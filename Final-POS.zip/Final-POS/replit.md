# Advanced POS System with 194+ Features

## Overview
This is a comprehensive Point of Sale (POS) system built with React, Express, and TypeScript. It includes dual-role support (Cashier and Customer), extensive product management, loyalty programs, QR code integration, messaging, deals, coupons, ratings, and much more.

## Recent Changes
- **November 7, 2025**: Configured for Replit environment - set up Node.js 20, configured Vite to allow all hosts for proxy support, created workflow for port 5000, configured deployment settings, and verified application runs correctly.
- **November 6, 2025**: Implemented role selection (Cashier/Customer), complete customer portal with 7 pages, QR code generation system, barcode scanning, rating system, deals management, announcements, coupons, messages, customer registration, loyalty program display, and IndexedDB integration for large datasets.

## User Preferences
- All features must work without errors
- Complete implementation of all 194 features
- Support for both cashier and customer workflows
- Secure PIN-based authentication
- Real-time messaging between cashiers and customers

## Project Architecture

### Frontend (React + Vite)
- **Role Selection**: Users can choose between Cashier or Customer role before login
- **Cashier Interface**: Full POS functionality with sidebar navigation
- **Customer Portal**: 7-page portal (Account, Deals, Announcements, Notifications, Messages, Online Delivery, Loyalty)
- **UI Components**: Radix UI + Tailwind CSS with custom components
- **State Management**: React Context for authentication, localStorage for data persistence
- **QR Code**: Product QR generation and scanning using qrcode and @zxing/browser libraries

### Backend (Express)
- **Server**: Express.js running on port 5000
- **Development**: Vite dev server integrated with HMR
- **Production**: Static file serving with optimized builds

### Data Storage
- **LocalStorage**: Primary storage for products, customers, cashiers, orders, deals, announcements, coupons, ratings
- **IndexedDB**: Large datasets (scan history, cart transfers, AI chats) with localStorage fallback
- **Audit Logs**: Complete tracking of all sensitive operations

### Key Features Implemented

#### Authentication & Access
- Dual-role system (Cashier/Customer)
- PIN-based authentication (4-digit)
- Role-based access control
- Customer registration by cashiers only

#### Customer Portal
- Account Details with tier, points, card balance
- Deals page showing active discounts
- Announcements from store
- Notifications for purchases and card activity
- Two-way messaging with cashiers
- Online Delivery link
- Loyalty program display with tier progress

#### Cashier Management
- Deals Management (percentage & Buy X Get Y Free)
- Announcements Management
- Coupons Management
- Customer Registration
- Messages Management
- Ratings View with analytics

#### Product Features
- QR code generation for each product
- Barcode/QR scanning with camera
- Product QR PDF export (20 per page, 4x5 grid)
- Product code lookup
- Stock tracking

#### Checkout & Payments
- Rating modal after checkout (5-star system)
- Survey link integration
- Card payment with PIN verification (in progress)
- Coupon code application (in progress)
- Multiple payment methods

#### Loyalty & Rewards
- Tier-based system (Bronze, Silver, Gold, Platinum)
- Points accrual from purchases
- Customer-facing loyalty view
- Progress tracking to next tier

#### Communications
- Real-time messaging between cashiers and customers
- Announcements visible to all customers
- Notifications for transactions

### Tech Stack
- **Frontend**: React 18, TypeScript, Vite, Tailwind CSS, Radix UI
- **Backend**: Express, Node.js
- **Libraries**: 
  - QR Code generation: qrcode
  - Barcode scanning: @zxing/browser
  - PDF generation: jsPDF, pdfmake
  - Date handling: date-fns
  - Storage: idb (IndexedDB wrapper)
  - Forms: react-hook-form, zod
  - UI: lucide-react icons, framer-motion

### File Structure
```
client/
  src/
    components/
      - CustomerPortal.tsx (Main customer interface)
      - Customer*.tsx (7 customer portal pages)
      - *Management.tsx (Cashier management components)
      - BarcodeScanner.tsx (Camera-based scanning)
      - RatingModal.tsx (Post-checkout rating)
      - ui/ (Reusable UI components)
    lib/
      - storage.ts (Data models and localStorage API)
      - qrcode.ts (QR generation utilities)
      - indexedDB.ts (IndexedDB wrapper)
      - utils.ts (Utility functions)
    App.tsx (Main routing)
    AuthContext.tsx (Authentication state)
server/
  - index.ts (Express server)
  - routes.ts (API routes)
  - vite.ts (Vite dev server integration)
shared/
  - schema.ts (Shared types)
```

### Data Models
- **Cashier**: id, name, pin, role, avatar, themeColor, permissions, shift info
- **Customer**: id, name, email, phone, cardPin, cardBalance, points, tier, loyalty data
- **Product**: id, code, name, price, stock, qrCode, category, supplier, tax settings
- **Order**: id, transactionId, items, payment, rating, coupon info
- **Deal**: id, productId, type (percentage/buyXgetY), discount, active status
- **Announcement**: id, title, message, createdBy, timestamp
- **Coupon**: id, code, discountPercent, active, usageCount, maxUses
- **Message**: id, from/to info, text, timestamp, read status
- **Rating**: id, orderId, rating (1-5), feedback, timestamp
- **Notification**: id, customerId, type, title, message, read status

### Settings
- Store information
- Tax rate and settings
- Loyalty program configuration
- Receipt customization (background, border, footer)
- Survey form URL
- Online delivery URL
- Cart link expiry and limits

### Deployment
- **Type**: Autoscale (stateless web application)
- **Build**: `npm run build` (Vite + esbuild)
- **Run**: `npm start` (Production Express server)
- **Port**: 5000 (frontend and API on same port)

### Next Steps for Full 194 Feature Implementation
Still pending implementation:
- Enhanced payment flows (card PIN verification at checkout)
- AI Price Adjuster rules engine
- Smart Tax Auto-Detection
- Cart Transfer via QR
- Auto PDF Exporter with scheduling
- Cashier Profiles with permissions
- Scan History tracking
- AI Chat (dockable panel or offline helper)
- Enhanced Categories with hierarchy
- Stock Management enhancements
- Suppliers module
- Staff Management with shifts
- Change PIN workflow
- Receipt customization UI
- Delete All Data feature
- Comprehensive help tooltips
- Performance optimizations
- Full audit logging
- Data archival
- End-to-end testing

### Development Commands
- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm start` - Run production server
- `npm run check` - TypeScript type checking

### Replit Configuration
- **Node.js Version**: 20
- **Workflow**: "POS System" workflow configured to run on port 5000
- **Vite Config**: Configured with `allowedHosts: true` to work with Replit's proxy
- **Deployment**: Autoscale deployment configured with build and run commands
- **Port Binding**: Server binds to 0.0.0.0:5000 for external access

### Environment Variables
- `PORT` - Server port (default: 5000)
- `NODE_ENV` - Environment (development/production)

### Notes
- This system uses client-side storage (localStorage + IndexedDB)
- No external database required for basic operation
- All features work offline
- QR scanning requires camera permission
- Customer registration requires cashier account
