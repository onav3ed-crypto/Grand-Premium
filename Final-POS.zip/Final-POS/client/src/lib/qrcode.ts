import QRCode from 'qrcode';
import jsPDF from 'jspdf';
import { Product } from './storage';

export async function generateQRCode(text: string, size: number = 300): Promise<string> {
  try {
    return await QRCode.toDataURL(text, {
      width: size,
      margin: 1,
      color: {
        dark: '#000000',
        light: '#FFFFFF',
      },
      errorCorrectionLevel: 'H',
    });
  } catch (error) {
    console.error('QR code generation failed:', error);
    return '';
  }
}

export async function generateProductQRCode(productId: string, productCode: string): Promise<string> {
  // Generate QR with just the product code for direct scanning
  return generateQRCode(productCode, 400);
}

export async function downloadQRCode(qrCodeDataUrl: string, filename: string): Promise<void> {
  const link = document.createElement('a');
  link.href = qrCodeDataUrl;
  link.download = `${filename}.png`;
  link.click();
}

export async function generateQRCodesPDF(products: Product[]): Promise<void> {
  const pdf = new jsPDF();
  const pageWidth = pdf.internal.pageSize.getWidth();
  const pageHeight = pdf.internal.pageSize.getHeight();
  
  const qrSize = 40;
  const padding = 5;
  const cols = 4;
  const rows = 5;
  const qrsPerPage = cols * rows;
  
  let currentPage = 0;
  let qrIndex = 0;
  
  for (let i = 0; i < products.length; i++) {
    if (i % qrsPerPage === 0 && i > 0) {
      pdf.addPage();
      currentPage++;
    }
    
    const posInPage = i % qrsPerPage;
    const row = Math.floor(posInPage / cols);
    const col = posInPage % cols;
    
    const x = padding + col * (qrSize + padding);
    const y = padding + row * (qrSize + padding + 10);
    
    const product = products[i];
    if (product.qrCode) {
      pdf.addImage(product.qrCode, 'PNG', x, y, qrSize, qrSize);
      pdf.setFontSize(8);
      pdf.text(`${product.name}`, x, y + qrSize + 5, { maxWidth: qrSize });
      pdf.text(`Code: ${product.code}`, x, y + qrSize + 8, { maxWidth: qrSize });
    }
  }
  
  pdf.save(`product-qrcodes-${new Date().toISOString().split('T')[0]}.pdf`);
}
