// Local Storage Management System
import { generateProductQRCode } from './qrcode';

export interface Cashier {
  id: string;
  name: string;
  pin: string;
  role: 'admin' | 'cashier' | 'manager';
  createdAt: string;
  avatar?: string;
  themeColor?: string;
  quickButtons?: string[];
  permissions?: {
    priceOverride: boolean;
    refunds: boolean;
    exports: boolean;
    settings: boolean;
  };
  shiftStart?: string;
  isActive?: boolean;
}

export interface Product {
  id: string;
  code: string;
  name: string;
  category: string;
  price: number;
  cost: number;
  stock: number;
  lowStockThreshold: number;
  sku: string;
  supplier: string;
  taxable: boolean;
  image?: string;
  description?: string;
  archived: boolean;
  qrCode?: string;
  taxFreeOverride?: boolean;
  taxDecisionSource?: 'auto' | 'manual';
  expiryDate?: string;
  lastPriceChange?: string;
  priceHistory?: { price: number; date: string; changedBy: string }[];
}

export interface Customer {
  id: string;
  name: string;
  email?: string;
  phone?: string;
  balance: number;
  points: number;
  tier: 'Bronze' | 'Silver' | 'Gold' | 'Platinum';
  totalSpent: number;
  visits: number;
  lastVisit: string;
  createdAt: string;
  birthday?: string;
  notes?: string;
  tags: string[];
  hasCard?: boolean;
  cardPin?: string;
  cardBalance?: number;
  role?: 'customer';
}

export interface OrderItem {
  id: string;
  productId: string;
  code: string;
  name: string;
  price: number;
  cost: number;
  quantity: number;
  discount: number;
  taxed: boolean;
}

export interface Order {
  id: string;
  transactionId: string;
  cashierId: string;
  cashierName: string;
  customerId?: string;
  customerName?: string;
  items: OrderItem[];
  subtotal: number;
  tax: number;
  discount: number;
  total: number;
  profit: number;
  paymentMethod: 'cash' | 'card' | 'split' | 'balance';
  paymentDetails: {
    cash?: number;
    card?: number;
    balance?: number;
    change?: number;
  };
  status: 'completed' | 'held' | 'refunded';
  createdAt: string;
  notes?: string;
  rating?: number;
  couponCode?: string;
  couponDiscount?: number;
}

export interface Deal {
  id: string;
  productId: string;
  type: 'percentage' | 'buyXgetY';
  discountPercent?: number;
  buyQuantity?: number;
  getQuantity?: number;
  active: boolean;
  createdAt: string;
  createdBy: string;
}

export interface Announcement {
  id: string;
  title: string;
  message: string;
  createdAt: string;
  createdBy: string;
}

export interface Message {
  id: string;
  fromId: string;
  fromName: string;
  fromRole: 'cashier' | 'customer';
  toId: string;
  toName: string;
  toRole: 'cashier' | 'customer';
  text: string;
  createdAt: string;
  read: boolean;
}

export interface Coupon {
  id: string;
  code: string;
  discountPercent: number;
  active: boolean;
  createdAt: string;
  createdBy: string;
  usageCount: number;
  maxUses?: number;
}

export interface Rating {
  id: string;
  orderId: string;
  rating: number;
  feedback?: string;
  createdAt: string;
}

export interface PriceRule {
  id: string;
  name: string;
  priority: number;
  active: boolean;
  mode: 'suggest' | 'autoApply';
  triggers: {
    lowStock?: number;
    highDemand?: number;
    timeOfDay?: string[];
    dayOfWeek?: string[];
    percentChange?: number;
  };
  action: {
    maxPercentIncrease: number;
    maxPercentDecrease: number;
  };
  cooldownMinutes: number;
  lastApplied?: string;
  createdBy: string;
  createdAt: string;
}

export interface PriceSuggestion {
  id: string;
  productId: string;
  currentPrice: number;
  suggestedPrice: number;
  reason: string;
  ruleId: string;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
  reviewedBy?: string;
  reviewedAt?: string;
}

export interface TaxRule {
  id: string;
  category: string;
  keywords: string[];
  skuPattern?: string;
  taxExempt: boolean;
  createdAt: string;
  createdBy: string;
}

export interface ScanHistoryEntry {
  id: string;
  timestamp: string;
  cashierId?: string;
  cashierName?: string;
  deviceInfo: string;
  decodedContent: string;
  actionTaken: string;
  productId?: string;
}

export interface CartTransfer {
  id: string;
  token: string;
  cartData: string;
  createdAt: string;
  expiresAt: string;
  maxUses: number;
  usageCount: number;
  blacklisted: boolean;
}

export interface PDFExportJob {
  id: string;
  type: 'receipt' | 'salesReport' | 'inventory';
  schedule?: string;
  lastRun?: string;
  nextRun?: string;
  active: boolean;
  template: string;
  createdBy: string;
  createdAt: string;
}

export interface Notification {
  id: string;
  customerId: string;
  type: 'purchase' | 'cardActivity' | 'points' | 'announcement';
  title: string;
  message: string;
  createdAt: string;
  read: boolean;
}

export interface AuditLog {
  id: string;
  action: string;
  entityType: string;
  entityId: string;
  userId: string;
  userName: string;
  userRole: string;
  changes?: any;
  timestamp: string;
}

export interface Supplier {
  id: string;
  name: string;
  contact: string;
  email?: string;
  phone?: string;
  address?: string;
  notes?: string;
  createdAt: string;
}

export interface Category {
  id: string;
  name: string;
  parentId?: string;
  description?: string;
  createdAt: string;
}

export interface StockOrder {
  id: string;
  supplierId: string;
  supplierName: string;
  items: { productId: string; productName: string; quantity: number; cost: number }[];
  total: number;
  status: 'pending' | 'ordered' | 'received';
  createdAt: string;
  createdBy: string;
}

export interface LoyaltyTransaction {
  id: string;
  customerId: string;
  type: 'earn' | 'redeem';
  points: number;
  orderId?: string;
  description: string;
  createdAt: string;
}

export interface ShiftHandover {
  id: string;
  cashierId: string;
  cashierName: string;
  shiftStart: string;
  shiftEnd: string;
  heldOrders: number;
  cashTotal: number;
  notes: string;
}

export interface AIChat {
  id: string;
  userId: string;
  role: 'cashier' | 'customer';
  messages: { role: 'user' | 'assistant'; content: string; timestamp: string }[];
  createdAt: string;
}

export interface Settings {
  storeName: string;
  storeAddress: string;
  storePhone: string;
  storeEmail: string;
  currency: 'USD' | 'AED' | 'EUR' | 'GBP';
  taxRate: number;
  taxEnabled: boolean;
  loyaltyEnabled: boolean;
  loyaltyRate: number;
  tierThresholds: {
    bronze: number;
    silver: number;
    gold: number;
    platinum: number;
  };
  receiptHeader: string;
  receiptFooter: string;
  receiptBackground?: string;
  receiptBorder?: string;
  receiptFooterLogo?: string;
  autoLockEnabled: boolean;
  idleTimeout: number;
  soundsEnabled: boolean;
  surveyFormUrl?: string;
  onlineDeliveryUrl?: string;
  cartLinkExpiryMinutes?: number;
  cartLinkMaxUses?: number;
}

class LocalStorage {
  private getItem<T>(key: string, defaultValue: T): T {
    try {
      const item = localStorage.getItem(key);
      return item ? JSON.parse(item) : defaultValue;
    } catch {
      return defaultValue;
    }
  }

  private setItem(key: string, value: any): void {
    localStorage.setItem(key, JSON.stringify(value));
  }

  // Cashiers
  getCashiers(): Cashier[] {
    return this.getItem('cashiers', []);
  }

  saveCashiers(cashiers: Cashier[]): void {
    this.setItem('cashiers', cashiers);
  }

  addCashier(cashier: Omit<Cashier, 'id' | 'createdAt'>): Cashier {
    const cashiers = this.getCashiers();
    const newCashier: Cashier = {
      ...cashier,
      id: crypto.randomUUID(),
      createdAt: new Date().toISOString(),
    };
    cashiers.push(newCashier);
    this.saveCashiers(cashiers);
    return newCashier;
  }

  getCashierByPin(pin: string): Cashier | undefined {
    return this.getCashiers().find(c => c.pin === pin);
  }

  // Products
  getProducts(): Product[] {
    return this.getItem('products', []);
  }

  saveProducts(products: Product[]): void {
    this.setItem('products', products);
  }

  addProduct(product: Omit<Product, 'id'>): Product {
    const products = this.getProducts();
    const newProduct: Product = {
      ...product,
      id: crypto.randomUUID(),
    };
    products.push(newProduct);
    this.saveProducts(products);
    return newProduct;
  }

  updateProduct(id: string, updates: Partial<Product>): void {
    const products = this.getProducts();
    const index = products.findIndex(p => p.id === id);
    if (index !== -1) {
      products[index] = { ...products[index], ...updates };
      this.saveProducts(products);
    }
  }

  deleteProduct(id: string): void {
    const products = this.getProducts();
    this.saveProducts(products.filter(p => p.id !== id));
  }

  getProductByCode(code: string): Product | undefined {
    return this.getProducts().find(p => p.code === code && !p.archived);
  }

  // Customers
  getCustomers(): Customer[] {
    return this.getItem('customers', []);
  }

  saveCustomers(customers: Customer[]): void {
    this.setItem('customers', customers);
  }

  addCustomer(customer: Omit<Customer, 'id' | 'createdAt' | 'totalSpent' | 'visits' | 'lastVisit'>): Customer {
    const customers = this.getCustomers();
    const newCustomer: Customer = {
      ...customer,
      id: crypto.randomUUID(),
      createdAt: new Date().toISOString(),
      totalSpent: 0,
      visits: 0,
      lastVisit: new Date().toISOString(),
    };
    customers.push(newCustomer);
    this.saveCustomers(customers);
    return newCustomer;
  }

  updateCustomer(id: string, updates: Partial<Customer>): void {
    const customers = this.getCustomers();
    const index = customers.findIndex(c => c.id === id);
    if (index !== -1) {
      customers[index] = { ...customers[index], ...updates };
      this.saveCustomers(customers);
    }
  }

  deleteCustomer(id: string): void {
    const customers = this.getCustomers();
    this.saveCustomers(customers.filter(c => c.id !== id));
  }

  // Orders
  getOrders(): Order[] {
    return this.getItem('orders', []);
  }

  saveOrders(orders: Order[]): void {
    this.setItem('orders', orders);
  }

  addOrder(order: Omit<Order, 'id' | 'transactionId' | 'createdAt'>): Order {
    const orders = this.getOrders();
    const date = new Date();
    const dateStr = date.toISOString().split('T')[0].replace(/-/g, '');
    const orderNum = String(orders.filter(o => o.createdAt.startsWith(date.toISOString().split('T')[0])).length + 1).padStart(4, '0');
    
    const newOrder: Order = {
      ...order,
      id: crypto.randomUUID(),
      transactionId: `TXN-${dateStr}-${orderNum}`,
      createdAt: date.toISOString(),
    };
    orders.push(newOrder);
    this.saveOrders(orders);

    // Update customer stats if customer selected
    if (order.customerId) {
      const customer = this.getCustomers().find(c => c.id === order.customerId);
      if (customer) {
        const loyaltyEarned = order.total * (this.getSettings().loyaltyRate / 100);
        this.updateCustomer(order.customerId, {
          totalSpent: customer.totalSpent + order.total,
          visits: customer.visits + 1,
          lastVisit: date.toISOString(),
          balance: customer.balance + loyaltyEarned,
          points: customer.points + Math.floor(loyaltyEarned * 100),
        });
      }
    }

    // Update product stock
    order.items.forEach(item => {
      const product = this.getProducts().find(p => p.id === item.productId);
      if (product) {
        this.updateProduct(product.id, {
          stock: Math.max(0, product.stock - item.quantity)
        });
      }
    });

    return newOrder;
  }

  getHeldOrders(): Order[] {
    return this.getOrders().filter(o => o.status === 'held');
  }

  // Settings
  getSettings(): Settings {
    return this.getItem('settings', {
      storeName: 'Premium POS Store',
      storeAddress: '123 Main Street, City, State 12345',
      storePhone: '+1 (555) 123-4567',
      storeEmail: 'store@example.com',
      currency: 'USD',
      taxRate: 5,
      taxEnabled: true,
      loyaltyEnabled: true,
      loyaltyRate: 5,
      tierThresholds: {
        bronze: 0,
        silver: 1000,
        gold: 5000,
        platinum: 10000,
      },
      receiptHeader: 'Thank you for shopping with us!',
      receiptFooter: 'Visit us again soon!\nwww.premiumpos.com',
      autoLockEnabled: true,
      idleTimeout: 2,
      soundsEnabled: true,
    });
  }

  saveSettings(settings: Settings): void {
    this.setItem('settings', settings);
  }

  updateSettings(updates: Partial<Settings>): void {
    const settings = this.getSettings();
    this.saveSettings({ ...settings, ...updates });
  }

  // Erase All Data - Complete Reset
  eraseAllData(): void {
    // Remove all localStorage items
    localStorage.removeItem('products');
    localStorage.removeItem('customers');
    localStorage.removeItem('orders');
    localStorage.removeItem('cashiers');
    localStorage.removeItem('deals');
    localStorage.removeItem('announcements');
    localStorage.removeItem('messages');
    localStorage.removeItem('coupons');
    localStorage.removeItem('ratings');
    localStorage.removeItem('notifications');
    localStorage.removeItem('auditLogs');
    localStorage.removeItem('categories');
    localStorage.removeItem('settings');
    localStorage.removeItem('currentCashier');
    localStorage.removeItem('currentCustomer');
    
    // Reinitialize with sample data
    this.initializeSampleData();
  }

  // Cleanup Inactive Customers (not visited in 6 months)
  cleanupInactiveCustomers(): void {
    const customers = this.getCustomers();
    const sixMonthsAgo = new Date();
    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);
    
    const activeCustomers = customers.filter(c => {
      const lastVisit = new Date(c.lastVisit);
      return lastVisit > sixMonthsAgo || c.points > 0;
    });
    
    this.saveCustomers(activeCustomers);
  }

  // Session
  getCurrentCashier(): Cashier | null {
    return this.getItem('currentCashier', null);
  }

  setCurrentCashier(cashier: Cashier | null): void {
    this.setItem('currentCashier', cashier);
  }

  getCurrentCustomer(): Customer | null {
    return this.getItem('currentCustomer', null);
  }

  setCurrentCustomer(customer: Customer | null): void {
    this.setItem('currentCustomer', customer);
  }

  getCustomerByPin(pin: string): Customer | undefined {
    return this.getCustomers().find(c => c.cardPin === pin);
  }

  // Deals
  getDeals(): Deal[] {
    return this.getItem('deals', []);
  }

  saveDeals(deals: Deal[]): void {
    this.setItem('deals', deals);
  }

  // Announcements
  getAnnouncements(): Announcement[] {
    return this.getItem('announcements', []);
  }

  saveAnnouncements(announcements: Announcement[]): void {
    this.setItem('announcements', announcements);
  }

  // Messages
  getMessages(): Message[] {
    return this.getItem('messages', []);
  }

  saveMessages(messages: Message[]): void {
    this.setItem('messages', messages);
  }

  // Coupons
  getCoupons(): Coupon[] {
    return this.getItem('coupons', []);
  }

  saveCoupons(coupons: Coupon[]): void {
    this.setItem('coupons', coupons);
  }

  // Ratings
  getRatings(): Rating[] {
    return this.getItem('ratings', []);
  }

  saveRatings(ratings: Rating[]): void {
    this.setItem('ratings', ratings);
  }

  // Notifications
  getNotifications(customerId: string): Notification[] {
    return this.getItem('notifications', []).filter((n: Notification) => n.customerId === customerId);
  }

  saveNotifications(notifications: Notification[]): void {
    this.setItem('notifications', notifications);
  }

  addNotification(notification: Omit<Notification, 'id' | 'createdAt'>): void {
    const notifications: Notification[] = this.getItem('notifications', []);
    notifications.push({
      ...notification,
      id: crypto.randomUUID(),
      createdAt: new Date().toISOString(),
      read: false,
    });
    this.saveNotifications(notifications);
  }

  // Audit Logs
  getAuditLogs(): AuditLog[] {
    return this.getItem('auditLogs', []);
  }

  saveAuditLogs(logs: AuditLog[]): void {
    this.setItem('auditLogs', logs);
  }

  addAuditLog(log: Omit<AuditLog, 'id' | 'timestamp'>): void {
    const logs = this.getAuditLogs();
    logs.push({
      ...log,
      id: crypto.randomUUID(),
      timestamp: new Date().toISOString(),
    });
    this.saveAuditLogs(logs);
  }

  // Categories
  getCategories(): any[] {
    return this.getItem('categories', []);
  }

  saveCategories(categories: any[]): void {
    this.setItem('categories', categories);
  }

  // Initialize with sample data
  async initializeSampleData(): Promise<void> {
    // Add admin if no cashiers exist
    const cashiers = this.getCashiers();
    if (cashiers.length === 0) {
      this.addCashier({
        name: 'Admin',
        pin: '1234',
        role: 'admin',
      });
    }

    // Add sample products if none exist
    const products = this.getProducts();
    if (products.length === 0) {
      const sampleProducts = [
        { code: 'PRD001', name: 'Premium Coffee', category: 'Drinks', price: 10.00, cost: 6.00, stock: 50, lowStockThreshold: 10, sku: 'CF-001', supplier: 'Coffee Co.', taxable: true, archived: false },
        { code: 'PRD002', name: 'Croissant', category: 'Food', price: 4.99, cost: 2.50, stock: 30, lowStockThreshold: 10, sku: 'BKR-001', supplier: 'Local Bakery', taxable: true, archived: false },
        { code: 'PRD003', name: 'Fresh Juice', category: 'Drinks', price: 5.99, cost: 3.20, stock: 25, lowStockThreshold: 10, sku: 'JCE-001', supplier: 'Juice Plus', taxable: false, archived: false },
        { code: 'PRD004', name: 'Sandwich', category: 'Food', price: 8.99, cost: 5.00, stock: 20, lowStockThreshold: 5, sku: 'SDW-001', supplier: 'Deli Fresh', taxable: true, archived: false },
        { code: 'PRD005', name: 'Salad Bowl', category: 'Food', price: 12.99, cost: 7.00, stock: 15, lowStockThreshold: 5, sku: 'SLD-001', supplier: 'Green Gardens', taxable: true, archived: false },
      ];
      
      // Generate QR codes for all sample products
      for (const p of sampleProducts) {
        const tempId = crypto.randomUUID();
        const qrCode = await generateProductQRCode(tempId, p.code);
        this.addProduct({ ...p, qrCode });
      }
    }
  }
}

export const storage = new LocalStorage();
