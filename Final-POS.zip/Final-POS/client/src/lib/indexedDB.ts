import { openDB, DBSchema, IDBPDatabase } from 'idb';

interface POSDB extends DBSchema {
  scanHistory: {
    key: string;
    value: {
      id: string;
      timestamp: string;
      cashierId?: string;
      cashierName?: string;
      deviceInfo: string;
      decodedContent: string;
      actionTaken: string;
      productId?: string;
    };
    indexes: { 'by-timestamp': string; 'by-cashier': string };
  };
  cartTransfers: {
    key: string;
    value: {
      id: string;
      token: string;
      cartData: string;
      createdAt: string;
      expiresAt: string;
      maxUses: number;
      usageCount: number;
      blacklisted: boolean;
    };
    indexes: { 'by-token': string; 'by-expiry': string };
  };
  aiChats: {
    key: string;
    value: {
      id: string;
      userId: string;
      role: 'cashier' | 'customer';
      messages: { role: 'user' | 'assistant'; content: string; timestamp: string }[];
      createdAt: string;
    };
    indexes: { 'by-user': string };
  };
}

let dbInstance: IDBPDatabase<POSDB> | null = null;

export async function initDB(): Promise<IDBPDatabase<POSDB>> {
  if (dbInstance) return dbInstance;
  
  dbInstance = await openDB<POSDB>('POS-Database', 1, {
    upgrade(db) {
      if (!db.objectStoreNames.contains('scanHistory')) {
        const scanStore = db.createObjectStore('scanHistory', { keyPath: 'id' });
        scanStore.createIndex('by-timestamp', 'timestamp');
        scanStore.createIndex('by-cashier', 'cashierId');
      }
      
      if (!db.objectStoreNames.contains('cartTransfers')) {
        const cartStore = db.createObjectStore('cartTransfers', { keyPath: 'id' });
        cartStore.createIndex('by-token', 'token');
        cartStore.createIndex('by-expiry', 'expiresAt');
      }
      
      if (!db.objectStoreNames.contains('aiChats')) {
        const chatStore = db.createObjectStore('aiChats', { keyPath: 'id' });
        chatStore.createIndex('by-user', 'userId');
      }
    },
  });
  
  return dbInstance;
}

export async function addScanHistory(entry: POSDB['scanHistory']['value']): Promise<void> {
  const db = await initDB();
  await db.add('scanHistory', entry);
}

export async function getScanHistory(): Promise<POSDB['scanHistory']['value'][]> {
  try {
    const db = await initDB();
    return await db.getAll('scanHistory');
  } catch {
    return [];
  }
}

export async function addCartTransfer(transfer: POSDB['cartTransfers']['value']): Promise<void> {
  const db = await initDB();
  await db.add('cartTransfers', transfer);
}

export async function getCartTransfers(): Promise<POSDB['cartTransfers']['value'][]> {
  try {
    const db = await initDB();
    return await db.getAll('cartTransfers');
  } catch {
    return [];
  }
}

export async function getCartTransferByToken(token: string): Promise<POSDB['cartTransfers']['value'] | undefined> {
  try {
    const db = await initDB();
    return await db.getFromIndex('cartTransfers', 'by-token', token);
  } catch {
    return undefined;
  }
}

export async function updateCartTransfer(id: string, updates: Partial<POSDB['cartTransfers']['value']>): Promise<void> {
  const db = await initDB();
  const existing = await db.get('cartTransfers', id);
  if (existing) {
    await db.put('cartTransfers', { ...existing, ...updates });
  }
}

export async function addAIChat(chat: POSDB['aiChats']['value']): Promise<void> {
  const db = await initDB();
  await db.add('aiChats', chat);
}

export async function getAIChats(userId: string): Promise<POSDB['aiChats']['value'][]> {
  try {
    const db = await initDB();
    return await db.getAllFromIndex('aiChats', 'by-user', userId);
  } catch {
    return [];
  }
}

export async function deleteAIChat(id: string): Promise<void> {
  const db = await initDB();
  await db.delete('aiChats', id);
}

export async function clearAllAIChats(userId: string): Promise<void> {
  const db = await initDB();
  const chats = await db.getAllFromIndex('aiChats', 'by-user', userId);
  for (const chat of chats) {
    await db.delete('aiChats', chat.id);
  }
}
