import { Switch, Route, useLocation } from 'wouter';
import { queryClient } from './lib/queryClient';
import { QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { SidebarProvider, SidebarTrigger } from '@/components/ui/sidebar';
import { AppSidebar } from '@/components/AppSidebar';
import { ThemeProvider } from '@/components/ThemeProvider';
import { ThemeToggle } from '@/components/ThemeToggle';
import { AuthProvider, useAuth } from '@/components/AuthContext';
import { LoginPage } from '@/components/LoginPage';
import { Dashboard } from '@/components/Dashboard';
import { POSCheckout } from '@/components/POSCheckout';
import { CustomerManagement } from '@/components/CustomerManagement';
import { ProductManagement } from '@/components/ProductManagement';
import { OrderHistory } from '@/components/OrderHistory';
import { HoldOrders } from '@/components/HoldOrders';
import { Settings } from '@/components/Settings';
import { ReturnExchange } from '@/components/ReturnExchange';
import { Categories } from '@/components/Categories';
import { StockManagement } from '@/components/StockManagement';
import { Suppliers } from '@/components/Suppliers';
import { LoyaltyProgram } from '@/components/LoyaltyProgram';
import { StaffManagement } from '@/components/StaffManagement';
import { CustomerPortal } from '@/components/CustomerPortal';
import { RatingsView } from '@/components/RatingsView';
import { DealsManagement } from '@/components/DealsManagement';
import { CouponsManagement } from '@/components/CouponsManagement';
import { AnnouncementsManagement } from '@/components/AnnouncementsManagement';
import { MessagesManagement } from '@/components/MessagesManagement';
import { ScanHistory } from '@/components/ScanHistory';
import { PINChange } from '@/components/PINChange';
import { AIChat } from '@/components/AIChat';
import { DataManagement } from '@/components/DataManagement';
import { Button } from '@/components/ui/button';
import { LogOut, User } from 'lucide-react';
import NotFound from '@/pages/not-found';

function Router() {
  const [location] = useLocation();

  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/checkout" component={POSCheckout} />
      <Route path="/customers" component={CustomerManagement} />
      <Route path="/products" component={ProductManagement} />
      <Route path="/orders" component={OrderHistory} />
      <Route path="/hold-orders" component={HoldOrders} />
      <Route path="/returns" component={ReturnExchange} />
      <Route path="/categories" component={Categories} />
      <Route path="/stock" component={StockManagement} />
      <Route path="/suppliers" component={Suppliers} />
      <Route path="/loyalty" component={LoyaltyProgram} />
      <Route path="/staff" component={StaffManagement} />
      <Route path="/ratings" component={RatingsView} />
      <Route path="/deals" component={DealsManagement} />
      <Route path="/coupons" component={CouponsManagement} />
      <Route path="/announcements" component={AnnouncementsManagement} />
      <Route path="/messages" component={MessagesManagement} />
      <Route path="/scan-history" component={ScanHistory} />
      <Route path="/ai-chat" component={AIChat} />
      <Route path="/change-pin" component={PINChange} />
      <Route path="/data" component={DataManagement} />
      <Route path="/settings" component={Settings} />
      <Route component={NotFound} />
    </Switch>
  );
}

function AppContent() {
  const [location] = useLocation();
  const { currentCashier, currentCustomer, userRole, logout } = useAuth();

  const sidebarStyle = {
    '--sidebar-width': '16rem',
  };

  if (!currentCashier && !currentCustomer) {
    return <LoginPage />;
  }

  if (userRole === 'customer' && currentCustomer) {
    return <CustomerPortal />;
  }

  if (!currentCashier) {
    return <LoginPage />;
  }

  return (
    <SidebarProvider style={sidebarStyle as React.CSSProperties}>
      <div className="flex h-screen w-full">
        <AppSidebar currentPath={location} />
        <div className="flex flex-col flex-1 overflow-hidden">
          <header className="flex items-center justify-between p-4 border-b bg-card">
            <SidebarTrigger data-testid="button-sidebar-toggle" />
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 text-sm">
                <User className="w-4 h-4" />
                <span className="font-medium">{currentCashier.name}</span>
                <span className="text-muted-foreground">({currentCashier.role})</span>
              </div>
              <ThemeToggle />
              <Button
                variant="ghost"
                size="icon"
                onClick={logout}
                data-testid="button-logout"
              >
                <LogOut className="w-4 h-4" />
              </Button>
            </div>
          </header>
          <main className="flex-1 overflow-auto p-6">
            <Router />
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <AuthProvider>
          <TooltipProvider>
            <AppContent />
            <Toaster />
          </TooltipProvider>
        </AuthProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}
