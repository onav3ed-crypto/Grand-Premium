import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Search, Plus, Package, AlertTriangle, Download, Upload, Edit, Trash2, QrCode } from 'lucide-react';
import { storage, type Product } from '@/lib/storage';
import { useToast } from '@/hooks/use-toast';
import Papa from 'papaparse';
import { generateProductQRCode, downloadQRCode, generateQRCodesPDF } from '@/lib/qrcode';

export function ProductManagement() {
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddEdit, setShowAddEdit] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [enlargedQR, setEnlargedQR] = useState<{ url: string; name: string; code: string } | null>(null);
  const [formData, setFormData] = useState({
    code: '',
    name: '',
    category: 'Food',
    price: '',
    cost: '',
    stock: '',
    lowStockThreshold: '10',
    sku: '',
    supplier: '',
    taxable: true,
  });
  const { toast } = useToast();

  const products = storage.getProducts().filter(p => !p.archived);
  
  const filteredProducts = products.filter(product =>
    product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    product.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
    product.sku.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStockStatus = (stock: number, lowStock: number) => {
    if (stock === 0) return { label: 'Out of Stock', variant: 'destructive' as const };
    if (stock <= lowStock) return { label: 'Low Stock', variant: 'default' as const };
    return { label: 'In Stock', variant: 'outline' as const };
  };

  const openAddDialog = () => {
    setEditingProduct(null);
    setFormData({
      code: `PRD${String(products.length + 1).padStart(3, '0')}`,
      name: '',
      category: 'Food',
      price: '',
      cost: '',
      stock: '',
      lowStockThreshold: '10',
      sku: '',
      supplier: '',
      taxable: true,
    });
    setShowAddEdit(true);
  };

  const openEditDialog = (product: Product) => {
    setEditingProduct(product);
    setFormData({
      code: product.code,
      name: product.name,
      category: product.category,
      price: product.price.toString(),
      cost: product.cost.toString(),
      stock: product.stock.toString(),
      lowStockThreshold: product.lowStockThreshold.toString(),
      sku: product.sku,
      supplier: product.supplier,
      taxable: product.taxable,
    });
    setShowAddEdit(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.name.trim() || !formData.code.trim()) {
      toast({
        title: 'Missing Information',
        description: 'Name and code are required',
        variant: 'destructive',
      });
      return;
    }

    const productData = {
      code: formData.code.trim(),
      name: formData.name.trim(),
      category: formData.category,
      price: parseFloat(formData.price) || 0,
      cost: parseFloat(formData.cost) || 0,
      stock: parseInt(formData.stock) || 0,
      lowStockThreshold: parseInt(formData.lowStockThreshold) || 10,
      sku: formData.sku.trim(),
      supplier: formData.supplier.trim(),
      taxable: formData.taxable,
      archived: false,
    };

    if (editingProduct) {
      const qrCode = await generateProductQRCode(editingProduct.id, productData.code);
      storage.updateProduct(editingProduct.id, { ...productData, qrCode });
      toast({
        title: 'Product Updated',
        description: `${formData.name} has been updated successfully`,
      });
    } else {
      const tempId = crypto.randomUUID();
      const qrCode = await generateProductQRCode(tempId, productData.code);
      storage.addProduct({ ...productData, qrCode });
      toast({
        title: 'Product Added',
        description: `${formData.name} has been added successfully`,
      });
    }

    setShowAddEdit(false);
  };

  const handleDelete = (product: Product) => {
    if (confirm(`Are you sure you want to delete ${product.name}?`)) {
      storage.deleteProduct(product.id);
      toast({
        title: 'Product Deleted',
        description: `${product.name} has been deleted`,
      });
    }
  };

  const handleDownloadAllQRs = async () => {
    const productsWithQR = products.filter(p => p.qrCode);
    if (productsWithQR.length === 0) {
      toast({
        title: 'No QR Codes',
        description: 'No products have QR codes to export',
        variant: 'destructive',
      });
      return;
    }

    await generateQRCodesPDF(productsWithQR);
    toast({
      title: 'QR Codes Downloaded',
      description: `${productsWithQR.length} QR codes exported to PDF (20 per page, 4x5 grid)`,
    });
  };

  const handleExportCSV = () => {
    const csvData = products.map(p => ({
      Code: p.code,
      Name: p.name,
      Category: p.category,
      Price: p.price,
      Cost: p.cost,
      Stock: p.stock,
      'Low Stock Threshold': p.lowStockThreshold,
      SKU: p.sku,
      Supplier: p.supplier,
      Taxable: p.taxable ? 'Yes' : 'No',
    }));

    const csv = Papa.unparse(csvData);
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `products-${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    URL.revokeObjectURL(url);

    toast({
      title: 'Export Successful',
      description: `${products.length} products exported`,
    });
  };

  const handleImportCSV = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    Papa.parse(file, {
      header: true,
      complete: (results) => {
        let imported = 0;
        results.data.forEach((row: any) => {
          if (row.Code && row.Name) {
            storage.addProduct({
              code: row.Code,
              name: row.Name,
              category: row.Category || 'Food',
              price: parseFloat(row.Price) || 0,
              cost: parseFloat(row.Cost) || 0,
              stock: parseInt(row.Stock) || 0,
              lowStockThreshold: parseInt(row['Low Stock Threshold']) || 10,
              sku: row.SKU || '',
              supplier: row.Supplier || '',
              taxable: row.Taxable === 'Yes',
              archived: false,
            });
            imported++;
          }
        });
        toast({
          title: 'Import Successful',
          description: `${imported} products imported`,
        });
      },
    });
  };

  const stats = {
    total: products.length,
    lowStock: products.filter(p => p.stock <= p.lowStockThreshold && p.stock > 0).length,
    outOfStock: products.filter(p => p.stock === 0).length,
    totalValue: products.reduce((sum, p) => sum + (p.price * p.stock), 0),
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Product Management</h1>
          <p className="text-muted-foreground mt-1">Manage inventory and product catalog</p>
        </div>
        <div className="flex gap-2">
          <input
            type="file"
            accept=".csv"
            onChange={handleImportCSV}
            className="hidden"
            id="csv-upload"
          />
          <Button
            variant="outline"
            onClick={() => document.getElementById('csv-upload')?.click()}
            data-testid="button-import-products"
          >
            <Upload className="w-4 h-4 mr-2" />
            Import CSV
          </Button>
          <Button
            variant="outline"
            onClick={handleExportCSV}
            data-testid="button-export-products"
          >
            <Download className="w-4 h-4 mr-2" />
            Export CSV
          </Button>
          <Button
            variant="outline"
            onClick={handleDownloadAllQRs}
            data-testid="button-download-all-qrs"
          >
            <QrCode className="w-4 h-4 mr-2" />
            Download All QRs
          </Button>
          <Button onClick={openAddDialog} data-testid="button-add-product">
            <Plus className="w-4 h-4 mr-2" />
            Add Product
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-4">
        <Card className="p-6">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-primary/10 rounded-lg">
              <Package className="w-6 h-6 text-primary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Total Products</p>
              <p className="text-2xl font-bold">{stats.total}</p>
            </div>
          </div>
        </Card>
        <Card className="p-6">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-chart-3/10 rounded-lg">
              <AlertTriangle className="w-6 h-6 text-chart-3" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Low Stock</p>
              <p className="text-2xl font-bold">{stats.lowStock}</p>
            </div>
          </div>
        </Card>
        <Card className="p-6">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-destructive/10 rounded-lg">
              <AlertTriangle className="w-6 h-6 text-destructive" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Out of Stock</p>
              <p className="text-2xl font-bold">{stats.outOfStock}</p>
            </div>
          </div>
        </Card>
        <Card className="p-6">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-chart-2/10 rounded-lg">
              <Package className="w-6 h-6 text-chart-2" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Inventory Value</p>
              <p className="text-2xl font-bold">${stats.totalValue.toFixed(0)}</p>
            </div>
          </div>
        </Card>
      </div>

      <Card className="p-6">
        <div className="relative mb-6">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            data-testid="input-search-product"
            placeholder="Search products by name, code, or SKU..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>

        <ScrollArea className="h-[500px]">
          <div className="space-y-3">
            {filteredProducts.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">
                <Package className="w-12 h-12 mx-auto mb-3 opacity-50" />
                <p>No products found</p>
              </div>
            ) : (
              filteredProducts.map((product) => {
                const stockStatus = getStockStatus(product.stock, product.lowStockThreshold);
                const profit = product.price - product.cost;
                const margin = product.price > 0 ? ((profit / product.price) * 100).toFixed(1) : '0';

                return (
                  <Card key={product.id} className="p-4 hover-elevate">
                    <div className="flex items-start gap-6">
                      <div className="flex flex-col gap-2 flex-shrink-0">
                        <div className="w-16 h-16 rounded-lg bg-muted flex items-center justify-center">
                          <Package className="w-8 h-8 text-muted-foreground" />
                        </div>
                        {product.qrCode && (
                          <div 
                            className="w-16 h-16 rounded-lg bg-white border-2 border-muted cursor-pointer hover:border-primary transition-colors p-1"
                            onClick={() => setEnlargedQR({ url: product.qrCode!, name: product.name, code: product.code })}
                            title="Click to enlarge QR code"
                          >
                            <img src={product.qrCode} alt={`QR for ${product.name}`} className="w-full h-full" />
                          </div>
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <h3 className="font-semibold text-lg">{product.name}</h3>
                              <Badge variant="outline">{product.category}</Badge>
                              {!product.taxable && <Badge variant="outline">Tax Free</Badge>}
                            </div>
                            <p className="text-sm text-muted-foreground">
                              Code: {product.code} • SKU: {product.sku}
                            </p>
                          </div>
                          <div className="flex gap-2">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => openEditDialog(product)}
                              data-testid={`button-edit-${product.id}`}
                            >
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleDelete(product)}
                              data-testid={`button-delete-${product.id}`}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                          <div>
                            <p className="text-sm text-muted-foreground mb-1">Price</p>
                            <p className="font-semibold">${product.price.toFixed(2)}</p>
                          </div>
                          <div>
                            <p className="text-sm text-muted-foreground mb-1">Cost</p>
                            <p className="font-semibold">${product.cost.toFixed(2)}</p>
                          </div>
                          <div>
                            <p className="text-sm text-muted-foreground mb-1">Profit</p>
                            <p className="font-semibold text-chart-2">${profit.toFixed(2)}</p>
                          </div>
                          <div>
                            <p className="text-sm text-muted-foreground mb-1">Margin</p>
                            <p className="font-semibold">{margin}%</p>
                          </div>
                          <div>
                            <p className="text-sm text-muted-foreground mb-1">Stock</p>
                            <div className="flex items-center gap-2">
                              <p className="font-semibold">{product.stock}</p>
                              {product.stock <= product.lowStockThreshold && product.stock > 0 && (
                                <AlertTriangle className="w-4 h-4 text-chart-3" />
                              )}
                            </div>
                          </div>
                          <div>
                            <p className="text-sm text-muted-foreground mb-1">Status</p>
                            <Badge variant={stockStatus.variant}>{stockStatus.label}</Badge>
                          </div>
                        </div>

                        {product.supplier && (
                          <div className="mt-3 pt-3 border-t">
                            <p className="text-sm text-muted-foreground">
                              Supplier: <span className="text-foreground font-medium">{product.supplier}</span>
                            </p>
                          </div>
                        )}
                      </div>
                    </div>
                  </Card>
                );
              })
            )}
          </div>
        </ScrollArea>
      </Card>

      <Dialog open={showAddEdit} onOpenChange={setShowAddEdit}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-auto">
          <DialogHeader>
            <DialogTitle>{editingProduct ? 'Edit Product' : 'Add New Product'}</DialogTitle>
          </DialogHeader>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="code">Product Code *</Label>
                <Input
                  id="code"
                  data-testid="input-product-code"
                  value={formData.code}
                  onChange={(e) => setFormData({ ...formData, code: e.target.value })}
                  placeholder="PRD001"
                  className="mt-1"
                />
              </div>
              <div>
                <Label htmlFor="sku">SKU</Label>
                <Input
                  id="sku"
                  data-testid="input-product-sku"
                  value={formData.sku}
                  onChange={(e) => setFormData({ ...formData, sku: e.target.value })}
                  placeholder="SKU-001"
                  className="mt-1"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="name">Product Name *</Label>
              <Input
                id="name"
                data-testid="input-product-name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="Product name"
                className="mt-1"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="category">Category</Label>
                <Select value={formData.category} onValueChange={(value) => setFormData({ ...formData, category: value })}>
                  <SelectTrigger className="mt-1" data-testid="select-category">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Food">Food</SelectItem>
                    <SelectItem value="Drink">Drink</SelectItem>
                    <SelectItem value="Toy">Toy</SelectItem>
                    <SelectItem value="Clothes">Clothes</SelectItem>
                    <SelectItem value="Book">Book</SelectItem>
                    <SelectItem value="Tech">Tech</SelectItem>
                    <SelectItem value="Other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="supplier">Supplier</Label>
                <Input
                  id="supplier"
                  data-testid="input-product-supplier"
                  value={formData.supplier}
                  onChange={(e) => setFormData({ ...formData, supplier: e.target.value })}
                  placeholder="Supplier name"
                  className="mt-1"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="price">Sell Price</Label>
                <Input
                  id="price"
                  data-testid="input-product-price"
                  type="number"
                  step="0.01"
                  value={formData.price}
                  onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                  placeholder="0.00"
                  className="mt-1"
                />
              </div>
              <div>
                <Label htmlFor="cost">Cost Price</Label>
                <Input
                  id="cost"
                  data-testid="input-product-cost"
                  type="number"
                  step="0.01"
                  value={formData.cost}
                  onChange={(e) => setFormData({ ...formData, cost: e.target.value })}
                  placeholder="0.00"
                  className="mt-1"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="stock">Stock Quantity</Label>
                <Input
                  id="stock"
                  data-testid="input-product-stock"
                  type="number"
                  value={formData.stock}
                  onChange={(e) => setFormData({ ...formData, stock: e.target.value })}
                  placeholder="0"
                  className="mt-1"
                />
              </div>
              <div>
                <Label htmlFor="lowStock">Low Stock Threshold</Label>
                <Input
                  id="lowStock"
                  data-testid="input-product-low-stock"
                  type="number"
                  value={formData.lowStockThreshold}
                  onChange={(e) => setFormData({ ...formData, lowStockThreshold: e.target.value })}
                  placeholder="10"
                  className="mt-1"
                />
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Switch
                id="taxable"
                data-testid="switch-taxable"
                checked={formData.taxable}
                onCheckedChange={(checked) => setFormData({ ...formData, taxable: checked })}
              />
              <Label htmlFor="taxable">Taxable Product</Label>
            </div>

            <div className="flex gap-2 pt-4">
              <Button
                type="button"
                variant="outline"
                className="flex-1"
                onClick={() => setShowAddEdit(false)}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                className="flex-1"
                data-testid="button-save-product"
              >
                {editingProduct ? 'Update' : 'Add'} Product
              </Button>
            </div>
            {editingProduct && editingProduct.qrCode && (
              <div className="flex flex-col items-center gap-2 pt-4 border-t">
                <Label>Product QR Code</Label>
                <div 
                  className="w-32 h-32 rounded-lg bg-white border-2 border-muted cursor-pointer hover:border-primary transition-colors p-2"
                  onClick={() => setEnlargedQR({ url: editingProduct.qrCode!, name: editingProduct.name, code: editingProduct.code })}
                  title="Click to enlarge QR code"
                >
                  <img src={editingProduct.qrCode} alt={`QR for ${editingProduct.name}`} className="w-full h-full" />
                </div>
              </div>
            )}

            <div className="flex gap-2 pt-4">
              <Button
                type="button"
                variant="outline"
                className="flex-1"
                onClick={() => setShowAddEdit(false)}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                className="flex-1"
                data-testid="button-save-product"
              >
                {editingProduct ? 'Update' : 'Add'} Product
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* QR Code Enlarged Dialog */}
      <Dialog open={!!enlargedQR} onOpenChange={() => setEnlargedQR(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Product QR Code</DialogTitle>
          </DialogHeader>
          {enlargedQR && (
            <div className="space-y-4">
              <div className="flex flex-col items-center gap-2">
                <div className="w-64 h-64 rounded-lg bg-white border-2 border-muted p-2">
                  <img src={enlargedQR.url} alt={`QR for ${enlargedQR.name}`} className="w-full h-full" />
                </div>
                <div className="text-center">
                  <p className="font-semibold text-lg">{enlargedQR.name}</p>
                  <p className="text-sm text-muted-foreground">Code: {enlargedQR.code}</p>
                </div>
              </div>
              <Button
                onClick={async () => {
                  await downloadQRCode(enlargedQR.url, `${enlargedQR.code}_${enlargedQR.name}`);
                  toast({
                    title: 'QR Code Downloaded',
                    description: `QR code for ${enlargedQR.name} saved`,
                  });
                }}
                className="w-full"
              >
                <Download className="w-4 h-4 mr-2" />
                Download QR Code
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
