import { useState, useEffect } from 'react';
import { storage, Announcement } from '@/lib/storage';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Label } from './ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { useAuth } from './AuthContext';
import { useToast } from '@/hooks/use-toast';
import { Plus, Megaphone, Trash2 } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

export function AnnouncementsManagement() {
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const { currentCashier } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    loadAnnouncements();
  }, []);

  const loadAnnouncements = () => {
    setAnnouncements(storage.getAnnouncements().sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    ));
  };

  const createAnnouncement = () => {
    if (!title.trim() || !message.trim() || !currentCashier) return;

    const announcement: Announcement = {
      id: crypto.randomUUID(),
      title,
      message,
      createdAt: new Date().toISOString(),
      createdBy: currentCashier.name,
    };

    const all = storage.getAnnouncements();
    all.push(announcement);
    storage.saveAnnouncements(all);
    
    toast({ title: 'Announcement Created', description: 'Customers will see this immediately' });
    setIsDialogOpen(false);
    setTitle('');
    setMessage('');
    loadAnnouncements();
  };

  const deleteAnnouncement = (id: string) => {
    const all = storage.getAnnouncements().filter(a => a.id !== id);
    storage.saveAnnouncements(all);
    loadAnnouncements();
    toast({ title: 'Announcement Deleted' });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Announcements</h2>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button><Plus className="w-4 h-4 mr-2" />New Announcement</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create Announcement</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>Title</Label>
                <Input 
                  placeholder="Announcement title" 
                  value={title} 
                  onChange={e => setTitle(e.target.value)}
                />
              </div>
              <div>
                <Label>Message</Label>
                <Textarea 
                  placeholder="Enter your message here. You can include promo codes like 'Use WELCOME10 for 10% off'"
                  rows={6}
                  value={message}
                  onChange={e => setMessage(e.target.value)}
                />
              </div>
              <Button onClick={createAnnouncement} className="w-full">Create Announcement</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="space-y-4">
        {announcements.map(a => (
          <Card key={a.id} className="p-6">
            <div className="flex items-start gap-4">
              <div className="p-2 bg-primary/10 rounded-lg">
                <Megaphone className="w-6 h-6 text-primary" />
              </div>
              <div className="flex-1">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-semibold text-lg">{a.title}</h3>
                  <Button variant="ghost" size="sm" onClick={() => deleteAnnouncement(a.id)}>
                    <Trash2 className="w-4 h-4 text-destructive" />
                  </Button>
                </div>
                <p className="text-muted-foreground whitespace-pre-wrap">{a.message}</p>
                <p className="text-sm text-muted-foreground mt-3">
                  By {a.createdBy} • {formatDistanceToNow(new Date(a.createdAt), { addSuffix: true })}
                </p>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
