import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { AlertTriangle, Download, Trash2, Database, FileJson, FileText, Shield } from 'lucide-react';
import { storage } from '@/lib/storage';
import { useAuth } from './AuthContext';
import { useToast } from '@/hooks/use-toast';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';

export function DataManagement() {
  const { currentCashier } = useAuth();
  const { toast } = useToast();
  const [confirmText, setConfirmText] = useState('');

  const isAdmin = currentCashier?.role === 'admin';

  if (!isAdmin) {
    return (
      <div className="space-y-6">
        <Card className="p-12 text-center">
          <Shield className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
          <h2 className="text-2xl font-bold mb-2">Access Denied</h2>
          <p className="text-muted-foreground">
            Only administrators can access Data Management.
            <br />
            Contact your system admin for data exports or management.
          </p>
        </Card>
      </div>
    );
  }

  const exportAllData = () => {
    const data = {
      exportDate: new Date().toISOString(),
      products: storage.getProducts(),
      customers: storage.getCustomers(),
      orders: storage.getOrders(),
      cashiers: storage.getCashiers(),
      categories: storage.getCategories(),
      deals: storage.getDeals(),
      coupons: storage.getCoupons(),
      announcements: storage.getAnnouncements(),
      settings: storage.getSettings(),
      ratings: storage.getRatings(),
    };

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `pos-backup-${new Date().toISOString().split('T')[0]}.json`;
    a.click();

    toast({
      title: 'Data Exported',
      description: 'Complete system backup has been downloaded',
    });
  };

  const exportCSV = (type: string) => {
    let headers: string[] = [];
    let rows: any[][] = [];

    if (type === 'products') {
      const products = storage.getProducts();
      headers = ['Code', 'Name', 'Category', 'Price', 'Cost', 'Stock', 'SKU'];
      rows = products.map(p => [p.code, p.name, p.category, p.price, p.cost, p.stock, p.sku]);
    } else if (type === 'customers') {
      const customers = storage.getCustomers();
      headers = ['Name', 'Email', 'Phone', 'Points', 'Balance', 'Total Spent', 'Tier'];
      rows = customers.map(c => [c.name, c.email || '', c.phone || '', c.points, c.balance, c.totalSpent, c.tier]);
    } else if (type === 'orders') {
      const orders = storage.getOrders();
      headers = ['Transaction ID', 'Date', 'Customer', 'Total', 'Payment Method', 'Status'];
      rows = orders.map(o => [o.transactionId, o.createdAt, o.customerName || 'Guest', o.total, o.paymentMethod, o.status]);
    }

    const csv = [headers, ...rows].map(row => row.join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${type}-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();

    toast({
      title: 'Export Complete',
      description: `${type} data exported to CSV`,
    });
  };

  const deleteAllData = () => {
    if (!isAdmin) {
      toast({
        title: 'Permission Denied',
        description: 'Only administrators can delete all data',
        variant: 'destructive',
      });
      return;
    }

    storage.addAuditLog({
      action: 'Delete All Data',
      entityType: 'system',
      entityId: 'all',
      userId: currentCashier!.id,
      userName: currentCashier!.name,
      userRole: currentCashier!.role,
    });

    storage.eraseAllData();

    toast({
      title: 'All Data Deleted',
      description: 'System has been reset to initial state',
    });

    window.location.href = '/';
  };

  const dataStats = {
    products: storage.getProducts().length,
    customers: storage.getCustomers().length,
    orders: storage.getOrders().length,
    categories: storage.getCategories().length,
    deals: storage.getDeals().length,
    coupons: storage.getCoupons().length,
  };

  const totalRecords = Object.values(dataStats).reduce((a, b) => a + b, 0);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold flex items-center gap-2">
          <Database className="w-8 h-8" />
          Data Management
        </h1>
        <p className="text-muted-foreground mt-1">
          Export, backup, and manage your POS system data
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <Card className="p-6">
          <div className="flex items-center gap-4">
            <div className="h-12 w-12 rounded-lg bg-blue-100 dark:bg-blue-900/20 flex items-center justify-center">
              <Database className="h-6 w-6 text-blue-600" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Total Records</p>
              <p className="text-2xl font-bold">{totalRecords}</p>
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center gap-4">
            <div className="h-12 w-12 rounded-lg bg-green-100 dark:bg-green-900/20 flex items-center justify-center">
              <FileText className="h-6 w-6 text-green-600" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Products</p>
              <p className="text-2xl font-bold">{dataStats.products}</p>
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center gap-4">
            <div className="h-12 w-12 rounded-lg bg-purple-100 dark:bg-purple-900/20 flex items-center justify-center">
              <FileText className="h-6 w-6 text-purple-600" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Customers</p>
              <p className="text-2xl font-bold">{dataStats.customers}</p>
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center gap-4">
            <div className="h-12 w-12 rounded-lg bg-orange-100 dark:bg-orange-900/20 flex items-center justify-center">
              <FileText className="h-6 w-6 text-orange-600" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Orders</p>
              <p className="text-2xl font-bold">{dataStats.orders}</p>
            </div>
          </div>
        </Card>
      </div>

      <Card className="p-6">
        <h3 className="text-lg font-semibold mb-4">Export Data</h3>
        <div className="grid gap-4 md:grid-cols-2">
          <div>
            <h4 className="font-medium mb-2">Complete System Backup</h4>
            <p className="text-sm text-muted-foreground mb-3">
              Export all data as JSON including products, customers, orders, and settings
            </p>
            <Button onClick={exportAllData} className="w-full">
              <FileJson className="w-4 h-4 mr-2" />
              Export All Data (JSON)
            </Button>
          </div>

          <div>
            <h4 className="font-medium mb-2">Individual Exports</h4>
            <p className="text-sm text-muted-foreground mb-3">
              Export specific data types as CSV for analysis
            </p>
            <div className="flex flex-wrap gap-2">
              <Button variant="outline" size="sm" onClick={() => exportCSV('products')}>
                <Download className="w-3 h-3 mr-1" />
                Products CSV
              </Button>
              <Button variant="outline" size="sm" onClick={() => exportCSV('customers')}>
                <Download className="w-3 h-3 mr-1" />
                Customers CSV
              </Button>
              <Button variant="outline" size="sm" onClick={() => exportCSV('orders')}>
                <Download className="w-3 h-3 mr-1" />
                Orders CSV
              </Button>
            </div>
          </div>
        </div>
      </Card>

      {isAdmin && (
        <Card className="p-6 border-red-200 dark:border-red-800 bg-red-50 dark:bg-red-900/10">
          <div className="flex items-start gap-4">
            <AlertTriangle className="w-6 h-6 text-red-600 flex-shrink-0 mt-1" />
            <div className="flex-1">
              <h3 className="text-lg font-semibold text-red-900 dark:text-red-100 mb-2">
                Danger Zone
              </h3>
              <p className="text-sm text-red-700 dark:text-red-300 mb-4">
                Permanently delete all system data. This action cannot be undone.
                All products, customers, orders, and settings will be erased.
              </p>
              
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="destructive">
                    <Trash2 className="w-4 h-4 mr-2" />
                    Delete All Data
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle className="flex items-center gap-2">
                      <AlertTriangle className="w-5 h-5 text-red-600" />
                      Are you absolutely sure?
                    </AlertDialogTitle>
                    <AlertDialogDescription>
                      This will permanently delete:
                      <ul className="list-disc list-inside mt-2 space-y-1">
                        <li>{dataStats.products} products</li>
                        <li>{dataStats.customers} customers</li>
                        <li>{dataStats.orders} orders</li>
                        <li>All settings and configurations</li>
                        <li>All historical data and logs</li>
                      </ul>
                      <p className="mt-4 font-medium text-red-600">
                        This action cannot be undone. Consider exporting your data first.
                      </p>
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction
                      onClick={deleteAllData}
                      className="bg-red-600 hover:bg-red-700"
                    >
                      Yes, Delete Everything
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </div>
          </div>
        </Card>
      )}

      {!isAdmin && (
        <Card className="p-6 bg-muted/50">
          <div className="flex items-center gap-3">
            <Shield className="w-5 h-5 text-muted-foreground" />
            <p className="text-sm text-muted-foreground">
              <strong>Note:</strong> Only administrators can delete system data.
              Contact your system admin for destructive operations.
            </p>
          </div>
        </Card>
      )}
    </div>
  );
}
