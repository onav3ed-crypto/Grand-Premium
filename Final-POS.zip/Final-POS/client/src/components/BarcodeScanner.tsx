import { useState, useEffect, useRef } from 'react';
import { BrowserMultiFormatReader } from '@zxing/browser';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { Camera, X } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onScan: (code: string) => void;
}

export function BarcodeScanner({ isOpen, onClose, onScan }: Props) {
  const [isScanning, setIsScanning] = useState(false);
  const [error, setError] = useState('');
  const videoRef = useRef<HTMLVideoElement>(null);
  const readerRef = useRef<BrowserMultiFormatReader | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    if (isOpen && !readerRef.current) {
      readerRef.current = new BrowserMultiFormatReader();
    }

    return () => {
      stopScanning();
    };
  }, [isOpen]);

  const startScanning = async () => {
    setError('');
    setIsScanning(true);

    try {
      if (!readerRef.current || !videoRef.current) {
        setError('Scanner not initialized. Please try again.');
        setIsScanning(false);
        return;
      }

      // Check if getUserMedia is supported
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setError('Camera access is not supported in this browser. Please use a modern browser like Chrome, Firefox, or Safari.');
        setIsScanning(false);
        return;
      }

      // Request camera permission explicitly
      try {
        console.log('Requesting camera permission...');
        const stream = await navigator.mediaDevices.getUserMedia({ 
          video: { facingMode: 'environment' } 
        });
        streamRef.current = stream;
        console.log('Camera permission granted');
        
        const devices = await BrowserMultiFormatReader.listVideoInputDevices();
        console.log('Available cameras:', devices.length);
        
        if (devices.length === 0) {
          setError('No camera found. Please ensure your device has a camera and grant permission.');
          setIsScanning(false);
          return;
        }

        const selectedDeviceId = devices[0].deviceId;
        console.log('Starting scanner with device:', selectedDeviceId);

        await readerRef.current.decodeFromVideoDevice(
          selectedDeviceId,
          videoRef.current,
          (result, error) => {
            if (result) {
              const code = result.getText();
              console.log('QR Code scanned:', code);
              onScan(code);
              toast({ title: 'Scanned!', description: `Code: ${code}` });
              stopScanning();
              onClose();
            }
          }
        );
        console.log('Scanner started successfully');
      } catch (permErr: any) {
        console.error('Camera permission error:', permErr);
        setError(`Camera permission denied: ${permErr.message}. Please enable camera access in your browser settings and try again.`);
        setIsScanning(false);
        return;
      }
    } catch (err: any) {
      console.error('Scanner error:', err);
      setError(err.message || 'Failed to start camera. Please check permissions.');
      setIsScanning(false);
    }
  };

  const stopScanning = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setIsScanning(false);
  };

  const handleClose = () => {
    stopScanning();
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Scan Barcode / QR Code</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          {!isScanning ? (
            <div className="text-center py-8">
              <div className="inline-flex items-center justify-center w-20 h-20 bg-primary/10 rounded-full mb-4">
                <Camera className="w-10 h-10 text-primary" />
              </div>
              <p className="text-muted-foreground mb-4">
                Click the button below to start scanning
              </p>
              <Button onClick={startScanning}>
                <Camera className="w-4 h-4 mr-2" />
                Start Camera
              </Button>
            </div>
          ) : (
            <div className="relative">
              <video
                ref={videoRef}
                className="w-full rounded-lg border"
                style={{ maxHeight: '400px' }}
              />
              <Button
                onClick={stopScanning}
                variant="destructive"
                size="sm"
                className="absolute top-2 right-2"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          )}

          {error && (
            <div className="p-4 bg-destructive/10 text-destructive rounded-lg text-sm">
              {error}
            </div>
          )}

          <div className="text-xs text-muted-foreground text-center">
            <p>Point your camera at a QR code or barcode</p>
            <p className="mt-1">The product will be automatically added to your cart</p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
