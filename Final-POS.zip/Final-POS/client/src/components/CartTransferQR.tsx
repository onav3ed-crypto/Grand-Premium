import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { QrCode, Download, Clock, AlertTriangle } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import QRCode from 'qrcode';
import { addCartTransfer, getCartTransfers, updateCartTransfer } from '@/lib/indexedDB';

interface CartTransferQRProps {
  cart: any[];
  onRecover?: (cart: any[]) => void;
}

export function CartTransferQR({ cart, onRecover }: CartTransferQRProps) {
  const [showDialog, setShowDialog] = useState(false);
  const [qrDataURL, setQrDataURL] = useState('');
  const [transferToken, setTransferToken] = useState('');
  const [expiryHours, setExpiryHours] = useState(24);
  const [maxUses, setMaxUses] = useState(1);
  const [recoveryToken, setRecoveryToken] = useState('');
  const [showRecovery, setShowRecovery] = useState(false);
  const { toast } = useToast();

  const generateCartQR = async () => {
    if (cart.length === 0) {
      toast({
        title: 'Empty Cart',
        description: 'Add items to cart before generating QR',
        variant: 'destructive',
      });
      return;
    }

    const token = `CART-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`.toUpperCase();
    const expiresAt = new Date(Date.now() + expiryHours * 60 * 60 * 1000).toISOString();

    const transfer = {
      id: crypto.randomUUID(),
      token,
      cartData: JSON.stringify(cart),
      createdAt: new Date().toISOString(),
      expiresAt,
      maxUses,
      usageCount: 0,
      blacklisted: false,
    };

    await addCartTransfer(transfer);

    const qrData = `CART_TRANSFER:${token}`;
    const dataURL = await QRCode.toDataURL(qrData, {
      width: 400,
      margin: 2,
      color: {
        dark: '#000000',
        light: '#FFFFFF',
      },
    });

    setQrDataURL(dataURL);
    setTransferToken(token);
    setShowDialog(true);

    toast({
      title: 'Cart QR Generated',
      description: `Valid for ${expiryHours} hours, max ${maxUses} use(s)`,
    });
  };

  const downloadQR = () => {
    const link = document.createElement('a');
    link.href = qrDataURL;
    link.download = `cart-transfer-${transferToken}.png`;
    link.click();

    toast({
      title: 'QR Code Downloaded',
      description: 'Cart transfer QR saved successfully',
    });
  };

  const recoverCart = async () => {
    if (!recoveryToken.trim()) {
      toast({
        title: 'Error',
        description: 'Please enter a transfer token',
        variant: 'destructive',
      });
      return;
    }

    const transfers = await getCartTransfers();
    const transfer = transfers.find((t: any) => t.token === recoveryToken.toUpperCase());

    if (!transfer) {
      toast({
        title: 'Invalid Token',
        description: 'Transfer token not found',
        variant: 'destructive',
      });
      return;
    }

    if (transfer.blacklisted) {
      toast({
        title: 'Blacklisted',
        description: 'This transfer has been blacklisted and cannot be used',
        variant: 'destructive',
      });
      return;
    }

    if (new Date(transfer.expiresAt) < new Date()) {
      toast({
        title: 'Expired',
        description: 'This transfer has expired',
        variant: 'destructive',
      });
      return;
    }

    if (transfer.usageCount >= transfer.maxUses) {
      toast({
        title: 'Usage Limit Reached',
        description: 'This transfer has reached its maximum usage limit',
        variant: 'destructive',
      });
      return;
    }

    const recoveredCart = JSON.parse(transfer.cartData);
    
    await updateCartTransfer(transfer.id, {
      usageCount: transfer.usageCount + 1,
    });

    if (onRecover) {
      onRecover(recoveredCart);
    }

    toast({
      title: 'Cart Recovered',
      description: `${recoveredCart.length} items restored to cart`,
    });

    setShowRecovery(false);
    setRecoveryToken('');
  };

  const blacklistTransfer = async (token: string) => {
    const transfers = await getCartTransfers();
    const transfer = transfers.find((t: any) => t.token === token);
    
    if (transfer) {
      await updateCartTransfer(transfer.id, {
        blacklisted: true,
      });

      toast({
        title: 'Transfer Blacklisted',
        description: 'This transfer can no longer be used',
      });
    }
  };

  return (
    <div>
      <div className="flex gap-2">
        <Button onClick={generateCartQR} variant="outline" size="sm">
          <QrCode className="w-4 h-4 mr-2" />
          Generate Cart QR
        </Button>
        <Button onClick={() => setShowRecovery(true)} variant="outline" size="sm">
          Recover Cart
        </Button>
      </div>

      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Cart Transfer QR Code</DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div className="bg-white p-6 rounded-lg flex justify-center">
              {qrDataURL && <img src={qrDataURL} alt="Cart Transfer QR" className="w-64 h-64" />}
            </div>

            <div className="space-y-2">
              <div className="p-3 bg-muted rounded-lg">
                <p className="text-xs text-muted-foreground mb-1">Transfer Token</p>
                <p className="font-mono font-bold">{transferToken}</p>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="p-3 bg-muted rounded-lg">
                  <div className="flex items-center gap-2 text-muted-foreground mb-1">
                    <Clock className="w-3 h-3" />
                    <p className="text-xs">Expires In</p>
                  </div>
                  <p className="text-sm font-medium">{expiryHours} hours</p>
                </div>

                <div className="p-3 bg-muted rounded-lg">
                  <div className="flex items-center gap-2 text-muted-foreground mb-1">
                    <AlertTriangle className="w-3 h-3" />
                    <p className="text-xs">Max Uses</p>
                  </div>
                  <p className="text-sm font-medium">{maxUses}</p>
                </div>
              </div>

              <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                <p className="text-sm text-blue-700 dark:text-blue-400">
                  <strong>Items in Cart:</strong> {cart.length}
                </p>
                <p className="text-xs text-blue-600 dark:text-blue-500 mt-1">
                  Scan this QR code or enter the token to recover this cart
                </p>
              </div>
            </div>

            <div className="flex gap-2">
              <Button onClick={downloadQR} className="flex-1">
                <Download className="w-4 h-4 mr-2" />
                Download QR
              </Button>
              <Button onClick={() => blacklistTransfer(transferToken)} variant="destructive">
                Blacklist
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={showRecovery} onOpenChange={setShowRecovery}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Recover Cart</DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <Label>Transfer Token</Label>
              <Input
                value={recoveryToken}
                onChange={(e) => setRecoveryToken(e.target.value.toUpperCase())}
                placeholder="CART-XXXXXXXXXX"
                className="font-mono mt-1"
              />
            </div>

            <div className="p-3 bg-muted rounded-lg">
              <p className="text-sm text-muted-foreground">
                Enter the cart transfer token to recover items from a previous session
              </p>
            </div>

            <div className="flex gap-2">
              <Button variant="outline" onClick={() => setShowRecovery(false)} className="flex-1">
                Cancel
              </Button>
              <Button onClick={recoverCart} className="flex-1">
                Recover Cart
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <div className="mt-4">
        <Card className="p-4 bg-muted/50">
          <div className="flex items-center justify-between mb-2">
            <Label>QR Settings</Label>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-xs">Expiry (hours)</Label>
              <Input
                type="number"
                value={expiryHours}
                onChange={(e) => setExpiryHours(parseInt(e.target.value))}
                min={1}
                max={168}
                className="mt-1"
              />
            </div>
            <div>
              <Label className="text-xs">Max Uses</Label>
              <Input
                type="number"
                value={maxUses}
                onChange={(e) => setMaxUses(parseInt(e.target.value))}
                min={1}
                max={100}
                className="mt-1"
              />
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
