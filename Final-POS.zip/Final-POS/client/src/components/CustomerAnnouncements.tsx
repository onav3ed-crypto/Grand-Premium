import { useState, useEffect } from 'react';
import { storage, Announcement } from '@/lib/storage';
import { Card } from './ui/card';
import { Megaphone } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

export function CustomerAnnouncements() {
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);

  useEffect(() => {
    const allAnnouncements = storage.getAnnouncements();
    setAnnouncements(allAnnouncements.sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    ));
  }, []);

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold">Announcements</h2>
      
      {announcements.length === 0 ? (
        <Card className="p-8 text-center text-muted-foreground">
          No announcements at this time.
        </Card>
      ) : (
        <div className="space-y-4">
          {announcements.map((announcement) => (
            <Card key={announcement.id} className="p-6">
              <div className="flex items-start gap-4">
                <div className="p-2 bg-primary/10 rounded-lg">
                  <Megaphone className="w-6 h-6 text-primary" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-lg mb-2">{announcement.title}</h3>
                  <p className="text-muted-foreground whitespace-pre-wrap">{announcement.message}</p>
                  <p className="text-sm text-muted-foreground mt-4">
                    {formatDistanceToNow(new Date(announcement.createdAt), { addSuffix: true })}
                  </p>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
