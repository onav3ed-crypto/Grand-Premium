import { Card } from '@/components/ui/card';
import { TrendingUp, DollarSign, ShoppingBag, Users, ArrowUp, Package, AlertTriangle } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { storage } from '@/lib/storage';

export function Dashboard() {
  const orders = storage.getOrders().filter(o => o.status === 'completed');
  const customers = storage.getCustomers();
  const products = storage.getProducts().filter(p => !p.archived);

  // Calculate stats
  const totalRevenue = orders.reduce((sum, o) => sum + o.total, 0);
  const totalProfit = orders.reduce((sum, o) => sum + o.profit, 0);
  const totalOrders = orders.length;
  const avgOrderValue = totalOrders > 0 ? totalRevenue / totalOrders : 0;
  
  // Get today's data
  const today = new Date().toISOString().split('T')[0];
  const todayOrders = orders.filter(o => o.createdAt.startsWith(today));
  const todayRevenue = todayOrders.reduce((sum, o) => sum + o.total, 0);

  // Weekly sales data (last 7 days)
  const salesData = [];
  for (let i = 6; i >= 0; i--) {
    const date = new Date();
    date.setDate(date.getDate() - i);
    const dateStr = date.toISOString().split('T')[0];
    const dayOrders = orders.filter(o => o.createdAt.startsWith(dateStr));
    const dayRevenue = dayOrders.reduce((sum, o) => sum + o.total, 0);
    
    salesData.push({
      day: date.toLocaleDateString('en-US', { weekday: 'short' }),
      sales: dayRevenue,
      orders: dayOrders.length,
    });
  }

  // Top products by revenue
  const productSales = new Map<string, { name: string; quantity: number; revenue: number }>();
  orders.forEach(order => {
    order.items.forEach(item => {
      const existing = productSales.get(item.productId);
      const itemTotal = (item.price * item.quantity) * (1 - item.discount / 100);
      if (existing) {
        existing.quantity += item.quantity;
        existing.revenue += itemTotal;
      } else {
        productSales.set(item.productId, {
          name: item.name,
          quantity: item.quantity,
          revenue: itemTotal,
        });
      }
    });
  });
  
  const topProducts = Array.from(productSales.values())
    .sort((a, b) => b.revenue - a.revenue)
    .slice(0, 5);

  const lowStockProducts = products.filter(p => p.stock <= p.lowStockThreshold && p.stock > 0);
  const outOfStockProducts = products.filter(p => p.stock === 0);
  const inventoryValue = products.reduce((sum, p) => sum + (p.price * p.stock), 0);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Dashboard</h1>
        <p className="text-muted-foreground mt-1">Overview of your business performance</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-primary/10 rounded-lg">
              <DollarSign className="w-6 h-6 text-primary" />
            </div>
          </div>
          <div className="space-y-1">
            <p className="text-sm text-muted-foreground">Total Revenue</p>
            <p className="text-2xl font-bold" data-testid="metric-total-sales">${totalRevenue.toFixed(2)}</p>
            <p className="text-xs text-muted-foreground">All time</p>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-chart-2/10 rounded-lg">
              <ShoppingBag className="w-6 h-6 text-chart-2" />
            </div>
          </div>
          <div className="space-y-1">
            <p className="text-sm text-muted-foreground">Total Orders</p>
            <p className="text-2xl font-bold" data-testid="metric-total-orders">{totalOrders}</p>
            <p className="text-xs text-muted-foreground">All time</p>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-chart-4/10 rounded-lg">
              <TrendingUp className="w-6 h-6 text-chart-4" />
            </div>
          </div>
          <div className="space-y-1">
            <p className="text-sm text-muted-foreground">Total Profit</p>
            <p className="text-2xl font-bold text-chart-2" data-testid="metric-total-profit">${totalProfit.toFixed(2)}</p>
            <p className="text-xs text-muted-foreground">All time</p>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-chart-3/10 rounded-lg">
              <Users className="w-6 h-6 text-chart-3" />
            </div>
          </div>
          <div className="space-y-1">
            <p className="text-sm text-muted-foreground">Customers</p>
            <p className="text-2xl font-bold" data-testid="metric-total-customers">{customers.length}</p>
            <p className="text-xs text-muted-foreground">Registered</p>
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2 p-6">
          <h3 className="font-semibold text-lg mb-4">Sales Overview (Last 7 Days)</h3>
          {salesData.length > 0 && salesData.some(d => d.sales > 0) ? (
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={salesData}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis dataKey="day" className="text-xs" />
                <YAxis className="text-xs" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px'
                  }}
                />
                <Bar dataKey="sales" fill="hsl(var(--primary))" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[300px] flex items-center justify-center text-muted-foreground">
              <div className="text-center">
                <ShoppingBag className="w-12 h-12 mx-auto mb-3 opacity-50" />
                <p>No sales data yet</p>
                <p className="text-sm mt-1">Start making sales to see charts</p>
              </div>
            </div>
          )}
        </Card>

        <Card className="p-6">
          <h3 className="font-semibold text-lg mb-4">Top Products</h3>
          {topProducts.length > 0 ? (
            <div className="space-y-4">
              {topProducts.map((product, index) => (
                <div key={product.name} className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-sm font-semibold text-primary">
                    {index + 1}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium truncate">{product.name}</p>
                    <p className="text-sm text-muted-foreground">{product.quantity} sold</p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold">${product.revenue.toFixed(0)}</p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              <Package className="w-12 h-12 mx-auto mb-3 opacity-50" />
              <p className="text-sm">No products sold yet</p>
            </div>
          )}
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="p-6">
          <h3 className="font-semibold text-lg mb-4">Inventory Status</h3>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-muted-foreground">Total Products</span>
              <span className="font-semibold text-lg">{products.length}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-muted-foreground">Inventory Value</span>
              <span className="font-semibold text-lg">${inventoryValue.toFixed(0)}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-muted-foreground">Low Stock Items</span>
              <Badge variant={lowStockProducts.length > 0 ? 'default' : 'outline'}>
                <AlertTriangle className="w-3 h-3 mr-1" />
                {lowStockProducts.length}
              </Badge>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-muted-foreground">Out of Stock</span>
              <Badge variant={outOfStockProducts.length > 0 ? 'destructive' : 'outline'}>
                {outOfStockProducts.length}
              </Badge>
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <h3 className="font-semibold text-lg mb-4">Today's Stats</h3>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-muted-foreground">Today's Revenue</span>
              <span className="font-semibold text-lg">${todayRevenue.toFixed(2)}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-muted-foreground">Today's Orders</span>
              <span className="font-semibold text-lg">{todayOrders.length}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-muted-foreground">Avg Order Value</span>
              <span className="font-semibold text-lg">${avgOrderValue.toFixed(2)}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-muted-foreground">Total Customers</span>
              <span className="font-semibold">{customers.length}</span>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
