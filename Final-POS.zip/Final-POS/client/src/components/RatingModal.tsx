import { useState } from 'react';
import { storage, Rating } from '@/lib/storage';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { Star, ExternalLink } from 'lucide-react';

interface Props {
  orderId: string;
  isOpen: boolean;
  onClose: () => void;
}

export function RatingModal({ orderId, isOpen, onClose }: Props) {
  const [rating, setRating] = useState(0);
  const [hoveredRating, setHoveredRating] = useState(0);
  const [feedback, setFeedback] = useState('');
  const settings = storage.getSettings();

  const submitRating = () => {
    if (rating === 0) return;

    const ratingData: Rating = {
      id: crypto.randomUUID(),
      orderId,
      rating,
      feedback: feedback.trim() || undefined,
      createdAt: new Date().toISOString(),
    };

    const allRatings = storage.getRatings();
    allRatings.push(ratingData);
    storage.saveRatings(allRatings);

    const orders = storage.getOrders();
    const order = orders.find(o => o.id === orderId);
    if (order) {
      order.rating = rating;
      storage.saveOrders(orders);
    }

    onClose();
  };

  const openSurvey = () => {
    const url = settings.surveyFormUrl || 'https://docs.google.com/forms';
    window.open(url, '_blank');
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Rate Your Experience</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6 py-4">
          <div className="text-center">
            <p className="text-muted-foreground mb-4">How would you rate your experience?</p>
            <div className="flex justify-center gap-2 mb-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  onClick={() => setRating(star)}
                  onMouseEnter={() => setHoveredRating(star)}
                  onMouseLeave={() => setHoveredRating(0)}
                  className="transition-transform hover:scale-110"
                >
                  <Star
                    className={`w-12 h-12 ${
                      star <= (hoveredRating || rating)
                        ? 'text-yellow-500 fill-yellow-500'
                        : 'text-gray-300'
                    }`}
                  />
                </button>
              ))}
            </div>
            {rating > 0 && (
              <p className="text-sm text-muted-foreground mt-2">
                {rating === 5 && 'Excellent!'}
                {rating === 4 && 'Great!'}
                {rating === 3 && 'Good'}
                {rating === 2 && 'Fair'}
                {rating === 1 && 'Poor'}
              </p>
            )}
          </div>

          <div>
            <label className="text-sm font-medium mb-2 block">Additional Feedback (Optional)</label>
            <Textarea
              placeholder="Tell us more about your experience..."
              value={feedback}
              onChange={(e) => setFeedback(e.target.value)}
              rows={3}
            />
          </div>

          <Button 
            onClick={openSurvey} 
            variant="outline" 
            className="w-full"
          >
            <ExternalLink className="w-4 h-4 mr-2" />
            Fill Out Detailed Survey
          </Button>

          <div className="flex gap-2">
            <Button variant="outline" onClick={onClose} className="flex-1">
              Skip
            </Button>
            <Button onClick={submitRating} disabled={rating === 0} className="flex-1">
              Submit Rating
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
