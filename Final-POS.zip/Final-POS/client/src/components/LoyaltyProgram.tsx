import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Tag, Award, TrendingUp, Gift, Users } from 'lucide-react';
import { storage } from '@/lib/storage';
import { useToast } from '@/hooks/use-toast';

export function LoyaltyProgram() {
  const settings = storage.getSettings();
  const [pointsPerDollar, setPointsPerDollar] = useState(settings.loyaltyRate || 10);
  const [bronzeThreshold, setBronzeThreshold] = useState(settings.tierThresholds?.bronze || 0);
  const [silverThreshold, setSilverThreshold] = useState(settings.tierThresholds?.silver || 100);
  const [goldThreshold, setGoldThreshold] = useState(settings.tierThresholds?.gold || 500);
  const [platinumThreshold, setPlatinumThreshold] = useState(settings.tierThresholds?.platinum || 1000);
  const { toast } = useToast();

  const customers = storage.getCustomers();
  const tierCounts = {
    Bronze: customers.filter(c => c.tier === 'Bronze').length,
    Silver: customers.filter(c => c.tier === 'Silver').length,
    Gold: customers.filter(c => c.tier === 'Gold').length,
    Platinum: customers.filter(c => c.tier === 'Platinum').length,
  };

  const handleSave = () => {
    storage.updateSettings({
      loyaltyRate: pointsPerDollar,
      tierThresholds: {
        bronze: bronzeThreshold,
        silver: silverThreshold,
        gold: goldThreshold,
        platinum: platinumThreshold,
      },
    });
    toast({
      title: 'Loyalty Settings Saved',
      description: 'Your loyalty program configuration has been updated',
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Loyalty Program</h1>
          <p className="text-muted-foreground mt-1">Manage customer rewards and loyalty tiers</p>
        </div>
        <Button onClick={handleSave}>
          Save Changes
        </Button>
      </div>

      <Tabs defaultValue="overview" className="w-full">
        <TabsList>
          <TabsTrigger value="overview">
            <Award className="w-4 h-4 mr-2" />
            Overview
          </TabsTrigger>
          <TabsTrigger value="tiers">
            <TrendingUp className="w-4 h-4 mr-2" />
            Tier Settings
          </TabsTrigger>
          <TabsTrigger value="members">
            <Users className="w-4 h-4 mr-2" />
            Members
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card className="p-6">
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-semibold">Bronze</h3>
                <Badge variant="outline" className="bg-amber-900/20">Bronze</Badge>
              </div>
              <p className="text-3xl font-bold">{tierCounts.Bronze}</p>
              <p className="text-sm text-muted-foreground mt-1">Members</p>
            </Card>
            <Card className="p-6">
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-semibold">Silver</h3>
                <Badge variant="outline" className="bg-gray-400/20">Silver</Badge>
              </div>
              <p className="text-3xl font-bold">{tierCounts.Silver}</p>
              <p className="text-sm text-muted-foreground mt-1">Members</p>
            </Card>
            <Card className="p-6">
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-semibold">Gold</h3>
                <Badge variant="outline" className="bg-yellow-500/20">Gold</Badge>
              </div>
              <p className="text-3xl font-bold">{tierCounts.Gold}</p>
              <p className="text-sm text-muted-foreground mt-1">Members</p>
            </Card>
            <Card className="p-6">
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-semibold">Platinum</h3>
                <Badge variant="outline" className="bg-purple-500/20">Platinum</Badge>
              </div>
              <p className="text-3xl font-bold">{tierCounts.Platinum}</p>
              <p className="text-sm text-muted-foreground mt-1">Members</p>
            </Card>
          </div>

          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4">Total Members</h3>
            <p className="text-5xl font-bold">{customers.length}</p>
            <p className="text-sm text-muted-foreground mt-2">
              Total loyalty points distributed: {customers.reduce((sum, c) => sum + c.points, 0).toLocaleString()}
            </p>
          </Card>
        </TabsContent>

        <TabsContent value="tiers" className="space-y-6">
          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4">Points Configuration</h3>
            <div className="space-y-4">
              <div>
                <Label>Points Per Dollar Spent</Label>
                <Input
                  type="number"
                  min="1"
                  value={pointsPerDollar}
                  onChange={(e) => setPointsPerDollar(parseInt(e.target.value) || 1)}
                  className="mt-1"
                />
                <p className="text-sm text-muted-foreground mt-1">
                  Customers earn {pointsPerDollar} points for every $1 spent
                </p>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4">Tier Thresholds (Points Required)</h3>
            <div className="space-y-4">
              <div>
                <Label>Bronze Tier (Starting)</Label>
                <Input
                  type="number"
                  min="0"
                  value={bronzeThreshold}
                  onChange={(e) => setBronzeThreshold(parseInt(e.target.value) || 0)}
                  className="mt-1"
                />
              </div>
              <div>
                <Label>Silver Tier</Label>
                <Input
                  type="number"
                  min="0"
                  value={silverThreshold}
                  onChange={(e) => setSilverThreshold(parseInt(e.target.value) || 0)}
                  className="mt-1"
                />
              </div>
              <div>
                <Label>Gold Tier</Label>
                <Input
                  type="number"
                  min="0"
                  value={goldThreshold}
                  onChange={(e) => setGoldThreshold(parseInt(e.target.value) || 0)}
                  className="mt-1"
                />
              </div>
              <div>
                <Label>Platinum Tier</Label>
                <Input
                  type="number"
                  min="0"
                  value={platinumThreshold}
                  onChange={(e) => setPlatinumThreshold(parseInt(e.target.value) || 0)}
                  className="mt-1"
                />
              </div>
            </div>
          </Card>

          <Card className="p-6 bg-muted/50">
            <h3 className="text-lg font-semibold mb-2">
              <Gift className="w-5 h-5 inline mr-2" />
              Tier Benefits
            </h3>
            <ul className="space-y-2 text-sm">
              <li>• <strong>Bronze:</strong> Earn points on purchases</li>
              <li>• <strong>Silver:</strong> 5% discount on all items</li>
              <li>• <strong>Gold:</strong> 10% discount + early access to deals</li>
              <li>• <strong>Platinum:</strong> 15% discount + exclusive offers + birthday rewards</li>
            </ul>
          </Card>
        </TabsContent>

        <TabsContent value="members" className="space-y-6">
          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4">Loyalty Members</h3>
            <ScrollArea className="h-[500px]">
              <div className="space-y-2">
                {customers.length === 0 ? (
                  <div className="text-center text-muted-foreground py-12">
                    <Users className="w-16 h-16 mx-auto mb-4 opacity-50" />
                    <p>No loyalty members yet</p>
                  </div>
                ) : (
                  customers
                    .sort((a, b) => b.points - a.points)
                    .map((customer) => (
                      <Card key={customer.id} className="p-4 hover:bg-muted/50 transition-colors">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="font-semibold">{customer.name}</p>
                            <p className="text-sm text-muted-foreground">{customer.email || customer.phone}</p>
                          </div>
                          <div className="text-right">
                            <Badge variant="outline">{customer.tier}</Badge>
                            <p className="text-sm font-semibold mt-1">{customer.points.toLocaleString()} pts</p>
                            <p className="text-xs text-muted-foreground">
                              ${customer.totalSpent.toFixed(2)} spent
                            </p>
                          </div>
                        </div>
                      </Card>
                    ))
                )}
              </div>
            </ScrollArea>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
