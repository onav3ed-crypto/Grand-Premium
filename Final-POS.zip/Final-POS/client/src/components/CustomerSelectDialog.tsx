import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Search, Plus, Star, Trophy, Award, Crown } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { storage, type Customer } from '@/lib/storage';
import { AddCustomerDialog } from './AddCustomerDialog';

interface CustomerSelectDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSelect: (customer: Customer) => void;
}

const tierIcons = {
  Bronze: Star,
  Silver: Trophy,
  Gold: Award,
  Platinum: Crown,
};

const tierColors = {
  Bronze: 'bg-orange-500/10 text-orange-700 dark:text-orange-400',
  Silver: 'bg-slate-500/10 text-slate-700 dark:text-slate-400',
  Gold: 'bg-yellow-500/10 text-yellow-700 dark:text-yellow-400',
  Platinum: 'bg-purple-500/10 text-purple-700 dark:text-purple-400',
};

export function CustomerSelectDialog({ open, onOpenChange, onSelect }: CustomerSelectDialogProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddCustomer, setShowAddCustomer] = useState(false);

  const customers = storage.getCustomers();
  const filteredCustomers = customers.filter(customer =>
    customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    customer.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    customer.phone?.includes(searchTerm)
  );

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Select Customer</DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  data-testid="input-search-customer-dialog"
                  placeholder="Search by name, email, or phone..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Button onClick={() => setShowAddCustomer(true)} data-testid="button-add-customer-dialog">
                <Plus className="w-4 h-4 mr-2" />
                Add New
              </Button>
            </div>

            <ScrollArea className="h-[400px]">
              <div className="space-y-2">
                {filteredCustomers.length === 0 ? (
                  <div className="text-center py-12 text-muted-foreground">
                    <p>No customers found</p>
                  </div>
                ) : (
                  filteredCustomers.map((customer) => {
                    const TierIcon = tierIcons[customer.tier];
                    return (
                      <Card
                        key={customer.id}
                        className="p-4 hover-elevate cursor-pointer"
                        onClick={() => onSelect(customer)}
                        data-testid={`customer-${customer.id}`}
                      >
                        <div className="flex items-center gap-4">
                          <Avatar>
                            <AvatarFallback className="bg-primary/10 text-primary font-semibold">
                              {customer.name.split(' ').map(n => n[0]).join('')}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1">
                              <h4 className="font-medium truncate">{customer.name}</h4>
                              <Badge className={tierColors[customer.tier]}>
                                <TierIcon className="w-3 h-3 mr-1" />
                                {customer.tier}
                              </Badge>
                            </div>
                            <p className="text-sm text-muted-foreground truncate">
                              {customer.email || customer.phone || 'No contact info'}
                            </p>
                          </div>
                          <div className="text-right">
                            <p className="font-semibold text-chart-2">${customer.balance.toFixed(2)}</p>
                            <p className="text-xs text-muted-foreground">{customer.points} pts</p>
                          </div>
                        </div>
                      </Card>
                    );
                  })
                )}
              </div>
            </ScrollArea>
          </div>
        </DialogContent>
      </Dialog>

      <AddCustomerDialog
        open={showAddCustomer}
        onOpenChange={setShowAddCustomer}
        onAdded={(customer: Customer) => {
          setShowAddCustomer(false);
          onSelect(customer);
        }}
      />
    </>
  );
}
