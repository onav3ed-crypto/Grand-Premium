import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { useAuth } from './AuthContext';
import { ShoppingCart, Lock, User } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export function LoginPage() {
  const [screen, setScreen] = useState<'role' | 'login' | 'register'>('role');
  const [selectedRole, setSelectedRole] = useState<'cashier' | 'customer' | null>(null);
  const [pin, setPin] = useState('');
  const [name, setName] = useState('');
  const { login, register } = useAuth();
  const { toast } = useToast();

  const handleLogin = () => {
    if (pin.length !== 4) {
      toast({
        title: 'Invalid PIN',
        description: 'PIN must be 4 digits',
        variant: 'destructive',
      });
      return;
    }

    if (!selectedRole) return;

    const success = login(pin, selectedRole);
    if (success) {
      toast({
        title: 'Welcome!',
        description: 'Login successful',
      });
    } else {
      toast({
        title: 'Login Failed',
        description: 'Invalid PIN. Please try again.',
        variant: 'destructive',
      });
      setPin('');
    }
  };

  const handleRegister = () => {
    if (!name.trim()) {
      toast({
        title: 'Name Required',
        description: 'Please enter your name',
        variant: 'destructive',
      });
      return;
    }

    if (pin.length !== 4) {
      toast({
        title: 'Invalid PIN',
        description: 'PIN must be 4 digits',
        variant: 'destructive',
      });
      return;
    }

    const success = register(name, pin);
    if (success) {
      toast({
        title: 'Registration Successful!',
        description: 'You can now use the POS system',
      });
    } else {
      toast({
        title: 'Registration Failed',
        description: 'This PIN is already in use',
        variant: 'destructive',
      });
      setPin('');
    }
  };

  const handlePinInput = (value: string) => {
    const digits = value.replace(/\D/g, '').slice(0, 4);
    setPin(digits);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (screen === 'login') {
      handleLogin();
    } else {
      handleRegister();
    }
  };

  if (screen === 'role') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/10 to-background p-6">
        <Card className="w-full max-w-md p-8">
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-primary/10 rounded-full mb-4">
              <ShoppingCart className="w-8 h-8 text-primary" />
            </div>
            <h1 className="text-3xl font-bold">POS System</h1>
            <p className="text-muted-foreground mt-2">Select your role to continue</p>
          </div>

          <div className="space-y-4">
            <Button
              onClick={() => {
                setSelectedRole('cashier');
                setScreen('login');
              }}
              className="w-full h-20 text-lg"
              variant="outline"
            >
              <User className="mr-3 w-6 h-6" />
              Cashier / Staff
            </Button>
            <Button
              onClick={() => {
                setSelectedRole('customer');
                setScreen('login');
              }}
              className="w-full h-20 text-lg"
              variant="outline"
            >
              <ShoppingCart className="mr-3 w-6 h-6" />
              Customer
            </Button>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/10 to-background p-6">
      <Card className="w-full max-w-md p-8">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-primary/10 rounded-full mb-4">
            <ShoppingCart className="w-8 h-8 text-primary" />
          </div>
          <h1 className="text-3xl font-bold">POS System</h1>
          <p className="text-muted-foreground mt-2">
            {screen === 'login' 
              ? `${selectedRole === 'cashier' ? 'Cashier' : 'Customer'} Login`
              : 'Create your cashier account'}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {screen === 'register' && (
            <div>
              <Label htmlFor="name" className="text-base font-medium">
                <User className="w-4 h-4 inline mr-2" />
                Full Name
              </Label>
              <Input
                id="name"
                data-testid="input-cashier-name"
                placeholder="Enter your name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="mt-2 h-12"
                autoFocus={screen === 'register'}
              />
            </div>
          )}

          <div>
            <Label htmlFor="pin" className="text-base font-medium">
              <Lock className="w-4 h-4 inline mr-2" />
              4-Digit PIN
            </Label>
            <Input
              id="pin"
              data-testid="input-pin"
              type="password"
              placeholder="••••"
              value={pin}
              onChange={(e) => handlePinInput(e.target.value)}
              className="mt-2 h-16 text-2xl text-center tracking-widest"
              maxLength={4}
              autoFocus={screen === 'login'}
            />
            <div className="flex gap-1 justify-center mt-3">
              {[0, 1, 2, 3].map((i) => (
                <div
                  key={i}
                  className={`w-3 h-3 rounded-full ${
                    pin.length > i ? 'bg-primary' : 'bg-muted'
                  }`}
                />
              ))}
            </div>
          </div>

          <Button
            type="submit"
            className="w-full"
            size="lg"
            data-testid={screen === 'login' ? 'button-login' : 'button-register-submit'}
          >
            {screen === 'login' ? 'Login' : 'Register'}
          </Button>
        </form>

        <div className="mt-6 text-center">
          <Button
            variant="ghost"
            onClick={() => setScreen('role')}
            className="mr-2"
          >
            ← Back to Role Selection
          </Button>
          {selectedRole === 'cashier' && (
            <Button
              variant="ghost"
              onClick={() => {
                setScreen(screen === 'login' ? 'register' : 'login');
                setPin('');
                setName('');
              }}
              data-testid={screen === 'login' ? 'button-switch-register' : 'button-switch-login'}
            >
              {screen === 'login' ? "Don't have an account? Register" : 'Already have an account? Login'}
            </Button>
          )}
        </div>

        {screen === 'login' && (
          <div className="mt-6 p-4 bg-muted/50 rounded-lg">
            <p className="text-sm text-muted-foreground text-center">
              {selectedRole === 'cashier' 
                ? <>Default admin PIN: <span className="font-mono font-semibold text-foreground">1234</span></>
                : 'Enter your customer PIN provided by the cashier'}
            </p>
          </div>
        )}
      </Card>
    </div>
  );
}
