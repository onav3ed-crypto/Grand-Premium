import { useState } from 'react';
import { useAuth } from './AuthContext';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { User, Package, Bell, MessageSquare, Truck, Gift, LogOut, Settings, Star } from 'lucide-react';
import { CustomerDeals } from './CustomerDeals';
import { CustomerAnnouncements } from './CustomerAnnouncements';
import { CustomerNotifications } from './CustomerNotifications';
import { CustomerMessages } from './CustomerMessages';
import { CustomerOnlineDelivery } from './CustomerOnlineDelivery';
import { CustomerAccountDetails } from './CustomerAccountDetails';
import { CustomerLoyalty } from './CustomerLoyalty';

export function CustomerPortal() {
  const { currentCustomer, logout } = useAuth();
  const [activeTab, setActiveTab] = useState('account');

  if (!currentCustomer) return null;

  const tabs = [
    { id: 'account', label: 'Account', icon: User },
    { id: 'deals', label: 'Deals', icon: Package },
    { id: 'announcements', label: 'Announcements', icon: Bell },
    { id: 'notifications', label: 'Notifications', icon: Bell },
    { id: 'messages', label: 'Messages', icon: MessageSquare },
    { id: 'delivery', label: 'Online Delivery', icon: Truck },
    { id: 'loyalty', label: 'Loyalty', icon: Star },
  ];

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-card sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold">Customer Portal</h1>
            <p className="text-sm text-muted-foreground">Welcome, {currentCustomer.name}</p>
          </div>
          <Button variant="ghost" onClick={logout}>
            <LogOut className="w-4 h-4 mr-2" />
            Logout
          </Button>
        </div>
      </header>

      <div className="container mx-auto p-4">
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-2 mb-6">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <Button
                key={tab.id}
                variant={activeTab === tab.id ? 'default' : 'outline'}
                onClick={() => setActiveTab(tab.id)}
                className="flex flex-col h-20 gap-2"
              >
                <Icon className="w-5 h-5" />
                <span className="text-xs">{tab.label}</span>
              </Button>
            );
          })}
        </div>

        <div className="mt-6">
          {activeTab === 'account' && <CustomerAccountDetails customer={currentCustomer} />}
          {activeTab === 'deals' && <CustomerDeals />}
          {activeTab === 'announcements' && <CustomerAnnouncements />}
          {activeTab === 'notifications' && <CustomerNotifications customerId={currentCustomer.id} />}
          {activeTab === 'messages' && <CustomerMessages customerId={currentCustomer.id} customerName={currentCustomer.name} />}
          {activeTab === 'delivery' && <CustomerOnlineDelivery />}
          {activeTab === 'loyalty' && <CustomerLoyalty customer={currentCustomer} />}
        </div>
      </div>
    </div>
  );
}
