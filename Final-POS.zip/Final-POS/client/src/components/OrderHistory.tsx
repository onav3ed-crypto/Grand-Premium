import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Search, Receipt, Calendar, DollarSign, Package, User } from 'lucide-react';
import { storage, type Order } from '@/lib/storage';
import { ReceiptPreview } from './ReceiptPreview';

export function OrderHistory() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [showReceipt, setShowReceipt] = useState(false);

  const orders = storage.getOrders().filter(o => o.status === 'completed');
  
  const filteredOrders = orders.filter(order =>
    order.transactionId.toLowerCase().includes(searchTerm.toLowerCase()) ||
    order.customerName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    order.cashierName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const stats = {
    total: orders.length,
    totalRevenue: orders.reduce((sum, o) => sum + o.total, 0),
    totalProfit: orders.reduce((sum, o) => sum + o.profit, 0),
  };

  const handleViewReceipt = (order: Order) => {
    setSelectedOrder(order);
    setShowReceipt(true);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Order History</h1>
          <p className="text-muted-foreground mt-1">View and manage past orders</p>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <Card className="p-6">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-primary/10 rounded-lg">
              <Receipt className="w-6 h-6 text-primary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Total Orders</p>
              <p className="text-2xl font-bold">{stats.total}</p>
            </div>
          </div>
        </Card>
        <Card className="p-6">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-chart-2/10 rounded-lg">
              <DollarSign className="w-6 h-6 text-chart-2" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Total Revenue</p>
              <p className="text-2xl font-bold">${stats.totalRevenue.toFixed(2)}</p>
            </div>
          </div>
        </Card>
        <Card className="p-6">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-chart-4/10 rounded-lg">
              <DollarSign className="w-6 h-6 text-chart-4" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Total Profit</p>
              <p className="text-2xl font-bold text-chart-2">${stats.totalProfit.toFixed(2)}</p>
            </div>
          </div>
        </Card>
      </div>

      <Card className="p-6">
        <div className="relative mb-6">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            data-testid="input-search-order"
            placeholder="Search by transaction ID, customer, or cashier..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>

        <ScrollArea className="h-[600px]">
          <div className="space-y-3">
            {filteredOrders.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">
                <Receipt className="w-12 h-12 mx-auto mb-3 opacity-50" />
                <p>No orders found</p>
              </div>
            ) : (
              filteredOrders.map((order) => (
                <Card key={order.id} className="p-4 hover-elevate">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <Receipt className="w-6 h-6 text-primary" />
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <h3 className="font-semibold text-lg">{order.transactionId}</h3>
                          <div className="flex items-center gap-3 text-sm text-muted-foreground mt-1">
                            <span className="flex items-center gap-1">
                              <Calendar className="w-3 h-3" />
                              {new Date(order.createdAt).toLocaleString()}
                            </span>
                            <span className="flex items-center gap-1">
                              <User className="w-3 h-3" />
                              {order.cashierName}
                            </span>
                            {order.customerName && (
                              <span className="flex items-center gap-1">
                                <User className="w-3 h-3" />
                                {order.customerName}
                              </span>
                            )}
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-2xl font-bold">${order.total.toFixed(2)}</p>
                          <Badge variant="outline" className="mt-1">{order.paymentMethod.toUpperCase()}</Badge>
                        </div>
                      </div>

                      <div className="flex items-center gap-6 text-sm mb-3">
                        <div className="flex items-center gap-1">
                          <Package className="w-4 h-4 text-muted-foreground" />
                          <span>{order.items.length} items</span>
                        </div>
                        <div>
                          Subtotal: <span className="font-medium">${order.subtotal.toFixed(2)}</span>
                        </div>
                        {order.discount > 0 && (
                          <div className="text-chart-2">
                            Discount: <span className="font-medium">-${order.discount.toFixed(2)}</span>
                          </div>
                        )}
                        <div>
                          Tax: <span className="font-medium">${order.tax.toFixed(2)}</span>
                        </div>
                        <div className="text-chart-2">
                          Profit: <span className="font-medium">${order.profit.toFixed(2)}</span>
                        </div>
                      </div>

                      <div className="border-t pt-3">
                        <div className="flex flex-wrap gap-2">
                          {order.items.slice(0, 5).map((item, idx) => (
                            <Badge key={idx} variant="outline">
                              {item.quantity}x {item.name}
                            </Badge>
                          ))}
                          {order.items.length > 5 && (
                            <Badge variant="outline">+{order.items.length - 5} more</Badge>
                          )}
                        </div>
                      </div>
                    </div>

                    <Button
                      variant="outline"
                      onClick={() => handleViewReceipt(order)}
                      data-testid={`button-view-receipt-${order.id}`}
                    >
                      <Receipt className="w-4 h-4 mr-2" />
                      View Receipt
                    </Button>
                  </div>
                </Card>
              ))
            )}
          </div>
        </ScrollArea>
      </Card>

      {selectedOrder && (
        <ReceiptPreview
          open={showReceipt}
          onOpenChange={setShowReceipt}
          order={selectedOrder}
        />
      )}
    </div>
  );
}
