import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Download, Share2 } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { storage } from '@/lib/storage';
import jsPDF from 'jspdf';
import { useToast } from '@/hooks/use-toast';

interface ReceiptPreviewProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  order: any;
}

export function ReceiptPreview({ open, onOpenChange, order }: ReceiptPreviewProps) {
  const settings = storage.getSettings();
  const { toast } = useToast();

  const handleDownloadPDF = () => {
    const doc = new jsPDF();
    const pageWidth = doc.internal.pageSize.getWidth();
    
    // Header
    doc.setFontSize(18);
    doc.setFont('helvetica', 'bold');
    doc.text(settings.storeName, pageWidth / 2, 20, { align: 'center' });
    
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.text(settings.storeAddress, pageWidth / 2, 28, { align: 'center' });
    doc.text(settings.storePhone, pageWidth / 2, 34, { align: 'center' });
    
    // Transaction Info
    let y = 45;
    doc.setFontSize(9);
    doc.text(`Transaction ID: ${order.transactionId}`, 15, y);
    y += 6;
    doc.text(`Date: ${new Date(order.createdAt).toLocaleString()}`, 15, y);
    y += 6;
    doc.text(`Cashier: ${order.cashierName}`, 15, y);
    if (order.customerName) {
      y += 6;
      doc.text(`Customer: ${order.customerName}`, 15, y);
    }
    
    // Items
    y += 10;
    doc.setFont('helvetica', 'bold');
    doc.text('ITEMS', 15, y);
    doc.setFont('helvetica', 'normal');
    y += 6;
    
    order.items.forEach((item: any) => {
      const itemTotal = (item.price * item.quantity) * (1 - item.discount / 100);
      doc.text(item.name, 15, y);
      doc.text(`$${itemTotal.toFixed(2)}`, pageWidth - 15, y, { align: 'right' });
      y += 5;
      doc.setFontSize(8);
      doc.text(`  ${item.quantity} x $${item.price.toFixed(2)}`, 15, y);
      if (item.discount > 0) {
        doc.text(`-${item.discount}%`, pageWidth - 15, y, { align: 'right' });
      }
      doc.setFontSize(9);
      y += 6;
    });
    
    // Totals
    y += 5;
    doc.text(`Subtotal:`, 15, y);
    doc.text(`$${order.subtotal.toFixed(2)}`, pageWidth - 15, y, { align: 'right' });
    y += 6;
    
    if (order.discount > 0) {
      doc.text(`Discount:`, 15, y);
      doc.text(`-$${order.discount.toFixed(2)}`, pageWidth - 15, y, { align: 'right' });
      y += 6;
    }
    
    doc.text(`Tax (${settings.taxRate}%):`, 15, y);
    doc.text(`$${order.tax.toFixed(2)}`, pageWidth - 15, y, { align: 'right' });
    y += 6;
    
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.text(`TOTAL:`, 15, y);
    doc.text(`$${order.total.toFixed(2)}`, pageWidth - 15, y, { align: 'right' });
    
    // Payment info
    y += 10;
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.text(`Payment Method: ${order.paymentMethod.toUpperCase()}`, 15, y);
    
    if (order.paymentDetails.cash) {
      y += 6;
      doc.text(`Tendered: $${order.paymentDetails.cash.toFixed(2)}`, 15, y);
      if (order.paymentDetails.change) {
        y += 6;
        doc.text(`Change: $${order.paymentDetails.change.toFixed(2)}`, 15, y);
      }
    }
    
    // Footer
    y += 15;
    doc.setFontSize(10);
    doc.text(settings.receiptHeader, pageWidth / 2, y, { align: 'center' });
    
    const filename = `receipt-${order.transactionId}-${new Date().toISOString().split('T')[0]}.pdf`;
    doc.save(filename);
  };

  const handleShare = async () => {
    try {
      const doc = new jsPDF();
      const pageWidth = doc.internal.pageSize.getWidth();
      
      doc.setFontSize(18);
      doc.setFont('helvetica', 'bold');
      doc.text(settings.storeName, pageWidth / 2, 20, { align: 'center' });
      
      doc.setFontSize(10);
      doc.setFont('helvetica', 'normal');
      doc.text(settings.storeAddress, pageWidth / 2, 28, { align: 'center' });
      doc.text(settings.storePhone, pageWidth / 2, 34, { align: 'center' });
      
      let y = 45;
      doc.setFontSize(9);
      doc.text(`Transaction ID: ${order.transactionId}`, 15, y);
      y += 6;
      doc.text(`Date: ${new Date(order.createdAt).toLocaleString()}`, 15, y);
      y += 6;
      doc.text(`Cashier: ${order.cashierName}`, 15, y);
      if (order.customerName) {
        y += 6;
        doc.text(`Customer: ${order.customerName}`, 15, y);
      }
      
      y += 10;
      doc.setFont('helvetica', 'bold');
      doc.text('ITEMS', 15, y);
      doc.setFont('helvetica', 'normal');
      y += 6;
      
      order.items.forEach((item: any) => {
        const itemTotal = (item.price * item.quantity) * (1 - item.discount / 100);
        doc.text(item.name, 15, y);
        doc.text(`$${itemTotal.toFixed(2)}`, pageWidth - 15, y, { align: 'right' });
        y += 5;
        doc.setFontSize(8);
        doc.text(`  ${item.quantity} x $${item.price.toFixed(2)}`, 15, y);
        if (item.discount > 0) {
          doc.text(`-${item.discount}%`, pageWidth - 15, y, { align: 'right' });
        }
        doc.setFontSize(9);
        y += 6;
      });
      
      y += 5;
      doc.text(`Subtotal:`, 15, y);
      doc.text(`$${order.subtotal.toFixed(2)}`, pageWidth - 15, y, { align: 'right' });
      y += 6;
      
      if (order.discount > 0) {
        doc.text(`Discount:`, 15, y);
        doc.text(`-$${order.discount.toFixed(2)}`, pageWidth - 15, y, { align: 'right' });
        y += 6;
      }
      
      doc.text(`Tax (${settings.taxRate}%):`, 15, y);
      doc.text(`$${order.tax.toFixed(2)}`, pageWidth - 15, y, { align: 'right' });
      y += 6;
      
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(11);
      doc.text(`TOTAL:`, 15, y);
      doc.text(`$${order.total.toFixed(2)}`, pageWidth - 15, y, { align: 'right' });
      
      y += 10;
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(9);
      doc.text(`Payment Method: ${order.paymentMethod.toUpperCase()}`, 15, y);
      
      if (order.paymentDetails.cash) {
        y += 6;
        doc.text(`Tendered: $${order.paymentDetails.cash.toFixed(2)}`, 15, y);
        if (order.paymentDetails.change) {
          y += 6;
          doc.text(`Change: $${order.paymentDetails.change.toFixed(2)}`, 15, y);
        }
      }
      
      y += 15;
      doc.setFontSize(10);
      doc.text(settings.receiptHeader, pageWidth / 2, y, { align: 'center' });

      const pdfBlob = doc.output('blob');
      const file = new File([pdfBlob], `receipt-${order.transactionId}.pdf`, { type: 'application/pdf' });

      if (navigator.share && navigator.canShare && navigator.canShare({ files: [file] })) {
        await navigator.share({
          files: [file],
          title: `Receipt ${order.transactionId}`,
          text: 'Sales Receipt'
        });
      } else {
        toast({
          title: 'Share Not Available',
          description: 'Your device does not support sharing. PDF downloaded instead.',
          variant: 'default',
        });
        handleDownloadPDF();
      }
    } catch (error) {
      console.error('Share failed:', error);
      toast({
        title: 'Share Failed',
        description: 'Could not share receipt. Try downloading instead.',
        variant: 'destructive',
      });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md max-h-[90vh] flex flex-col">
        <DialogHeader>
          <DialogTitle>Receipt Preview</DialogTitle>
        </DialogHeader>

        <ScrollArea className="flex-1 pr-4">
          <Card className="bg-white dark:bg-card text-foreground p-6 font-mono text-sm" id="receipt-content" style={{ backgroundImage: settings.receiptBackground ? `url(${settings.receiptBackground})` : 'none', backgroundSize: 'cover', backgroundPosition: 'center' }}>
            <div className="text-center mb-6">
            <h2 className="text-xl font-bold mb-2">{settings.storeName}</h2>
            <p className="text-xs">{settings.storeAddress}</p>
            <p className="text-xs">{settings.storePhone}</p>
          </div>

          <div className="border-t border-b border-dashed py-3 mb-4 space-y-1 text-xs">
            <div className="flex justify-between">
              <span>Transaction ID:</span>
              <span>{order.transactionId}</span>
            </div>
            <div className="flex justify-between">
              <span>Date:</span>
              <span>{new Date(order.createdAt).toLocaleString()}</span>
            </div>
            <div className="flex justify-between">
              <span>Cashier:</span>
              <span>{order.cashierName}</span>
            </div>
            {order.customerName && (
              <div className="flex justify-between">
                <span>Customer:</span>
                <span>{order.customerName}</span>
              </div>
            )}
          </div>

          <div className="mb-4">
            <div className="font-bold mb-2 text-xs">ITEMS</div>
            {order.items.map((item: any, index: number) => {
              const itemTotal = (item.price * item.quantity) * (1 - item.discount / 100);
              return (
                <div key={index} className="mb-3">
                  <div className="flex justify-between">
                    <span className="flex-1">{item.name}</span>
                    <span>${itemTotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>  {item.quantity} x ${item.price.toFixed(2)}</span>
                    <span className="space-x-2">
                      {item.discount > 0 && <span>-{item.discount}%</span>}
                      {!item.taxed && <span>TAX FREE</span>}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="border-t border-dashed pt-3 space-y-2">
            <div className="flex justify-between">
              <span>Subtotal:</span>
              <span>${order.subtotal.toFixed(2)}</span>
            </div>
            {order.discount > 0 && (
              <div className="flex justify-between text-chart-2">
                <span>Discount:</span>
                <span>-${order.discount.toFixed(2)}</span>
              </div>
            )}
            <div className="flex justify-between">
              <span>Tax ({settings.taxRate}%):</span>
              <span>${order.tax.toFixed(2)}</span>
            </div>
            <div className="flex justify-between font-bold text-base border-t pt-2">
              <span>TOTAL:</span>
              <span>${order.total.toFixed(2)}</span>
            </div>
          </div>

          <div className="border-t border-dashed mt-4 pt-3 space-y-1 text-xs">
            <div className="flex justify-between">
              <span>Payment Method:</span>
              <span>{order.paymentMethod.toUpperCase()}</span>
            </div>
            {order.paymentDetails.cash && (
              <>
                <div className="flex justify-between">
                  <span>Tendered:</span>
                  <span>${order.paymentDetails.cash.toFixed(2)}</span>
                </div>
                {order.paymentDetails.change && (
                  <div className="flex justify-between font-bold">
                    <span>Change:</span>
                    <span>${order.paymentDetails.change.toFixed(2)}</span>
                  </div>
                )}
              </>
            )}
          </div>

            <div className="text-center mt-6 text-xs">
              <p>{settings.receiptHeader}</p>
              <p className="mt-2">{settings.receiptFooter}</p>
            </div>
          </Card>
        </ScrollArea>

        <div className="flex gap-2 pt-4">
          <Button
            variant="outline"
            className="flex-1"
            onClick={handleShare}
            data-testid="button-share-receipt"
          >
            <Share2 className="w-4 h-4 mr-2" />
            Share
          </Button>
          <Button
            className="flex-1"
            onClick={handleDownloadPDF}
            data-testid="button-download-receipt"
          >
            <Download className="w-4 h-4 mr-2" />
            Download PDF
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
