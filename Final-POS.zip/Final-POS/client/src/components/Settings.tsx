import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Store, Receipt, DollarSign, Bell, Shield, Trash2 } from 'lucide-react';
import { Textarea } from '@/components/ui/textarea';
import { storage } from '@/lib/storage';
import { useToast } from '@/hooks/use-toast';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';

export function Settings() {
  const [settings, setSettings] = useState(storage.getSettings());
  const { toast } = useToast();

  const handleSave = () => {
    storage.saveSettings(settings);
    toast({
      title: 'Settings Saved',
      description: 'Your settings have been updated successfully',
    });
  };

  const handleEraseAllData = () => {
    storage.eraseAllData();
    toast({
      title: 'All Data Erased',
      description: 'All products, customers, and orders have been deleted. Sample data has been added.',
      variant: 'destructive',
    });
    setTimeout(() => window.location.reload(), 1000);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Settings</h1>
          <p className="text-muted-foreground mt-1">Configure your POS system</p>
        </div>
        <Button onClick={handleSave} data-testid="button-save-settings">
          Save Changes
        </Button>
      </div>

      <Tabs defaultValue="store" className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="store" data-testid="tab-store">
            <Store className="w-4 h-4 mr-2" />
            Store
          </TabsTrigger>
          <TabsTrigger value="receipt" data-testid="tab-receipt">
            <Receipt className="w-4 h-4 mr-2" />
            Receipt
          </TabsTrigger>
          <TabsTrigger value="tax" data-testid="tab-tax">
            <DollarSign className="w-4 h-4 mr-2" />
            Tax & Currency
          </TabsTrigger>
          <TabsTrigger value="loyalty" data-testid="tab-loyalty">
            Loyalty
          </TabsTrigger>
          <TabsTrigger value="security" data-testid="tab-security">
            <Shield className="w-4 h-4 mr-2" />
            Security
          </TabsTrigger>
        </TabsList>

        <TabsContent value="store" className="space-y-6">
          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4">Store Information</h3>
            <div className="space-y-4">
              <div>
                <Label>Store Name</Label>
                <Input
                  value={settings.storeName}
                  onChange={(e) => setSettings({ ...settings, storeName: e.target.value })}
                  data-testid="input-store-name"
                  className="mt-1"
                />
              </div>
              <div>
                <Label>Address</Label>
                <Input
                  value={settings.storeAddress}
                  onChange={(e) => setSettings({ ...settings, storeAddress: e.target.value })}
                  data-testid="input-store-address"
                  className="mt-1"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Phone Number</Label>
                  <Input
                    value={settings.storePhone}
                    onChange={(e) => setSettings({ ...settings, storePhone: e.target.value })}
                    data-testid="input-store-phone"
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label>Email</Label>
                  <Input
                    type="email"
                    value={settings.storeEmail}
                    onChange={(e) => setSettings({ ...settings, storeEmail: e.target.value })}
                    data-testid="input-store-email"
                    className="mt-1"
                  />
                </div>
              </div>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="receipt" className="space-y-6">
          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4">Receipt Configuration</h3>
            <div className="space-y-4">
              <div>
                <Label>Receipt Header</Label>
                <Textarea
                  value={settings.receiptHeader}
                  onChange={(e) => setSettings({ ...settings, receiptHeader: e.target.value })}
                  data-testid="input-receipt-header"
                  rows={3}
                  className="mt-1"
                />
              </div>
              <div>
                <Label>Receipt Footer</Label>
                <Textarea
                  value={settings.receiptFooter}
                  onChange={(e) => setSettings({ ...settings, receiptFooter: e.target.value })}
                  data-testid="input-receipt-footer"
                  rows={3}
                  className="mt-1"
                />
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4">Receipt Design</h3>
            <div className="space-y-4">
              <div>
                <Label>Background Image URL</Label>
                <Input
                  value={settings.receiptBackground || ''}
                  onChange={(e) => setSettings({ ...settings, receiptBackground: e.target.value })}
                  placeholder="https://example.com/background.jpg"
                  className="mt-1"
                />
                <p className="text-sm text-muted-foreground mt-1">
                  Enter a URL for the receipt background image
                </p>
              </div>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="tax" className="space-y-6">
          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4">Tax & Currency Settings</h3>
            <div className="space-y-4">
              <div>
                <Label>Currency</Label>
                <Select
                  value={settings.currency}
                  onValueChange={(value: any) => setSettings({ ...settings, currency: value })}
                >
                  <SelectTrigger data-testid="select-currency" className="mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="USD">USD ($)</SelectItem>
                    <SelectItem value="EUR">EUR (€)</SelectItem>
                    <SelectItem value="GBP">GBP (£)</SelectItem>
                    <SelectItem value="AED">AED (د.إ)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label>Enable Tax</Label>
                  <p className="text-sm text-muted-foreground">Apply tax to taxable items</p>
                </div>
                <Switch
                  checked={settings.taxEnabled}
                  onCheckedChange={(checked) => setSettings({ ...settings, taxEnabled: checked })}
                  data-testid="switch-tax-enabled"
                />
              </div>
              <div>
                <Label>Tax Rate (%)</Label>
                <Input
                  type="number"
                  value={settings.taxRate}
                  onChange={(e) => setSettings({ ...settings, taxRate: parseFloat(e.target.value) || 0 })}
                  data-testid="input-tax-rate"
                  className="mt-1"
                />
              </div>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="loyalty" className="space-y-6">
          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4">Loyalty Program</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label>Enable Loyalty Program</Label>
                  <p className="text-sm text-muted-foreground">Reward customers with points</p>
                </div>
                <Switch
                  checked={settings.loyaltyEnabled}
                  onCheckedChange={(checked) => setSettings({ ...settings, loyaltyEnabled: checked })}
                  data-testid="switch-loyalty-enabled"
                />
              </div>
              <div>
                <Label>Loyalty Reward Rate (%)</Label>
                <p className="text-sm text-muted-foreground mb-1">Percentage of purchase value added as store credit</p>
                <Input
                  type="number"
                  value={settings.loyaltyRate}
                  onChange={(e) => setSettings({ ...settings, loyaltyRate: parseFloat(e.target.value) || 0 })}
                  data-testid="input-loyalty-rate"
                  className="mt-1"
                />
              </div>
              <div>
                <h4 className="font-medium mb-3">Tier Thresholds</h4>
                <div className="space-y-3">
                  <div>
                    <Label>Silver Tier (Total Spent $)</Label>
                    <Input
                      type="number"
                      value={settings.tierThresholds.silver}
                      onChange={(e) => setSettings({
                        ...settings,
                        tierThresholds: { ...settings.tierThresholds, silver: parseInt(e.target.value) || 0 }
                      })}
                      data-testid="input-tier-silver"
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label>Gold Tier (Total Spent $)</Label>
                    <Input
                      type="number"
                      value={settings.tierThresholds.gold}
                      onChange={(e) => setSettings({
                        ...settings,
                        tierThresholds: { ...settings.tierThresholds, gold: parseInt(e.target.value) || 0 }
                      })}
                      data-testid="input-tier-gold"
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label>Platinum Tier (Total Spent $)</Label>
                    <Input
                      type="number"
                      value={settings.tierThresholds.platinum}
                      onChange={(e) => setSettings({
                        ...settings,
                        tierThresholds: { ...settings.tierThresholds, platinum: parseInt(e.target.value) || 0 }
                      })}
                      data-testid="input-tier-platinum"
                      className="mt-1"
                    />
                  </div>
                </div>
              </div>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="security" className="space-y-6">
          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4">Security Settings</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label>Auto-Lock Screen</Label>
                  <p className="text-sm text-muted-foreground">Lock screen after period of inactivity</p>
                </div>
                <Switch
                  checked={settings.autoLockEnabled}
                  onCheckedChange={(checked) => setSettings({ ...settings, autoLockEnabled: checked })}
                  data-testid="switch-auto-lock"
                />
              </div>
              <div>
                <Label>Idle Timeout (minutes)</Label>
                <Input
                  type="number"
                  value={settings.idleTimeout}
                  onChange={(e) => setSettings({ ...settings, idleTimeout: parseInt(e.target.value) || 2 })}
                  data-testid="input-idle-timeout"
                  className="mt-1"
                />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label>Enable Sounds</Label>
                  <p className="text-sm text-muted-foreground">Play sound effects for actions</p>
                </div>
                <Switch
                  checked={settings.soundsEnabled}
                  onCheckedChange={(checked) => setSettings({ ...settings, soundsEnabled: checked })}
                  data-testid="switch-sounds"
                />
              </div>
            </div>
          </Card>

          <Card className="p-6 border-destructive">
            <h3 className="text-lg font-semibold mb-4 text-destructive">Danger Zone</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-destructive/10 rounded-lg">
                <div>
                  <Label className="text-destructive">Erase All Data</Label>
                  <p className="text-sm text-muted-foreground">Permanently delete all products, customers, and orders</p>
                </div>
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button variant="destructive" size="sm">
                      <Trash2 className="w-4 h-4 mr-2" />
                      Erase All Data
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                      <AlertDialogDescription>
                        This action cannot be undone. This will permanently delete all products, customers, and order history from the system. Sample data will be added automatically.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction onClick={handleEraseAllData} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                        Yes, Erase Everything
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
            </div>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="flex justify-end">
        <Button onClick={handleSave} size="lg" data-testid="button-save-settings-bottom">
          Save All Changes
        </Button>
      </div>
    </div>
  );
}
