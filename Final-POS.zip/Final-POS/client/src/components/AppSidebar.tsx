import { 
  LayoutDashboard, 
  ShoppingCart, 
  Package, 
  Users, 
  Receipt, 
  Settings, 
  TrendingUp, 
  Tag, 
  FileText,
  Clock,
  Boxes,
  UserCog,
  ArrowLeftRight,
  Star,
  MessageSquare,
  Megaphone,
  BadgePercent,
  Ticket,
  History,
  Bot,
  Scan,
  Lock,
  Database
} from 'lucide-react';
import { useAuth } from './AuthContext';
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter
} from '@/components/ui/sidebar';

const mainItems = [
  { title: 'Dashboard', icon: LayoutDashboard, path: '/' },
  { title: 'POS Checkout', icon: ShoppingCart, path: '/checkout' },
  { title: 'Orders', icon: Receipt, path: '/orders' },
  { title: 'Hold Orders', icon: Clock, path: '/hold-orders' },
  { title: 'Returns & Exchange', icon: ArrowLeftRight, path: '/returns' },
];

const inventoryItems = [
  { title: 'Products', icon: Package, path: '/products' },
  { title: 'Categories', icon: Boxes, path: '/categories' },
  { title: 'Stock Management', icon: TrendingUp, path: '/stock' },
  { title: 'Suppliers', icon: FileText, path: '/suppliers' },
];

const customerItems = [
  { title: 'Customers', icon: Users, path: '/customers' },
  { title: 'Loyalty Program', icon: Tag, path: '/loyalty' },
  { title: 'Ratings', icon: Star, path: '/ratings' },
];

const promotionsItems = [
  { title: 'Deals', icon: BadgePercent, path: '/deals' },
  { title: 'Coupons', icon: Ticket, path: '/coupons' },
  { title: 'Announcements', icon: Megaphone, path: '/announcements' },
];

const toolsItems = [
  { title: 'Messages', icon: MessageSquare, path: '/messages' },
  { title: 'Scan History', icon: Scan, path: '/scan-history' },
  { title: 'AI Assistant', icon: Bot, path: '/ai-chat' },
];

const systemItems = [
  { title: 'Staff Management', icon: UserCog, path: '/staff' },
  { title: 'Change PIN', icon: Lock, path: '/change-pin' },
  { title: 'Data Management', icon: Database, path: '/data' },
  { title: 'Settings', icon: Settings, path: '/settings' },
];

interface AppSidebarProps {
  currentPath?: string;
}

export function AppSidebar({ currentPath = '/' }: AppSidebarProps) {
  const { currentCashier } = useAuth();
  const isAdmin = currentCashier?.role === 'admin';

  return (
    <Sidebar>
      <SidebarHeader className="p-4">
        <h2 className="text-xl font-bold">POS System</h2>
        <p className="text-sm text-muted-foreground">Professional Edition</p>
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Main</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {mainItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton
                    data-testid={`nav-${item.title.toLowerCase().replace(' ', '-')}`}
                    asChild
                    isActive={currentPath === item.path}
                  >
                    <a href={item.path}>
                      <item.icon />
                      <span>{item.title}</span>
                    </a>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel>Inventory</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {inventoryItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton
                    data-testid={`nav-${item.title.toLowerCase().replace(' ', '-')}`}
                    asChild
                    isActive={currentPath === item.path}
                  >
                    <a href={item.path}>
                      <item.icon />
                      <span>{item.title}</span>
                    </a>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel>Customers</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {customerItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton
                    data-testid={`nav-${item.title.toLowerCase().replace(' ', '-')}`}
                    asChild
                    isActive={currentPath === item.path}
                  >
                    <a href={item.path}>
                      <item.icon />
                      <span>{item.title}</span>
                    </a>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel>Promotions</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {promotionsItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton
                    data-testid={`nav-${item.title.toLowerCase().replace(' ', '-')}`}
                    asChild
                    isActive={currentPath === item.path}
                  >
                    <a href={item.path}>
                      <item.icon />
                      <span>{item.title}</span>
                    </a>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel>Tools</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {toolsItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton
                    data-testid={`nav-${item.title.toLowerCase().replace(' ', '-')}`}
                    asChild
                    isActive={currentPath === item.path}
                  >
                    <a href={item.path}>
                      <item.icon />
                      <span>{item.title}</span>
                    </a>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel>System</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {systemItems.filter(item => item.path !== '/data' || isAdmin).map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton
                    data-testid={`nav-${item.title.toLowerCase().replace(' ', '-')}`}
                    asChild
                    isActive={currentPath === item.path}
                  >
                    <a href={item.path}>
                      <item.icon />
                      <span>{item.title}</span>
                    </a>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      <SidebarFooter className="p-4 border-t">
        <div className="text-xs text-muted-foreground">
          <p>Version 1.0.0</p>
          <p>© 2024 POS Pro</p>
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}
