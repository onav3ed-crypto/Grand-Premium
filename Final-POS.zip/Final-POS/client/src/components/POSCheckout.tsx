import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Search, Plus, Minus, X, ShoppingCart, User, Percent, Undo, Scan } from 'lucide-react';
import { storage, type Product, type Customer } from '@/lib/storage';
import { PaymentDialog } from './PaymentDialog';
import { CustomerSelectDialog } from './CustomerSelectDialog';
import { BarcodeScanner } from './BarcodeScanner';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from './AuthContext';
import { addScanHistory } from '@/lib/indexedDB';

interface CartItem {
  id: string;
  productId: string;
  code: string;
  name: string;
  price: number;
  quantity: number;
  discount: number;
  taxed: boolean;
  costPrice: number;
}

export function POSCheckout() {
  const [itemCode, setItemCode] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [discount, setDiscount] = useState(0);
  const [taxEnabled, setTaxEnabled] = useState(true);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [showPayment, setShowPayment] = useState(false);
  const [showCustomerSelect, setShowCustomerSelect] = useState(false);
  const [showScanner, setShowScanner] = useState(false);
  const { currentCashier } = useAuth();
  const { toast } = useToast();

  const settings = storage.getSettings();
  const taxRate = settings.taxRate / 100;

  useEffect(() => {
    const init = async () => {
      await storage.initializeSampleData();
      
      // Check for resumed order
      const resumeOrderId = sessionStorage.getItem('resumeOrderId');
      if (resumeOrderId) {
        const order = storage.getOrders().find(o => o.id === resumeOrderId);
        if (order && order.status === 'held') {
          // Load order into cart
          const loadedCart: CartItem[] = order.items.map(item => ({
            id: crypto.randomUUID(),
            productId: item.productId,
            code: item.code,
            name: item.name,
            price: item.price,
            quantity: item.quantity,
            discount: item.discount,
            taxed: item.taxed,
            costPrice: item.cost,
          }));
          setCart(loadedCart);
          
          // Load customer if exists
          if (order.customerId) {
            const customer = storage.getCustomers().find(c => c.id === order.customerId);
            if (customer) {
              setSelectedCustomer(customer);
            }
          }
          
          // Delete the held order
          const orders = storage.getOrders().filter(o => o.id !== resumeOrderId);
          storage.saveOrders(orders);
          
          sessionStorage.removeItem('resumeOrderId');
          
          toast({
            title: 'Order Resumed',
            description: 'Held order has been loaded into cart',
          });
        }
      }
    };
    
    init();
  }, []);

  const addToCart = (scannedCode?: string) => {
    const codeToUse = scannedCode || itemCode;
    
    if (!codeToUse.trim()) {
      toast({
        title: 'Error',
        description: 'Please enter an item code',
        variant: 'destructive',
      });
      return;
    }

    const product = storage.getProductByCode(codeToUse);
    
    if (!product) {
      toast({
        title: 'Product Not Found',
        description: `No product with code "${codeToUse}"`,
        variant: 'destructive',
      });
      return;
    }

    if (product.stock < quantity) {
      toast({
        title: 'Insufficient Stock',
        description: `Only ${product.stock} items available`,
        variant: 'destructive',
      });
      return;
    }

    // Check if product already in cart, if so increment quantity
    const existingItemIndex = cart.findIndex(item => item.code === product.code);
    if (existingItemIndex !== -1 && scannedCode) {
      const updatedCart = [...cart];
      const existingItem = updatedCart[existingItemIndex];
      const newQuantity = existingItem.quantity + 1;
      
      if (product.stock < newQuantity) {
        toast({
          title: 'Insufficient Stock',
          description: `Only ${product.stock} items available`,
          variant: 'destructive',
        });
        return;
      }
      
      updatedCart[existingItemIndex] = { ...existingItem, quantity: newQuantity };
      setCart(updatedCart);
      
      toast({
        title: 'Quantity Updated',
        description: `${product.name} quantity increased to ${newQuantity}`,
      });
    } else {
      const cartItem: CartItem = {
        id: crypto.randomUUID(),
        productId: product.id,
        code: product.code,
        name: product.name,
        price: product.price,
        quantity: scannedCode ? 1 : quantity,
        discount,
        taxed: taxEnabled && product.taxable,
        costPrice: product.cost,
      };

      setCart([...cart, cartItem]);
      
      toast({
        title: 'Item Added',
        description: `${product.name} added to cart`,
      });
    }

    if (!scannedCode) {
      setItemCode('');
      setQuantity(1);
      setDiscount(0);
    }
  };

  const handleScan = async (code: string) => {
    // Save scan to history
    const product = storage.getProductByCode(code);
    const scanEntry = {
      id: crypto.randomUUID(),
      timestamp: new Date().toISOString(),
      cashierId: currentCashier?.id,
      cashierName: currentCashier?.name,
      deviceInfo: navigator.userAgent,
      decodedContent: code,
      actionTaken: product ? 'Added product to cart' : 'Product not found',
      productId: product?.id,
    };
    
    try {
      await addScanHistory(scanEntry);
    } catch (error) {
      console.error('Failed to save scan history:', error);
    }
    
    // Add to cart
    addToCart(code);
  };

  const removeItem = (id: string) => {
    setCart(cart.filter(item => item.id !== id));
  };

  const undoLast = () => {
    if (cart.length > 0) {
      setCart(cart.slice(0, -1));
      toast({
        title: 'Undone',
        description: 'Last item removed',
      });
    }
  };

  const updateQuantity = (id: string, newQty: number) => {
    const item = cart.find(i => i.id === id);
    if (!item) return;

    const product = storage.getProducts().find(p => p.id === item.productId);
    if (product && newQty > product.stock) {
      toast({
        title: 'Insufficient Stock',
        description: `Only ${product.stock} items available`,
        variant: 'destructive',
      });
      return;
    }

    setCart(cart.map(item => 
      item.id === id ? { ...item, quantity: Math.max(1, newQty) } : item
    ));
  };

  const updateDiscount = (id: string, newDiscount: number) => {
    setCart(cart.map(item => 
      item.id === id ? { ...item, discount: Math.max(0, Math.min(100, newDiscount)) } : item
    ));
  };

  const subtotal = cart.reduce((sum, item) => {
    const itemPrice = item.price * item.quantity;
    const discountAmount = (itemPrice * item.discount) / 100;
    return sum + (itemPrice - discountAmount);
  }, 0);

  const totalTax = cart.reduce((sum, item) => {
    if (!item.taxed) return sum;
    const itemPrice = item.price * item.quantity;
    const discountAmount = (itemPrice * item.discount) / 100;
    return sum + ((itemPrice - discountAmount) * taxRate);
  }, 0);

  const totalDiscount = cart.reduce((sum, item) => {
    const itemPrice = item.price * item.quantity;
    return sum + ((itemPrice * item.discount) / 100);
  }, 0);

  const total = subtotal + totalTax;

  const totalProfit = cart.reduce((sum, item) => {
    const sellPrice = item.price * item.quantity;
    const costTotal = item.costPrice * item.quantity;
    const discountAmount = (sellPrice * item.discount) / 100;
    return sum + (sellPrice - discountAmount - costTotal);
  }, 0);

  const handleCompleteOrder = () => {
    if (cart.length === 0) {
      toast({
        title: 'Empty Cart',
        description: 'Add items to complete order',
        variant: 'destructive',
      });
      return;
    }
    setShowPayment(true);
  };

  const handleHoldOrder = () => {
    if (cart.length === 0) return;

    const order = storage.addOrder({
      cashierId: currentCashier!.id,
      cashierName: currentCashier!.name,
      customerId: selectedCustomer?.id,
      customerName: selectedCustomer?.name,
      items: cart.map(item => ({
        id: item.id,
        productId: item.productId,
        code: item.code,
        name: item.name,
        price: item.price,
        cost: item.costPrice,
        quantity: item.quantity,
        discount: item.discount,
        taxed: item.taxed,
      })),
      subtotal,
      tax: totalTax,
      discount: totalDiscount,
      total,
      profit: totalProfit,
      paymentMethod: 'cash',
      paymentDetails: {},
      status: 'held',
    });

    setCart([]);
    setSelectedCustomer(null);
    
    toast({
      title: 'Order Held',
      description: `Order ${order.transactionId} saved`,
    });
  };

  return (
    <div className="flex h-full gap-4">
      <div className="flex-1 flex flex-col gap-4">
        <Card className="p-6">
          <div className="space-y-4">
            <div className="flex gap-4">
              <div className="flex-1">
                <Label className="text-sm font-medium mb-2 block">Item Code</Label>
                <div className="flex gap-2">
                  <Input
                    data-testid="input-item-code"
                    placeholder="Enter item code or scan barcode"
                    value={itemCode}
                    onChange={(e) => setItemCode(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && itemCode && addToCart()}
                    className="h-12 text-lg flex-1"
                  />
                  <Button
                    variant="outline"
                    size="lg"
                    onClick={() => setShowScanner(true)}
                    data-testid="button-scan-barcode"
                    title="Scan Barcode/QR Code"
                  >
                    <Scan className="w-5 h-5" />
                  </Button>
                </div>
              </div>
              <div className="w-32">
                <Label className="text-sm font-medium mb-2 block">Quantity</Label>
                <Input
                  data-testid="input-quantity"
                  type="number"
                  min="1"
                  value={quantity}
                  onChange={(e) => setQuantity(parseInt(e.target.value) || 1)}
                  className="h-12 text-lg"
                />
              </div>
              <div className="w-32">
                <Label className="text-sm font-medium mb-2 block">Discount %</Label>
                <Input
                  data-testid="input-discount"
                  type="number"
                  min="0"
                  max="100"
                  value={discount}
                  onChange={(e) => setDiscount(parseInt(e.target.value) || 0)}
                  className="h-12 text-lg"
                />
              </div>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Switch
                  data-testid="switch-tax"
                  checked={taxEnabled}
                  onCheckedChange={setTaxEnabled}
                />
                <Label>Apply {settings.taxRate}% Tax</Label>
              </div>
              <Button
                data-testid="button-add-item"
                onClick={() => addToCart()}
                disabled={!itemCode}
                size="lg"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add to Order
              </Button>
            </div>
          </div>
        </Card>

        <Card className="flex-1 flex flex-col">
          <div className="p-4 border-b flex items-center justify-between">
            <h3 className="font-semibold text-lg">Current Order</h3>
            {cart.length > 0 && (
              <Button
                variant="ghost"
                size="sm"
                onClick={undoLast}
                data-testid="button-undo-last"
              >
                <Undo className="w-4 h-4 mr-2" />
                Undo Last
              </Button>
            )}
          </div>
          <ScrollArea className="flex-1">
            <div className="p-4 space-y-2">
              {cart.length === 0 ? (
                <div className="text-center py-12 text-muted-foreground">
                  <ShoppingCart className="w-12 h-12 mx-auto mb-3 opacity-50" />
                  <p>No items in cart</p>
                </div>
              ) : (
                cart.map((item) => {
                  const itemSubtotal = item.price * item.quantity;
                  const discountAmount = (itemSubtotal * item.discount) / 100;
                  const itemTax = item.taxed ? ((itemSubtotal - discountAmount) * taxRate) : 0;
                  const itemTotal = itemSubtotal - discountAmount + itemTax;
                  const itemProfit = (item.price - item.costPrice) * item.quantity - discountAmount;

                  return (
                    <Card key={item.id} className="p-4 hover-elevate">
                      <div className="flex items-start gap-4">
                        <div className="flex-1">
                          <div className="flex items-start justify-between mb-2">
                            <div>
                              <h4 className="font-medium">{item.name}</h4>
                              <p className="text-sm text-muted-foreground">Code: {item.code}</p>
                            </div>
                            <Button
                              data-testid={`button-remove-${item.id}`}
                              variant="ghost"
                              size="icon"
                              onClick={() => removeItem(item.id)}
                            >
                              <X className="w-4 h-4" />
                            </Button>
                          </div>
                          <div className="flex items-center gap-4 mb-2">
                            <div className="flex items-center gap-2">
                              <Button
                                data-testid={`button-decrease-${item.id}`}
                                variant="outline"
                                size="icon"
                                className="h-8 w-8"
                                onClick={() => updateQuantity(item.id, item.quantity - 1)}
                              >
                                <Minus className="w-3 h-3" />
                              </Button>
                              <span className="font-mono w-8 text-center">{item.quantity}</span>
                              <Button
                                data-testid={`button-increase-${item.id}`}
                                variant="outline"
                                size="icon"
                                className="h-8 w-8"
                                onClick={() => updateQuantity(item.id, item.quantity + 1)}
                              >
                                <Plus className="w-3 h-3" />
                              </Button>
                            </div>
                            <div className="text-sm">
                              ${item.price.toFixed(2)} × {item.quantity}
                            </div>
                            <Input
                              type="number"
                              min="0"
                              max="100"
                              value={item.discount}
                              onChange={(e) => updateDiscount(item.id, parseInt(e.target.value) || 0)}
                              className="w-20 h-8 text-sm"
                              placeholder="Disc %"
                            />
                            {item.discount > 0 && (
                              <Badge variant="secondary">
                                <Percent className="w-3 h-3 mr-1" />
                                {item.discount}% OFF
                              </Badge>
                            )}
                            {!item.taxed && (
                              <Badge variant="outline">Tax Free</Badge>
                            )}
                          </div>
                          <div className="flex justify-between text-sm">
                            <div className="text-muted-foreground">
                              {item.discount > 0 && (
                                <span>Saved: ${discountAmount.toFixed(2)}</span>
                              )}
                            </div>
                            <div className="space-x-4">
                              <span className="text-muted-foreground">
                                Profit: ${itemProfit.toFixed(2)}
                              </span>
                              <span className="font-semibold">
                                ${itemTotal.toFixed(2)}
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </Card>
                  );
                })
              )}
            </div>
          </ScrollArea>
        </Card>
      </div>

      <Card className="w-96 p-6 flex flex-col">
        <div className="space-y-4 flex-1">
          <div>
            <h3 className="font-semibold text-lg mb-3">Order Summary</h3>
            {selectedCustomer ? (
              <Card className="p-3 mb-4 bg-muted/50 hover-elevate cursor-pointer" onClick={() => setShowCustomerSelect(true)}>
                <div className="flex items-center gap-2 mb-2">
                  <User className="w-4 h-4" />
                  <span className="font-medium">{selectedCustomer.name}</span>
                  <Badge className="ml-auto">{selectedCustomer.tier}</Badge>
                </div>
                <div className="text-sm text-muted-foreground">
                  Balance: ${selectedCustomer.balance.toFixed(2)} • Points: {selectedCustomer.points}
                </div>
              </Card>
            ) : (
              <Button
                variant="outline"
                className="w-full mb-4"
                onClick={() => setShowCustomerSelect(true)}
                data-testid="button-select-customer"
              >
                <User className="w-4 h-4 mr-2" />
                Select Customer
              </Button>
            )}
          </div>

          <div className="space-y-3 py-4 border-y">
            <div className="flex justify-between text-base">
              <span className="text-muted-foreground">Subtotal</span>
              <span className="font-mono">${subtotal.toFixed(2)}</span>
            </div>
            {totalDiscount > 0 && (
              <div className="flex justify-between text-base text-chart-2">
                <span>Discount</span>
                <span className="font-mono">-${totalDiscount.toFixed(2)}</span>
              </div>
            )}
            <div className="flex justify-between text-base">
              <span className="text-muted-foreground">Tax ({settings.taxRate}%)</span>
              <span className="font-mono">${totalTax.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-xl font-bold">
              <span>Total</span>
              <span className="font-mono">${total.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-sm text-muted-foreground">
              <span>Total Profit</span>
              <span className="font-mono text-chart-2">${totalProfit.toFixed(2)}</span>
            </div>
          </div>
        </div>

        <div className="space-y-2 mt-4">
          <Button
            data-testid="button-complete-order"
            className="w-full"
            size="lg"
            disabled={cart.length === 0}
            onClick={handleCompleteOrder}
          >
            <ShoppingCart className="w-4 h-4 mr-2" />
            Complete Order
          </Button>
          <div className="grid grid-cols-2 gap-2">
            <Button
              data-testid="button-hold-order"
              variant="outline"
              disabled={cart.length === 0}
              onClick={handleHoldOrder}
            >
              Hold Order
            </Button>
            <Button
              data-testid="button-clear-order"
              variant="outline"
              onClick={() => {
                setCart([]);
                setSelectedCustomer(null);
              }}
              disabled={cart.length === 0}
            >
              Clear Order
            </Button>
          </div>
        </div>
      </Card>

      <PaymentDialog
        open={showPayment}
        onOpenChange={setShowPayment}
        cart={cart}
        customer={selectedCustomer}
        onComplete={() => {
          setCart([]);
          setSelectedCustomer(null);
        }}
      />

      <CustomerSelectDialog
        open={showCustomerSelect}
        onOpenChange={setShowCustomerSelect}
        onSelect={(customer) => {
          setSelectedCustomer(customer);
          setShowCustomerSelect(false);
        }}
      />

      <BarcodeScanner
        isOpen={showScanner}
        onClose={() => setShowScanner(false)}
        onScan={handleScan}
      />
    </div>
  );
}
