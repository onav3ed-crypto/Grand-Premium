import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Lock, Shield } from 'lucide-react';
import { storage } from '@/lib/storage';
import { useAuth } from './AuthContext';
import { useToast } from '@/hooks/use-toast';

export function PINChange() {
  const [currentPin, setCurrentPin] = useState('');
  const [newPin, setNewPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const { currentCashier, currentCustomer } = useAuth();
  const { toast } = useToast();

  const handleChangePIN = () => {
    if (!currentCashier && !currentCustomer) {
      toast({
        title: 'Error',
        description: 'You must be logged in to change your PIN',
        variant: 'destructive',
      });
      return;
    }

    if (currentPin.length !== 4 || newPin.length !== 4 || confirmPin.length !== 4) {
      toast({
        title: 'Invalid PIN',
        description: 'All PINs must be exactly 4 digits',
        variant: 'destructive',
      });
      return;
    }

    if (newPin !== confirmPin) {
      toast({
        title: 'PIN Mismatch',
        description: 'New PIN and confirmation do not match',
        variant: 'destructive',
      });
      return;
    }

    if (currentCashier) {
      if (currentCashier.pin !== currentPin) {
        toast({
          title: 'Wrong PIN',
          description: 'Current PIN is incorrect',
          variant: 'destructive',
        });
        return;
      }

      const cashiers = storage.getCashiers();
      const updatedCashiers = cashiers.map(c =>
        c.id === currentCashier.id ? { ...c, pin: newPin } : c
      );
      storage.saveCashiers(updatedCashiers);

      storage.addAuditLog({
        action: 'PIN Changed',
        entityType: 'cashier',
        entityId: currentCashier.id,
        userId: currentCashier.id,
        userName: currentCashier.name,
        userRole: currentCashier.role,
      });

      toast({
        title: 'PIN Changed',
        description: 'Your PIN has been updated successfully',
      });
    } else if (currentCustomer) {
      if (currentCustomer.cardPin !== currentPin) {
        toast({
          title: 'Wrong PIN',
          description: 'Current PIN is incorrect',
          variant: 'destructive',
        });
        return;
      }

      const customers = storage.getCustomers();
      const updatedCustomers = customers.map(c =>
        c.id === currentCustomer.id ? { ...c, cardPin: newPin } : c
      );
      storage.saveCustomers(updatedCustomers);

      storage.addAuditLog({
        action: 'PIN Changed',
        entityType: 'customer',
        entityId: currentCustomer.id,
        userId: currentCustomer.id,
        userName: currentCustomer.name,
        userRole: 'customer',
      });

      toast({
        title: 'PIN Changed',
        description: 'Your card PIN has been updated successfully',
      });
    }

    setCurrentPin('');
    setNewPin('');
    setConfirmPin('');
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Change PIN</h1>
        <p className="text-muted-foreground mt-1">
          Update your {currentCashier ? 'cashier' : 'card'} PIN securely
        </p>
      </div>

      <Card className="p-6 max-w-md">
        <div className="space-y-6">
          <div className="flex items-center gap-3 p-4 bg-muted/50 rounded-lg">
            <Shield className="w-8 h-8 text-primary" />
            <div>
              <p className="font-medium">Security Notice</p>
              <p className="text-sm text-muted-foreground">
                All PIN changes are logged in the audit trail for security
              </p>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <Label>Current PIN</Label>
              <Input
                type="password"
                maxLength={4}
                placeholder="••••"
                value={currentPin}
                onChange={(e) => setCurrentPin(e.target.value.replace(/\D/g, ''))}
                className="text-2xl text-center tracking-widest mt-1"
              />
            </div>

            <div>
              <Label>New PIN</Label>
              <Input
                type="password"
                maxLength={4}
                placeholder="••••"
                value={newPin}
                onChange={(e) => setNewPin(e.target.value.replace(/\D/g, ''))}
                className="text-2xl text-center tracking-widest mt-1"
              />
            </div>

            <div>
              <Label>Confirm New PIN</Label>
              <Input
                type="password"
                maxLength={4}
                placeholder="••••"
                value={confirmPin}
                onChange={(e) => setConfirmPin(e.target.value.replace(/\D/g, ''))}
                className="text-2xl text-center tracking-widest mt-1"
              />
            </div>

            <Button
              onClick={handleChangePIN}
              className="w-full"
              size="lg"
            >
              <Lock className="w-4 h-4 mr-2" />
              Change PIN
            </Button>
          </div>
        </div>
      </Card>

      <Card className="p-4 bg-muted/50 max-w-md">
        <p className="text-sm text-muted-foreground">
          <strong>PIN Requirements:</strong>
          <br />
          • Must be exactly 4 digits
          <br />
          • Must be different from your current PIN
          <br />
          • Choose a PIN that is not easily guessable
        </p>
      </Card>
    </div>
  );
}
