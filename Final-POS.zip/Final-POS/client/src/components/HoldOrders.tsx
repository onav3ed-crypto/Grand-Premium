import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Clock, ShoppingCart, User, Play } from 'lucide-react';
import { storage, type Order } from '@/lib/storage';
import { useToast } from '@/hooks/use-toast';
import { useLocation } from 'wouter';

export function HoldOrders() {
  const [, setLocation] = useLocation();
  const [heldOrders, setHeldOrders] = useState<Order[]>([]);
  const { toast } = useToast();

  // Load held orders
  const refreshOrders = () => {
    setHeldOrders(storage.getHeldOrders());
  };

  useEffect(() => {
    refreshOrders();
  }, []);

  const handleResumeOrder = (orderId: string) => {
    const order = heldOrders.find(o => o.id === orderId);
    if (!order) {
      toast({
        title: 'Order Not Found',
        description: 'This order no longer exists',
        variant: 'destructive',
      });
      refreshOrders();
      return;
    }

    // Store the order ID in session storage to be picked up by checkout
    sessionStorage.setItem('resumeOrderId', orderId);
    
    toast({
      title: 'Order Resumed',
      description: 'Redirecting to checkout...',
    });
    
    setLocation('/checkout');
  };

  const handleCancelOrder = (orderId: string) => {
    const order = heldOrders.find(o => o.id === orderId);
    if (!order) {
      toast({
        title: 'Order Not Found',
        description: 'This order no longer exists',
        variant: 'destructive',
      });
      refreshOrders();
      return;
    }

    if (confirm('Are you sure you want to cancel this held order?')) {
      const orders = storage.getOrders().filter(o => o.id !== orderId);
      storage.saveOrders(orders);
      
      // Refresh the list after deletion
      refreshOrders();
      
      toast({
        title: 'Order Cancelled',
        description: 'Held order has been cancelled',
      });
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Hold Orders</h1>
          <p className="text-muted-foreground mt-1">Resume or cancel parked orders</p>
        </div>
        <Badge variant="outline" className="text-lg px-4 py-2">
          {heldOrders.length} Held Orders
        </Badge>
      </div>

      <ScrollArea className="h-[700px]">
        <div className="space-y-4">
          {heldOrders.length === 0 ? (
            <Card className="p-12">
              <div className="text-center text-muted-foreground">
                <Clock className="w-16 h-16 mx-auto mb-4 opacity-50" />
                <p className="text-lg">No held orders</p>
                <p className="text-sm mt-2">Held orders will appear here when you park an order from checkout</p>
              </div>
            </Card>
          ) : (
            heldOrders.map((order) => (
              <Card key={order.id} className="p-6 hover-elevate">
                <div className="flex items-start gap-6">
                  <div className="w-16 h-16 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <Clock className="w-8 h-8 text-primary" />
                  </div>

                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h3 className="text-xl font-semibold mb-1">{order.transactionId}</h3>
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <Clock className="w-4 h-4" />
                            {new Date(order.createdAt).toLocaleString()}
                          </span>
                          {order.customerName && (
                            <span className="flex items-center gap-1">
                              <User className="w-4 h-4" />
                              {order.customerName}
                            </span>
                          )}
                          <span className="flex items-center gap-1">
                            <ShoppingCart className="w-4 h-4" />
                            {order.items.length} items
                          </span>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-2xl font-bold">${order.total.toFixed(2)}</p>
                        <Badge variant="outline" className="mt-1">Held</Badge>
                      </div>
                    </div>

                    <div className="mb-4 pb-4 border-b">
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                        <div>
                          <p className="text-muted-foreground">Subtotal</p>
                          <p className="font-semibold">${order.subtotal.toFixed(2)}</p>
                        </div>
                        {order.discount > 0 && (
                          <div>
                            <p className="text-muted-foreground">Discount</p>
                            <p className="font-semibold text-chart-2">-${order.discount.toFixed(2)}</p>
                          </div>
                        )}
                        <div>
                          <p className="text-muted-foreground">Tax</p>
                          <p className="font-semibold">${order.tax.toFixed(2)}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Cashier</p>
                          <p className="font-semibold">{order.cashierName}</p>
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-2 mb-4">
                      {order.items.map((item, idx) => (
                        <Badge key={idx} variant="outline">
                          {item.quantity}x {item.name} ${item.price.toFixed(2)}
                        </Badge>
                      ))}
                    </div>

                    <div className="flex gap-2">
                      <Button
                        onClick={() => handleResumeOrder(order.id)}
                        data-testid={`button-resume-${order.id}`}
                        className="flex-1"
                      >
                        <Play className="w-4 h-4 mr-2" />
                        Resume Order
                      </Button>
                      <Button
                        variant="outline"
                        onClick={() => handleCancelOrder(order.id)}
                        data-testid={`button-cancel-${order.id}`}
                      >
                        Cancel
                      </Button>
                    </div>
                  </div>
                </div>
              </Card>
            ))
          )}
        </div>
      </ScrollArea>
    </div>
  );
}
