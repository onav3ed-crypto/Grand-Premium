import { Card } from './ui/card';
import { Label } from './ui/label';
import { Customer } from '@/lib/storage';
import { DollarSign, Star, Mail, Phone, CreditCard } from 'lucide-react';

interface Props {
  customer: Customer;
}

export function CustomerAccountDetails({ customer }: Props) {
  return (
    <div className="space-y-6">
      <Card className="p-6">
        <h2 className="text-2xl font-bold mb-6">Account Details</h2>
        
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <Label className="text-muted-foreground">Name</Label>
            <p className="text-lg font-medium">{customer.name}</p>
          </div>

          {customer.email && (
            <div>
              <Label className="text-muted-foreground flex items-center gap-2">
                <Mail className="w-4 h-4" />
                Email
              </Label>
              <p className="text-lg">{customer.email}</p>
            </div>
          )}

          {customer.phone && (
            <div>
              <Label className="text-muted-foreground flex items-center gap-2">
                <Phone className="w-4 h-4" />
                Phone
              </Label>
              <p className="text-lg">{customer.phone}</p>
            </div>
          )}

          <div>
            <Label className="text-muted-foreground flex items-center gap-2">
              <Star className="w-4 h-4" />
              Tier
            </Label>
            <p className="text-lg font-medium">{customer.tier}</p>
          </div>

          <div>
            <Label className="text-muted-foreground flex items-center gap-2">
              <DollarSign className="w-4 h-4" />
              Total Spent
            </Label>
            <p className="text-lg font-medium">${customer.totalSpent.toFixed(2)}</p>
          </div>

          <div>
            <Label className="text-muted-foreground">Visits</Label>
            <p className="text-lg font-medium">{customer.visits}</p>
          </div>

          {customer.hasCard && (
            <div>
              <Label className="text-muted-foreground flex items-center gap-2">
                <CreditCard className="w-4 h-4" />
                Card Balance
              </Label>
              <p className="text-lg font-medium">${(customer.cardBalance || 0).toFixed(2)}</p>
            </div>
          )}

          <div>
            <Label className="text-muted-foreground flex items-center gap-2">
              <Star className="w-4 h-4" />
              Loyalty Points
            </Label>
            <p className="text-lg font-medium">{customer.points} points</p>
          </div>
        </div>
      </Card>
    </div>
  );
}
