import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ArrowLeftRight, RotateCcw, Search } from 'lucide-react';
import { storage, type Order } from '@/lib/storage';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/components/AuthContext';
import { useLocation } from 'wouter';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';

export function ReturnExchange() {
  const [mode, setMode] = useState<'return' | 'exchange'>('return');
  const [orderNumber, setOrderNumber] = useState('');
  const [cashierPin, setCashierPin] = useState('');
  const [foundOrder, setFoundOrder] = useState<Order | null>(null);
  const [showPinDialog, setShowPinDialog] = useState(false);
  const { toast } = useToast();
  const { currentCashier } = useAuth();
  const [, setLocation] = useLocation();

  const handleFindOrder = () => {
    if (!orderNumber.trim()) {
      toast({
        title: 'Order Number Required',
        description: 'Please enter an order number',
        variant: 'destructive',
      });
      return;
    }

    const order = storage.getOrders().find(o => o.transactionId === orderNumber.trim());
    if (!order) {
      toast({
        title: 'Order Not Found',
        description: 'No order found with this transaction ID',
        variant: 'destructive',
      });
      return;
    }

    setFoundOrder(order);
    setShowPinDialog(true);
  };

  const handleVerifyPin = () => {
    if (cashierPin !== currentCashier?.pin) {
      toast({
        title: 'Invalid PIN',
        description: 'The entered PIN is incorrect',
        variant: 'destructive',
      });
      return;
    }

    setShowPinDialog(false);
    processReturnExchange();
  };

  const processReturnExchange = () => {
    if (!foundOrder) return;

    if (mode === 'return') {
      foundOrder.items.forEach(item => {
        const product = storage.getProducts().find(p => p.id === item.productId);
        if (product) {
          storage.updateProduct(product.id, {
            stock: product.stock + item.quantity
          });
        }
      });

      const orders = storage.getOrders();
      const orderIndex = orders.findIndex(o => o.id === foundOrder.id);
      if (orderIndex !== -1) {
        orders[orderIndex].status = 'refunded';
        storage.saveOrders(orders);
      }

      if (foundOrder.customerId) {
        const customer = storage.getCustomers().find(c => c.id === foundOrder.customerId);
        if (customer) {
          storage.updateCustomer(foundOrder.customerId, {
            balance: customer.balance + foundOrder.total
          });
        }
      }

      toast({
        title: 'Return Processed',
        description: `$${foundOrder.total.toFixed(2)} has been refunded. Items returned to stock.`,
      });

      setOrderNumber('');
      setCashierPin('');
      setFoundOrder(null);
    } else {
      foundOrder.items.forEach(item => {
        const product = storage.getProducts().find(p => p.id === item.productId);
        if (product) {
          storage.updateProduct(product.id, {
            stock: product.stock + item.quantity
          });
        }
      });

      const orders = storage.getOrders();
      const orderIndex = orders.findIndex(o => o.id === foundOrder.id);
      if (orderIndex !== -1) {
        orders[orderIndex].status = 'refunded';
        storage.saveOrders(orders);
      }

      sessionStorage.setItem('exchangeAmount', foundOrder.total.toString());
      sessionStorage.setItem('exchangeMode', 'true');

      toast({
        title: 'Exchange Started',
        description: 'Items returned to stock. Redirecting to checkout...',
      });

      setTimeout(() => {
        setLocation('/checkout');
      }, 1000);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Returns & Exchanges</h1>
        <p className="text-muted-foreground mt-1">Process returns and exchange orders</p>
      </div>

      <Tabs value={mode} onValueChange={(v) => setMode(v as 'return' | 'exchange')}>
        <TabsList className="grid w-full grid-cols-2 max-w-md">
          <TabsTrigger value="return">
            <RotateCcw className="w-4 h-4 mr-2" />
            Return
          </TabsTrigger>
          <TabsTrigger value="exchange">
            <ArrowLeftRight className="w-4 h-4 mr-2" />
            Exchange
          </TabsTrigger>
        </TabsList>

        <TabsContent value="return" className="space-y-6">
          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4">Process Return</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Customer will receive a full refund and items will be returned to stock
            </p>
            <div className="space-y-4">
              <div>
                <Label>Order / Transaction Number</Label>
                <div className="flex gap-2 mt-1">
                  <Input
                    value={orderNumber}
                    onChange={(e) => setOrderNumber(e.target.value)}
                    placeholder="TXN-20250124-0001"
                    className="flex-1"
                  />
                  <Button onClick={handleFindOrder}>
                    <Search className="w-4 h-4 mr-2" />
                    Find Order
                  </Button>
                </div>
              </div>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="exchange" className="space-y-6">
          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4">Process Exchange</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Items will be returned to stock. Customer can select new items of equal or greater value.
            </p>
            <div className="space-y-4">
              <div>
                <Label>Order / Transaction Number</Label>
                <div className="flex gap-2 mt-1">
                  <Input
                    value={orderNumber}
                    onChange={(e) => setOrderNumber(e.target.value)}
                    placeholder="TXN-20250124-0001"
                    className="flex-1"
                  />
                  <Button onClick={handleFindOrder}>
                    <Search className="w-4 h-4 mr-2" />
                    Find Order
                  </Button>
                </div>
              </div>
            </div>
          </Card>
        </TabsContent>
      </Tabs>

      <Dialog open={showPinDialog} onOpenChange={setShowPinDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Verify Cashier PIN</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {foundOrder && (
              <Card className="p-4 bg-muted">
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="font-semibold">Order:</span>
                    <span>{foundOrder.transactionId}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-semibold">Total:</span>
                    <span>${foundOrder.total.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-semibold">Items:</span>
                    <span>{foundOrder.items.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-semibold">Status:</span>
                    <Badge>{foundOrder.status}</Badge>
                  </div>
                </div>
              </Card>
            )}
            <div>
              <Label>Enter Your PIN to Authorize {mode === 'return' ? 'Return' : 'Exchange'}</Label>
              <Input
                type="password"
                maxLength={4}
                value={cashierPin}
                onChange={(e) => setCashierPin(e.target.value.replace(/\D/g, ''))}
                placeholder="Enter 4-digit PIN"
                className="mt-1"
              />
            </div>
            <div className="flex gap-2">
              <Button variant="outline" className="flex-1" onClick={() => setShowPinDialog(false)}>
                Cancel
              </Button>
              <Button className="flex-1" onClick={handleVerifyPin}>
                Verify & Process
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
