import { storage } from '@/lib/storage';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Truck, ExternalLink } from 'lucide-react';

export function CustomerOnlineDelivery() {
  const settings = storage.getSettings();
  const deliveryUrl = settings.onlineDeliveryUrl || 'https://docs.google.com/forms';

  const handleGoToSite = () => {
    window.open(deliveryUrl, '_blank');
  };

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold">Online Delivery</h2>
      
      <Card className="p-8">
        <div className="max-w-md mx-auto text-center space-y-6">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-primary/10 rounded-full">
            <Truck className="w-10 h-10 text-primary" />
          </div>
          
          <div>
            <h3 className="text-xl font-semibold mb-2">Order Online for Delivery</h3>
            <p className="text-muted-foreground">
              Place your order online and get it delivered to your doorstep. Click the button below to visit our delivery platform.
            </p>
          </div>
          
          <Button onClick={handleGoToSite} size="lg" className="w-full">
            <ExternalLink className="w-5 h-5 mr-2" />
            Go To Site
          </Button>
        </div>
      </Card>
    </div>
  );
}
