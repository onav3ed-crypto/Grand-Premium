import { useState, useEffect } from 'react';
import { storage, Message } from '@/lib/storage';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { Send } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

interface Props {
  customerId: string;
  customerName: string;
}

export function CustomerMessages({ customerId, customerName }: Props) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');

  useEffect(() => {
    loadMessages();
    const interval = setInterval(loadMessages, 3000);
    return () => clearInterval(interval);
  }, [customerId]);

  const loadMessages = () => {
    const allMessages = storage.getMessages();
    const myMessages = allMessages.filter(m => 
      (m.fromId === customerId) || 
      (m.toId === customerId)
    ).sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
    
    setMessages(myMessages);
  };

  const sendMessage = () => {
    if (!newMessage.trim()) return;

    const allMessages = storage.getMessages();

    const message: Message = {
      id: crypto.randomUUID(),
      fromId: customerId,
      fromName: customerName,
      fromRole: 'customer',
      toId: 'store',
      toName: 'Store',
      toRole: 'cashier',
      text: newMessage,
      createdAt: new Date().toISOString(),
      read: false,
    };

    allMessages.push(message);
    storage.saveMessages(allMessages);
    setNewMessage('');
    loadMessages();
  };

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold">Messages</h2>
      
      <Card className="p-4 h-[500px] flex flex-col">
        <div className="flex-1 overflow-y-auto space-y-3 mb-4">
          {messages.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">No messages yet. Start a conversation!</p>
          ) : (
            messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex ${msg.fromRole === 'customer' ? 'justify-end' : 'justify-start'}`}
              >
                <div className={`max-w-[70%] p-3 rounded-lg ${
                  msg.fromRole === 'customer' 
                    ? 'bg-primary text-primary-foreground' 
                    : 'bg-muted'
                }`}>
                  <p className="text-sm font-medium mb-1">{msg.fromName}</p>
                  <p>{msg.text}</p>
                  <p className="text-xs opacity-70 mt-1">
                    {formatDistanceToNow(new Date(msg.createdAt), { addSuffix: true })}
                  </p>
                </div>
              </div>
            ))
          )}
        </div>
        
        <div className="flex gap-2">
          <Textarea
            placeholder="Type your message..."
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendMessage();
              }
            }}
            rows={2}
          />
          <Button onClick={sendMessage} size="icon" className="h-auto">
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </Card>
    </div>
  );
}
