import { useState, useEffect } from 'react';
import { storage, Coupon } from '@/lib/storage';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { useAuth } from './AuthContext';
import { useToast } from '@/hooks/use-toast';
import { Plus, Ticket, ToggleLeft, ToggleRight } from 'lucide-react';

export function CouponsManagement() {
  const [coupons, setCoupons] = useState<Coupon[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [code, setCode] = useState('');
  const [discountPercent, setDiscountPercent] = useState('10');
  const [maxUses, setMaxUses] = useState('');
  const { currentCashier } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    loadCoupons();
  }, []);

  const loadCoupons = () => {
    setCoupons(storage.getCoupons());
  };

  const createCoupon = () => {
    if (!code.trim() || !currentCashier) return;

    const coupon: Coupon = {
      id: crypto.randomUUID(),
      code: code.toUpperCase(),
      discountPercent: parseInt(discountPercent),
      active: true,
      createdAt: new Date().toISOString(),
      createdBy: currentCashier.name,
      usageCount: 0,
      maxUses: maxUses ? parseInt(maxUses) : undefined,
    };

    const all = storage.getCoupons();
    all.push(coupon);
    storage.saveCoupons(all);
    
    toast({ title: 'Coupon Created', description: `Code: ${coupon.code}` });
    setIsDialogOpen(false);
    setCode('');
    setDiscountPercent('10');
    setMaxUses('');
    loadCoupons();
  };

  const toggleCoupon = (id: string) => {
    const all = storage.getCoupons();
    const coupon = all.find(c => c.id === id);
    if (coupon) {
      coupon.active = !coupon.active;
      storage.saveCoupons(all);
      loadCoupons();
      toast({ title: coupon.active ? 'Coupon Enabled' : 'Coupon Disabled' });
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Coupons Management</h2>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button><Plus className="w-4 h-4 mr-2" />Create Coupon</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create Coupon</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>Coupon Code</Label>
                <Input 
                  placeholder="WELCOME10" 
                  value={code} 
                  onChange={e => setCode(e.target.value.toUpperCase())}
                />
              </div>
              <div>
                <Label>Discount Percentage</Label>
                <Input 
                  type="number" 
                  value={discountPercent} 
                  onChange={e => setDiscountPercent(e.target.value)}
                />
              </div>
              <div>
                <Label>Max Uses (optional)</Label>
                <Input 
                  type="number" 
                  placeholder="Leave empty for unlimited" 
                  value={maxUses} 
                  onChange={e => setMaxUses(e.target.value)}
                />
              </div>
              <Button onClick={createCoupon} className="w-full">Create Coupon</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {coupons.map(coupon => (
          <Card key={coupon.id} className={`p-6 ${!coupon.active && 'opacity-50'}`}>
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-primary/10 rounded-lg">
                  <Ticket className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="font-mono font-bold text-lg">{coupon.code}</p>
                  <p className="text-2xl font-bold text-primary">{coupon.discountPercent}% OFF</p>
                </div>
              </div>
              <Button variant="ghost" size="sm" onClick={() => toggleCoupon(coupon.id)}>
                {coupon.active ? <ToggleRight className="w-5 h-5 text-green-600" /> : <ToggleLeft className="w-5 h-5" />}
              </Button>
            </div>
            <div className="space-y-1 text-sm text-muted-foreground">
              <p>Used: {coupon.usageCount}{coupon.maxUses ? ` / ${coupon.maxUses}` : ''} times</p>
              <p>Created by: {coupon.createdBy}</p>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
