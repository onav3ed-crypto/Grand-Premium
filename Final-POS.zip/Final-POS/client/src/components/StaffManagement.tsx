import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { UserCog, Plus, Edit, Trash2, Shield, Clock } from 'lucide-react';
import { storage, type Cashier } from '@/lib/storage';
import { useToast } from '@/hooks/use-toast';
import { format } from 'date-fns';

export function StaffManagement() {
  const [cashiers, setCashiers] = useState(storage.getCashiers());
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [editingCashier, setEditingCashier] = useState<Cashier | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    pin: '',
    role: 'cashier' as 'admin' | 'cashier' | 'manager',
    permissions: {
      priceOverride: false,
      refunds: false,
      exports: false,
      settings: false,
    },
  });
  const { toast } = useToast();

  const resetForm = () => {
    setFormData({
      name: '',
      pin: '',
      role: 'cashier',
      permissions: {
        priceOverride: false,
        refunds: false,
        exports: false,
        settings: false,
      },
    });
    setEditingCashier(null);
  };

  const handleAdd = () => {
    if (!formData.name || !formData.pin) {
      toast({
        title: 'Error',
        description: 'Please fill in all required fields',
        variant: 'destructive',
      });
      return;
    }

    if (formData.pin.length !== 4) {
      toast({
        title: 'Error',
        description: 'PIN must be exactly 4 digits',
        variant: 'destructive',
      });
      return;
    }

    if (editingCashier) {
      const updated = cashiers.map(c =>
        c.id === editingCashier.id
          ? { ...c, ...formData }
          : c
      );
      storage.saveCashiers(updated);
      setCashiers(updated);
      toast({
        title: 'Staff Updated',
        description: `${formData.name}'s information has been updated`,
      });
    } else {
      storage.addCashier(formData);
      setCashiers(storage.getCashiers());
      toast({
        title: 'Staff Added',
        description: `${formData.name} has been added to the team`,
      });
    }

    setShowAddDialog(false);
    resetForm();
  };

  const handleEdit = (cashier: Cashier) => {
    setEditingCashier(cashier);
    setFormData({
      name: cashier.name,
      pin: cashier.pin,
      role: cashier.role,
      permissions: cashier.permissions || {
        priceOverride: false,
        refunds: false,
        exports: false,
        settings: false,
      },
    });
    setShowAddDialog(true);
  };

  const handleDelete = (id: string) => {
    const updated = cashiers.filter(c => c.id !== id);
    storage.saveCashiers(updated);
    setCashiers(updated);
    toast({
      title: 'Staff Removed',
      description: 'Staff member has been removed',
    });
  };

  const handleToggleActive = (cashier: Cashier) => {
    const updated = cashiers.map(c =>
      c.id === cashier.id ? { ...c, isActive: !c.isActive } : c
    );
    storage.saveCashiers(updated);
    setCashiers(updated);
    toast({
      title: cashier.isActive ? 'Staff Deactivated' : 'Staff Activated',
      description: `${cashier.name} has been ${cashier.isActive ? 'deactivated' : 'activated'}`,
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Staff Management</h1>
          <p className="text-muted-foreground mt-1">Manage staff accounts, roles, and permissions</p>
        </div>
        <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
          <DialogTrigger asChild>
            <Button onClick={resetForm}>
              <Plus className="w-4 h-4 mr-2" />
              Add Staff Member
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editingCashier ? 'Edit Staff Member' : 'Add New Staff Member'}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>Name</Label>
                <Input
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Enter staff name"
                />
              </div>
              <div>
                <Label>PIN (4 digits)</Label>
                <Input
                  type="password"
                  maxLength={4}
                  value={formData.pin}
                  onChange={(e) => setFormData({ ...formData, pin: e.target.value.replace(/\D/g, '') })}
                  placeholder="Enter 4-digit PIN"
                />
              </div>
              <div>
                <Label>Role</Label>
                <Select value={formData.role} onValueChange={(value: any) => setFormData({ ...formData, role: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="cashier">Cashier</SelectItem>
                    <SelectItem value="manager">Manager</SelectItem>
                    <SelectItem value="admin">Admin</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-3">
                <Label>Permissions</Label>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label className="text-sm font-normal">Price Override</Label>
                    <Switch
                      checked={formData.permissions.priceOverride}
                      onCheckedChange={(checked) =>
                        setFormData({
                          ...formData,
                          permissions: { ...formData.permissions, priceOverride: checked },
                        })
                      }
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label className="text-sm font-normal">Process Refunds</Label>
                    <Switch
                      checked={formData.permissions.refunds}
                      onCheckedChange={(checked) =>
                        setFormData({
                          ...formData,
                          permissions: { ...formData.permissions, refunds: checked },
                        })
                      }
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label className="text-sm font-normal">Export Data</Label>
                    <Switch
                      checked={formData.permissions.exports}
                      onCheckedChange={(checked) =>
                        setFormData({
                          ...formData,
                          permissions: { ...formData.permissions, exports: checked },
                        })
                      }
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label className="text-sm font-normal">Access Settings</Label>
                    <Switch
                      checked={formData.permissions.settings}
                      onCheckedChange={(checked) =>
                        setFormData({
                          ...formData,
                          permissions: { ...formData.permissions, settings: checked },
                        })
                      }
                    />
                  </div>
                </div>
              </div>
              <Button onClick={handleAdd} className="w-full">
                {editingCashier ? 'Update Staff Member' : 'Add Staff Member'}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="p-6">
          <h3 className="font-semibold mb-2">Total Staff</h3>
          <p className="text-3xl font-bold">{cashiers.length}</p>
        </Card>
        <Card className="p-6">
          <h3 className="font-semibold mb-2">Active Staff</h3>
          <p className="text-3xl font-bold">{cashiers.filter(c => c.isActive !== false).length}</p>
        </Card>
        <Card className="p-6">
          <h3 className="font-semibold mb-2">On Shift</h3>
          <p className="text-3xl font-bold">{cashiers.filter(c => c.shiftStart).length}</p>
        </Card>
      </div>

      <Card className="p-6">
        <h3 className="text-lg font-semibold mb-4">Staff Members</h3>
        <ScrollArea className="h-[500px]">
          <div className="space-y-2">
            {cashiers.map((cashier) => (
              <Card key={cashier.id} className="p-4 hover:bg-muted/50 transition-colors">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <p className="font-semibold">{cashier.name}</p>
                      <Badge variant={cashier.role === 'admin' ? 'default' : 'outline'}>
                        {cashier.role}
                      </Badge>
                      {cashier.isActive === false && (
                        <Badge variant="destructive">Inactive</Badge>
                      )}
                      {cashier.shiftStart && (
                        <Badge variant="secondary">
                          <Clock className="w-3 h-3 mr-1" />
                          On Shift
                        </Badge>
                      )}
                    </div>
                    <div className="flex gap-4 text-sm text-muted-foreground">
                      <span>
                        <Shield className="w-3 h-3 inline mr-1" />
                        Permissions: {Object.values(cashier.permissions || {}).filter(Boolean).length}/4
                      </span>
                      {cashier.shiftStart && (
                        <span>
                          Started: {format(new Date(cashier.shiftStart), 'MMM dd, HH:mm')}
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleToggleActive(cashier)}
                    >
                      {cashier.isActive === false ? 'Activate' : 'Deactivate'}
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleEdit(cashier)}
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleDelete(cashier.id)}
                      disabled={cashier.role === 'admin'}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </ScrollArea>
      </Card>
    </div>
  );
}
