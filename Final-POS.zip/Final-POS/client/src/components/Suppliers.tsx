import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { FileText, Plus, Edit2, Trash2, Package } from 'lucide-react';
import { storage } from '@/lib/storage';
import { useToast } from '@/hooks/use-toast';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';

interface Supplier {
  id: string;
  name: string;
  contactPerson: string;
  email: string;
  phone: string;
  address: string;
  notes?: string;
  activeOrders: number;
  totalOrders: number;
}

export function Suppliers() {
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [showDialog, setShowDialog] = useState(false);
  const [editingSupplier, setEditingSupplier] = useState<Supplier | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    contactPerson: '',
    email: '',
    phone: '',
    address: '',
    notes: ''
  });
  const { toast } = useToast();

  useEffect(() => {
    const loaded = (storage as any).getItem('suppliers', []);
    setSuppliers(loaded);
  }, []);

  const saveSupplier = () => {
    if (!formData.name || !formData.contactPerson) {
      toast({
        title: 'Error',
        description: 'Name and contact person are required',
        variant: 'destructive',
      });
      return;
    }

    if (editingSupplier) {
      const updated = suppliers.map(s =>
        s.id === editingSupplier.id ? { ...editingSupplier, ...formData } : s
      );
      setSuppliers(updated);
      (storage as any).setItem('suppliers', updated);
      toast({ title: 'Supplier Updated', description: 'Changes saved successfully' });
    } else {
      const supplier: Supplier = {
        id: crypto.randomUUID(),
        ...formData,
        activeOrders: 0,
        totalOrders: 0,
      };
      const updated = [...suppliers, supplier];
      setSuppliers(updated);
      (storage as any).setItem('suppliers', updated);
      toast({ title: 'Supplier Added', description: 'New supplier created' });
    }

    setShowDialog(false);
    setEditingSupplier(null);
    setFormData({ name: '', contactPerson: '', email: '', phone: '', address: '', notes: '' });
  };

  const deleteSupplier = (id: string) => {
    const updated = suppliers.filter(s => s.id !== id);
    setSuppliers(updated);
    (storage as any).setItem('suppliers', updated);
    toast({ title: 'Supplier Deleted', description: 'Supplier removed successfully' });
  };

  const editSupplier = (supplier: Supplier) => {
    setEditingSupplier(supplier);
    setFormData({
      name: supplier.name,
      contactPerson: supplier.contactPerson,
      email: supplier.email,
      phone: supplier.phone,
      address: supplier.address,
      notes: supplier.notes || '',
    });
    setShowDialog(true);
  };

  const getSupplierPOs = (supplierId: string) => {
    const purchaseOrders = (storage as any).getItem('purchaseOrders', []);
    const supplier = suppliers.find(s => s.id === supplierId);
    if (!supplier) return [];
    return purchaseOrders.filter((po: any) => po.supplier === supplier.name);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Suppliers</h1>
          <p className="text-muted-foreground mt-1">Manage supplier contacts and track purchase orders</p>
        </div>
        <Button onClick={() => setShowDialog(true)}>
          <Plus className="w-4 h-4 mr-2" />
          Add Supplier
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {suppliers.length === 0 ? (
          <Card className="col-span-full p-12">
            <div className="text-center text-muted-foreground">
              <FileText className="w-16 h-16 mx-auto mb-4 opacity-50" />
              <p className="text-lg mb-2">No Suppliers Yet</p>
              <p className="text-sm">Add your first supplier to get started</p>
            </div>
          </Card>
        ) : (
          suppliers.map(supplier => {
            const pos = getSupplierPOs(supplier.id);
            const activePOs = pos.filter((po: any) => po.status === 'pending');

            return (
              <Card key={supplier.id} className="p-6">
                <div className="space-y-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="font-semibold text-lg">{supplier.name}</h3>
                      <p className="text-sm text-muted-foreground">{supplier.contactPerson}</p>
                    </div>
                    <div className="flex gap-1">
                      <Button size="sm" variant="ghost" onClick={() => editSupplier(supplier)}>
                        <Edit2 className="w-4 h-4" />
                      </Button>
                      <Button size="sm" variant="ghost" onClick={() => deleteSupplier(supplier.id)}>
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-2 text-sm">
                    {supplier.email && (
                      <div className="flex items-center gap-2">
                        <span className="text-muted-foreground">Email:</span>
                        <a href={`mailto:${supplier.email}`} className="text-primary hover:underline">
                          {supplier.email}
                        </a>
                      </div>
                    )}
                    {supplier.phone && (
                      <div className="flex items-center gap-2">
                        <span className="text-muted-foreground">Phone:</span>
                        <a href={`tel:${supplier.phone}`} className="text-primary hover:underline">
                          {supplier.phone}
                        </a>
                      </div>
                    )}
                    {supplier.address && (
                      <div className="flex items-start gap-2">
                        <span className="text-muted-foreground">Address:</span>
                        <span className="flex-1">{supplier.address}</span>
                      </div>
                    )}
                  </div>

                  <div className="flex items-center gap-2 pt-2 border-t">
                    <Package className="w-4 h-4 text-muted-foreground" />
                    <div className="flex gap-3 text-sm">
                      <div>
                        <span className="text-muted-foreground">Active POs: </span>
                        <Badge variant="default">{activePOs.length}</Badge>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Total: </span>
                        <Badge variant="secondary">{pos.length}</Badge>
                      </div>
                    </div>
                  </div>

                  {supplier.notes && (
                    <div className="text-sm pt-2 border-t">
                      <p className="text-muted-foreground mb-1">Notes:</p>
                      <p className="text-xs">{supplier.notes}</p>
                    </div>
                  )}
                </div>
              </Card>
            );
          })
        )}
      </div>

      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingSupplier ? 'Edit Supplier' : 'Add Supplier'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Supplier Name *</Label>
              <Input
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="e.g., ABC Wholesale"
              />
            </div>
            <div>
              <Label>Contact Person *</Label>
              <Input
                value={formData.contactPerson}
                onChange={(e) => setFormData({ ...formData, contactPerson: e.target.value })}
                placeholder="John Doe"
              />
            </div>
            <div>
              <Label>Email</Label>
              <Input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                placeholder="contact@example.com"
              />
            </div>
            <div>
              <Label>Phone</Label>
              <Input
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                placeholder="+1 234 567 8900"
              />
            </div>
            <div>
              <Label>Address</Label>
              <Input
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                placeholder="123 Main St, City, State"
              />
            </div>
            <div>
              <Label>Notes</Label>
              <Textarea
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                placeholder="Additional notes..."
                rows={3}
              />
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => setShowDialog(false)} className="flex-1">
                Cancel
              </Button>
              <Button onClick={saveSupplier} className="flex-1">
                Save
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
