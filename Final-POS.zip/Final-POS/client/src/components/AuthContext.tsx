import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { storage, type Cashier, type Customer } from '@/lib/storage';

type UserRole = 'cashier' | 'customer';

interface AuthContextType {
  currentCashier: Cashier | null;
  currentCustomer: Customer | null;
  userRole: UserRole | null;
  login: (pin: string, role: UserRole) => boolean;
  logout: () => void;
  register: (name: string, pin: string) => boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [currentCashier, setCurrentCashier] = useState<Cashier | null>(() => 
    storage.getCurrentCashier()
  );
  const [currentCustomer, setCurrentCustomer] = useState<Customer | null>(() => 
    storage.getCurrentCustomer()
  );
  const [userRole, setUserRole] = useState<UserRole | null>(() => {
    if (storage.getCurrentCashier()) return 'cashier';
    if (storage.getCurrentCustomer()) return 'customer';
    return null;
  });
  const [lastActivity, setLastActivity] = useState(Date.now());

  const login = (pin: string, role: UserRole): boolean => {
    if (role === 'cashier') {
      const cashier = storage.getCashierByPin(pin);
      if (cashier) {
        storage.setCurrentCashier(cashier);
        storage.setCurrentCustomer(null);
        setCurrentCashier(cashier);
        setCurrentCustomer(null);
        setUserRole('cashier');
        setLastActivity(Date.now());
        return true;
      }
    } else {
      const customer = storage.getCustomerByPin(pin);
      if (customer) {
        storage.setCurrentCustomer(customer);
        storage.setCurrentCashier(null);
        setCurrentCustomer(customer);
        setCurrentCashier(null);
        setUserRole('customer');
        setLastActivity(Date.now());
        return true;
      }
    }
    return false;
  };

  const logout = () => {
    storage.setCurrentCashier(null);
    storage.setCurrentCustomer(null);
    setCurrentCashier(null);
    setCurrentCustomer(null);
    setUserRole(null);
  };

  const register = (name: string, pin: string): boolean => {
    if (!name || !pin || pin.length !== 4) return false;
    
    const existing = storage.getCashierByPin(pin);
    if (existing) return false;

    const newCashier = storage.addCashier({
      name,
      pin,
      role: 'cashier',
    });
    storage.setCurrentCashier(newCashier);
    setCurrentCashier(newCashier);
    setUserRole('cashier');
    return true;
  };

  // Auto-logout after 2 minutes of inactivity
  useEffect(() => {
    if (!currentCashier) return;

    const settings = storage.getSettings();
    if (!settings.autoLockEnabled) return;

    const timeout = settings.idleTimeout * 60 * 1000; // Convert minutes to ms

    const handleActivity = () => {
      setLastActivity(Date.now());
    };

    // Track mouse and keyboard activity
    window.addEventListener('mousemove', handleActivity);
    window.addEventListener('mousedown', handleActivity);
    window.addEventListener('keypress', handleActivity);
    window.addEventListener('touchstart', handleActivity);

    const checkInactivity = setInterval(() => {
      if (Date.now() - lastActivity > timeout) {
        logout();
      }
    }, 1000);

    return () => {
      window.removeEventListener('mousemove', handleActivity);
      window.removeEventListener('mousedown', handleActivity);
      window.removeEventListener('keypress', handleActivity);
      window.removeEventListener('touchstart', handleActivity);
      clearInterval(checkInactivity);
    };
  }, [currentCashier, lastActivity]);

  return (
    <AuthContext.Provider value={{ currentCashier, currentCustomer, userRole, login, logout, register }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
}
