import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Banknote, CreditCard, Wallet, Check } from 'lucide-react';
import { storage, type Customer } from '@/lib/storage';
import { useAuth } from './AuthContext';
import { useToast } from '@/hooks/use-toast';
import { ReceiptPreview } from './ReceiptPreview';
import { RatingModal } from './RatingModal';

interface CartItem {
  id: string;
  productId: string;
  code: string;
  name: string;
  price: number;
  quantity: number;
  discount: number;
  taxed: boolean;
  costPrice: number;
}

interface PaymentDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  cart: CartItem[];
  customer?: Customer | null;
  onComplete: () => void;
}

export function PaymentDialog({ open, onOpenChange, cart, customer, onComplete }: PaymentDialogProps) {
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'card' | 'split'>('cash');
  const [cashTendered, setCashTendered] = useState<string>('');
  const [cardPin, setCardPin] = useState('');
  const [cashAmount, setCashAmount] = useState<string>('');
  const [cardAmount, setCardAmount] = useState<string>('');
  const [balanceAmount, setBalanceAmount] = useState<string>('');
  const [couponCode, setCouponCode] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<any>(null);
  const [showRating, setShowRating] = useState(false);
  const [showReceipt, setShowReceipt] = useState(false);
  const [completedOrder, setCompletedOrder] = useState<any>(null);
  const { currentCashier } = useAuth();
  const { toast } = useToast();

  const settings = storage.getSettings();
  const taxRate = settings.taxRate / 100;

  const subtotal = cart.reduce((sum, item) => {
    const itemPrice = item.price * item.quantity;
    const discountAmount = (itemPrice * item.discount) / 100;
    return sum + (itemPrice - discountAmount);
  }, 0);

  const totalTax = cart.reduce((sum, item) => {
    if (!item.taxed) return sum;
    const itemPrice = item.price * item.quantity;
    const discountAmount = (itemPrice * item.discount) / 100;
    return sum + ((itemPrice - discountAmount) * taxRate);
  }, 0);

  const totalDiscount = cart.reduce((sum, item) => {
    const itemPrice = item.price * item.quantity;
    return sum + ((itemPrice * item.discount) / 100);
  }, 0);

  const couponDiscount = appliedCoupon ? (subtotal * appliedCoupon.discountPercent / 100) : 0;
  const total = subtotal - couponDiscount + totalTax;

  const totalProfit = cart.reduce((sum, item) => {
    const sellPrice = item.price * item.quantity;
    const costTotal = item.costPrice * item.quantity;
    const discountAmount = (sellPrice * item.discount) / 100;
    return sum + (sellPrice - discountAmount - costTotal);
  }, 0);

  const change = parseFloat(cashTendered) - total;
  const balanceUsed = Math.min(parseFloat(balanceAmount) || 0, customer?.balance || 0);
  const remainingAfterBalance = total - balanceUsed;

  const handleApplyCoupon = () => {
    if (!couponCode.trim()) {
      toast({
        title: 'Error',
        description: 'Please enter a coupon code',
        variant: 'destructive',
      });
      return;
    }

    const coupons = storage.getCoupons();
    const coupon = coupons.find(c => 
      c.code.toUpperCase() === couponCode.toUpperCase() && 
      c.active &&
      (!c.maxUses || c.usageCount < c.maxUses)
    );

    if (!coupon) {
      toast({
        title: 'Wrong Coupon',
        description: 'Invalid or expired coupon code',
        variant: 'destructive',
      });
      return;
    }

    setAppliedCoupon(coupon);
    toast({
      title: 'Coupon Applied',
      description: `${coupon.discountPercent}% discount applied!`,
    });
  };

  const handleContinueWithoutCoupon = () => {
    setAppliedCoupon(null);
    setCouponCode('');
  };

  const handleConfirmPayment = () => {
    let paymentDetails: any = {};
    let finalMethod: 'cash' | 'card' | 'split' | 'balance' = paymentMethod;

    if (paymentMethod === 'cash') {
      if (!cashTendered || parseFloat(cashTendered) < total) {
        toast({
          title: 'Insufficient Payment',
          description: 'Cash amount must be at least the total',
          variant: 'destructive',
        });
        return;
      }
      paymentDetails = {
        cash: parseFloat(cashTendered),
        change: parseFloat(cashTendered) - total,
      };
    } else if (paymentMethod === 'card') {
      if (cardPin.length !== 4) {
        toast({
          title: 'Invalid PIN',
          description: 'Please enter 4-digit PIN',
          variant: 'destructive',
        });
        return;
      }
      paymentDetails = {
        card: total,
      };
    } else if (paymentMethod === 'split') {
      const cash = parseFloat(cashAmount) || 0;
      const card = parseFloat(cardAmount) || 0;
      const balance = balanceUsed;
      
      if (cash + card + balance < total - 0.01) {
        toast({
          title: 'Insufficient Payment',
          description: 'Split payments must equal total',
          variant: 'destructive',
        });
        return;
      }

      paymentDetails = { cash, card, balance };
    }

    // Use customer balance if applicable
    if (balanceUsed > 0 && customer) {
      finalMethod = 'split';
      if (!paymentDetails.balance) {
        paymentDetails.balance = balanceUsed;
      }
      
      storage.updateCustomer(customer.id, {
        balance: customer.balance - balanceUsed,
      });
    }

    const order = storage.addOrder({
      cashierId: currentCashier!.id,
      cashierName: currentCashier!.name,
      customerId: customer?.id,
      customerName: customer?.name,
      items: cart.map(item => ({
        id: item.id,
        productId: item.productId,
        code: item.code,
        name: item.name,
        price: item.price,
        cost: item.costPrice,
        quantity: item.quantity,
        discount: item.discount,
        taxed: item.taxed,
      })),
      subtotal,
      tax: totalTax,
      discount: totalDiscount + couponDiscount,
      total,
      profit: totalProfit - couponDiscount,
      paymentMethod: finalMethod,
      paymentDetails,
      status: 'completed',
      couponCode: appliedCoupon?.code,
      couponDiscount,
    });

    // Update coupon usage count
    if (appliedCoupon) {
      const coupons = storage.getCoupons();
      const coupon = coupons.find(c => c.id === appliedCoupon.id);
      if (coupon) {
        coupon.usageCount++;
        storage.saveCoupons(coupons);
      }
    }

    setCompletedOrder(order);
    
    toast({
      title: 'Payment Successful',
      description: `Order ${order.transactionId} completed`,
    });

    onOpenChange(false);
    setShowRating(true);
    
    // Reset form
    setCashTendered('');
    setCardPin('');
    setCashAmount('');
    setCardAmount('');
    setBalanceAmount('');
    
    onComplete();
  };

  const handleRatingClose = () => {
    setShowRating(false);
    setShowReceipt(true);
  };

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-2xl">Complete Payment</DialogTitle>
          </DialogHeader>

          <div className="space-y-6">
            <Card className="p-4 bg-muted/50">
              <div className="flex justify-between items-center">
                <span className="text-lg">Total Amount</span>
                <span className="text-3xl font-bold" data-testid="payment-total">${total.toFixed(2)}</span>
              </div>
            </Card>

            {/* Coupon Code Input */}
            <Card className="p-4">
              <Label className="text-base font-medium mb-2 block">Have a Coupon Code?</Label>
              {appliedCoupon ? (
                <div className="space-y-2">
                  <div className="flex items-center justify-between p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                    <div>
                      <p className="font-medium text-green-700 dark:text-green-400">{appliedCoupon.code}</p>
                      <p className="text-sm text-green-600 dark:text-green-500">{appliedCoupon.discountPercent}% discount applied</p>
                    </div>
                    <p className="text-lg font-bold text-green-700 dark:text-green-400">-${couponDiscount.toFixed(2)}</p>
                  </div>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={handleContinueWithoutCoupon}
                    className="w-full"
                  >
                    Remove Coupon
                  </Button>
                </div>
              ) : (
                <div className="flex gap-2">
                  <Input
                    placeholder="Enter coupon code"
                    value={couponCode}
                    onChange={(e) => setCouponCode(e.target.value.toUpperCase())}
                    className="flex-1"
                    data-testid="input-coupon-code"
                  />
                  <Button onClick={handleApplyCoupon} variant="outline">
                    Apply
                  </Button>
                  <Button onClick={handleContinueWithoutCoupon} variant="ghost">
                    Continue Without
                  </Button>
                </div>
              )}
            </Card>

            {customer && customer.balance > 0 && (
              <Card className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-base font-medium">Customer Balance</Label>
                    <p className="text-sm text-muted-foreground">Available: ${customer.balance.toFixed(2)}</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <Input
                      type="number"
                      placeholder="Amount"
                      value={balanceAmount}
                      onChange={(e) => setBalanceAmount(e.target.value)}
                      max={customer.balance}
                      className="w-32"
                      data-testid="input-balance-amount"
                    />
                    <Badge className="bg-chart-2">-${balanceUsed.toFixed(2)}</Badge>
                  </div>
                </div>
              </Card>
            )}

            <Tabs value={paymentMethod} onValueChange={(v) => setPaymentMethod(v as any)} className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="cash" data-testid="tab-cash">
                  <Banknote className="w-4 h-4 mr-2" />
                  Cash
                </TabsTrigger>
                <TabsTrigger value="card" data-testid="tab-card">
                  <CreditCard className="w-4 h-4 mr-2" />
                  Card
                </TabsTrigger>
                <TabsTrigger value="split" data-testid="tab-split">
                  <Wallet className="w-4 h-4 mr-2" />
                  Split Payment
                </TabsTrigger>
              </TabsList>

              <TabsContent value="cash" className="space-y-4">
                <div>
                  <Label className="text-base font-medium mb-2 block">Amount Received</Label>
                  <Input
                    type="number"
                    placeholder="0.00"
                    value={cashTendered}
                    onChange={(e) => setCashTendered(e.target.value)}
                    className="text-2xl h-16"
                    data-testid="input-cash-tendered"
                  />
                </div>
                <div className="grid grid-cols-4 gap-2">
                  {[10, 20, 50, 100].map((amount) => (
                    <Button
                      key={amount}
                      variant="outline"
                      onClick={() => setCashTendered(amount.toString())}
                      data-testid={`button-quick-${amount}`}
                    >
                      ${amount}
                    </Button>
                  ))}
                </div>
                {cashTendered && (
                  <Card className="p-4 bg-primary/10">
                    <div className="flex justify-between items-center">
                      <span className="text-lg font-medium">Change</span>
                      <span className="text-2xl font-bold" data-testid="text-change">
                        ${change >= 0 ? change.toFixed(2) : '0.00'}
                      </span>
                    </div>
                  </Card>
                )}
              </TabsContent>

              <TabsContent value="card" className="space-y-4">
                <div>
                  <Label className="text-base font-medium mb-2 block">Card Balance</Label>
                  <Card className="p-4 bg-muted/50">
                    <p className="text-2xl font-bold">$1,250.00</p>
                    <p className="text-sm text-muted-foreground mt-1">Available (Simulated)</p>
                  </Card>
                </div>
                <div>
                  <Label className="text-base font-medium mb-2 block">Enter PIN</Label>
                  <Input
                    type="password"
                    maxLength={4}
                    placeholder="••••"
                    value={cardPin}
                    onChange={(e) => setCardPin(e.target.value.replace(/\D/g, ''))}
                    className="text-2xl h-16 text-center tracking-widest"
                    data-testid="input-card-pin"
                  />
                </div>
              </TabsContent>

              <TabsContent value="split" className="space-y-4">
                <div className="space-y-3">
                  <div>
                    <Label className="text-base font-medium mb-2 block">Cash Amount</Label>
                    <Input
                      type="number"
                      placeholder="0.00"
                      value={cashAmount}
                      onChange={(e) => setCashAmount(e.target.value)}
                      className="text-xl h-12"
                      data-testid="input-split-cash"
                    />
                  </div>
                  <div>
                    <Label className="text-base font-medium mb-2 block">Card Amount</Label>
                    <Input
                      type="number"
                      placeholder="0.00"
                      value={cardAmount}
                      onChange={(e) => setCardAmount(e.target.value)}
                      className="text-xl h-12"
                      data-testid="input-split-card"
                    />
                  </div>
                  {customer && customer.balance > 0 && (
                    <div>
                      <Label className="text-base font-medium mb-2 block">Balance Amount</Label>
                      <Input
                        type="number"
                        placeholder="0.00"
                        value={balanceAmount}
                        onChange={(e) => setBalanceAmount(e.target.value)}
                        max={customer.balance}
                        className="text-xl h-12"
                        data-testid="input-split-balance"
                      />
                    </div>
                  )}
                </div>
              </TabsContent>
            </Tabs>

            <div className="flex gap-3">
              <Button
                variant="outline"
                className="flex-1"
                onClick={() => onOpenChange(false)}
                data-testid="button-cancel-payment"
              >
                Cancel
              </Button>
              <Button
                className="flex-1"
                size="lg"
                onClick={handleConfirmPayment}
                data-testid="button-confirm-payment"
              >
                <Check className="w-4 h-4 mr-2" />
                Confirm Payment
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {completedOrder && (
        <>
          <RatingModal
            orderId={completedOrder.id}
            isOpen={showRating}
            onClose={handleRatingClose}
          />
          <ReceiptPreview
            open={showReceipt}
            onOpenChange={setShowReceipt}
            order={completedOrder}
          />
        </>
      )}
    </>
  );
}
