import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Boxes, Plus, Edit2, Trash2, ChevronRight, ChevronDown } from 'lucide-react';
import { storage } from '@/lib/storage';
import { useToast } from '@/hooks/use-toast';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';

interface Category {
  id: string;
  name: string;
  parentId?: string;
  autoDeals?: boolean;
  dealPercent?: number;
}

export function Categories() {
  const [categories, setCategories] = useState<Category[]>(storage.getCategories() || []);
  const [showDialog, setShowDialog] = useState(false);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [newCategory, setNewCategory] = useState({ name: '', parentId: '', autoDeals: false, dealPercent: 0 });
  const [expandedCategories, setExpandedCategories] = useState<Set<string>>(new Set());
  const { toast } = useToast();

  const saveCategory = () => {
    if (!newCategory.name.trim()) {
      toast({ title: 'Error', description: 'Category name is required', variant: 'destructive' });
      return;
    }

    if (editingCategory) {
      const updated = categories.map(c => c.id === editingCategory.id ? { ...editingCategory, ...newCategory } : c);
      setCategories(updated);
      storage.saveCategories(updated);
      toast({ title: 'Category Updated', description: 'Changes saved successfully' });
    } else {
      const category: Category = { id: crypto.randomUUID(), ...newCategory };
      const updated = [...categories, category];
      setCategories(updated);
      storage.saveCategories(updated);
      toast({ title: 'Category Added', description: 'New category created' });
    }

    setShowDialog(false);
    setNewCategory({ name: '', parentId: '', autoDeals: false, dealPercent: 0 });
    setEditingCategory(null);
  };

  const deleteCategory = (id: string) => {
    const updated = categories.filter(c => c.id !== id && c.parentId !== id);
    setCategories(updated);
    storage.saveCategories(updated);
    toast({ title: 'Category Deleted', description: 'Category removed successfully' });
  };

  const bulkAssignToCategory = (categoryId: string) => {
    const products = storage.getProducts();
    const count = products.length;
    products.forEach(p => (p as any).categoryId = categoryId);
    storage.saveProducts(products);
    toast({ title: 'Bulk Assign Complete', description: `${count} products assigned to category` });
  };

  const toggleExpand = (id: string) => {
    const newExpanded = new Set(expandedCategories);
    if (newExpanded.has(id)) newExpanded.delete(id);
    else newExpanded.add(id);
    setExpandedCategories(newExpanded);
  };

  const renderCategory = (category: Category, level = 0): JSX.Element => {
    const children = categories.filter(c => c.parentId === category.id);
    const isExpanded = expandedCategories.has(category.id);
    const products = storage.getProducts().filter(p => (p as any).categoryId === category.id);

    return (
      <div key={category.id}>
        <div className="flex items-center gap-2 p-3 border rounded-lg hover:bg-muted/50" style={{ marginLeft: `${level * 20}px` }}>
          {children.length > 0 && (
            <Button variant="ghost" size="sm" onClick={() => toggleExpand(category.id)}>
              {isExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
            </Button>
          )}
          <Boxes className="w-5 h-5" />
          <span className="flex-1 font-medium">{category.name}</span>
          <Badge variant="secondary">{products.length} products</Badge>
          {category.autoDeals && <Badge className="bg-green-500">Auto Deals {category.dealPercent}%</Badge>}
          <Button size="sm" variant="ghost" onClick={() => { setEditingCategory(category); setNewCategory({name: category.name, parentId: category.parentId || '', autoDeals: category.autoDeals || false, dealPercent: category.dealPercent || 0}); setShowDialog(true); }}>
            <Edit2 className="w-4 h-4" />
          </Button>
          <Button size="sm" variant="ghost" onClick={() => deleteCategory(category.id)}>
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
        {isExpanded && children.map(child => renderCategory(child, level + 1))}
      </div>
    );
  };

  const rootCategories = categories.filter(c => !c.parentId);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Categories</h1>
          <p className="text-muted-foreground mt-1">Hierarchical product categories with auto-deals</p>
        </div>
        <Button onClick={() => setShowDialog(true)}><Plus className="w-4 h-4 mr-2" />Add Category</Button>
      </div>

      <Card className="p-6">
        <div className="space-y-2">
          {rootCategories.length === 0 ? (
            <div className="text-center text-muted-foreground py-8">
              <Boxes className="w-16 h-16 mx-auto mb-4 opacity-50" />
              <p>No categories yet. Create your first category to get started.</p>
            </div>
          ) : (
            rootCategories.map(cat => renderCategory(cat))
          )}
        </div>
      </Card>

      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingCategory ? 'Edit Category' : 'Add Category'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Category Name</Label>
              <Input value={newCategory.name} onChange={(e) => setNewCategory({ ...newCategory, name: e.target.value })} placeholder="e.g., Electronics" />
            </div>
            <div>
              <Label>Parent Category (Optional)</Label>
              <Select value={newCategory.parentId || 'none'} onValueChange={(v) => setNewCategory({ ...newCategory, parentId: v === 'none' ? '' : v })}>
                <SelectTrigger><SelectValue placeholder="Select parent" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">None (Root Level)</SelectItem>
                  {categories.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center gap-2">
              <input type="checkbox" checked={newCategory.autoDeals} onChange={(e) => setNewCategory({ ...newCategory, autoDeals: e.target.checked })} />
              <Label>Enable Auto Deals</Label>
            </div>
            {newCategory.autoDeals && (
              <div>
                <Label>Deal Percentage</Label>
                <Input type="number" value={newCategory.dealPercent} onChange={(e) => setNewCategory({ ...newCategory, dealPercent: parseFloat(e.target.value) })} placeholder="10" />
              </div>
            )}
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => setShowDialog(false)} className="flex-1">Cancel</Button>
              <Button onClick={saveCategory} className="flex-1">Save</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
