import { useState, useEffect } from 'react';
import { storage, Rating, Order } from '@/lib/storage';
import { Card } from './ui/card';
import { Star, TrendingUp } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

export function RatingsView() {
  const [ratings, setRatings] = useState<(Rating & { order?: Order })[]>([]);
  const [stats, setStats] = useState({ average: 0, total: 0, distribution: [0, 0, 0, 0, 0] });

  useEffect(() => {
    loadRatings();
  }, []);

  const loadRatings = () => {
    const allRatings = storage.getRatings();
    const orders = storage.getOrders();
    
    const ratingsWithOrders = allRatings.map(r => ({
      ...r,
      order: orders.find(o => o.id === r.orderId),
    })).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    
    setRatings(ratingsWithOrders);

    const distribution = [0, 0, 0, 0, 0];
    allRatings.forEach(r => {
      distribution[r.rating - 1]++;
    });

    const average = allRatings.length > 0
      ? allRatings.reduce((sum, r) => sum + r.rating, 0) / allRatings.length
      : 0;

    setStats({ average, total: allRatings.length, distribution });
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">Customer Ratings</h2>
      
      <div className="grid md:grid-cols-2 gap-6">
        <Card className="p-6">
          <h3 className="font-semibold mb-4">Overall Rating</h3>
          <div className="flex items-center gap-4">
            <div className="text-5xl font-bold">{stats.average.toFixed(1)}</div>
            <div className="flex items-center gap-1">
              {[1, 2, 3, 4, 5].map(i => (
                <Star 
                  key={i} 
                  className={`w-6 h-6 ${i <= Math.round(stats.average) ? 'text-yellow-500 fill-yellow-500' : 'text-gray-300'}`}
                />
              ))}
            </div>
          </div>
          <p className="text-muted-foreground mt-2">{stats.total} total ratings</p>
        </Card>

        <Card className="p-6">
          <h3 className="font-semibold mb-4">Rating Distribution</h3>
          <div className="space-y-2">
            {[5, 4, 3, 2, 1].map(stars => (
              <div key={stars} className="flex items-center gap-2">
                <span className="w-12 text-sm">{stars} star</span>
                <div className="flex-1 h-4 bg-muted rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-yellow-500 rounded-full"
                    style={{ width: `${stats.total > 0 ? (stats.distribution[stars - 1] / stats.total) * 100 : 0}%` }}
                  />
                </div>
                <span className="w-12 text-sm text-right">{stats.distribution[stars - 1]}</span>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <Card className="p-6">
        <h3 className="font-semibold mb-4">Recent Ratings</h3>
        <div className="space-y-4">
          {ratings.map(rating => (
            <div key={rating.id} className="border-b pb-4 last:border-0">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  {[1, 2, 3, 4, 5].map(i => (
                    <Star 
                      key={i} 
                      className={`w-4 h-4 ${i <= rating.rating ? 'text-yellow-500 fill-yellow-500' : 'text-gray-300'}`}
                    />
                  ))}
                </div>
                <span className="text-sm text-muted-foreground">
                  {formatDistanceToNow(new Date(rating.createdAt), { addSuffix: true })}
                </span>
              </div>
              {rating.order && (
                <p className="text-sm text-muted-foreground">Order: {rating.order.transactionId}</p>
              )}
              {rating.feedback && (
                <p className="text-sm mt-2">{rating.feedback}</p>
              )}
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
