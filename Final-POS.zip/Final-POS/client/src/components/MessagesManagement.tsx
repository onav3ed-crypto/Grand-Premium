import { useState, useEffect } from 'react';
import { storage, Message, Customer } from '@/lib/storage';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Send, MessageSquare } from 'lucide-react';
import { useAuth } from './AuthContext';
import { formatDistanceToNow } from 'date-fns';

export function MessagesManagement() {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [selectedCustomer, setSelectedCustomer] = useState<string>('');
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const { currentCashier } = useAuth();

  useEffect(() => {
    loadCustomers();
  }, []);

  useEffect(() => {
    if (selectedCustomer) {
      loadMessages();
      const interval = setInterval(loadMessages, 3000);
      return () => clearInterval(interval);
    }
  }, [selectedCustomer]);

  const loadCustomers = () => {
    setCustomers(storage.getCustomers());
  };

  const loadMessages = () => {
    if (!selectedCustomer) return;

    const allMessages = storage.getMessages();
    const filtered = allMessages.filter(m => 
      (m.fromId === selectedCustomer) ||
      (m.toId === selectedCustomer)
    ).sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
    
    setMessages(filtered);
  };

  const sendMessage = () => {
    if (!newMessage.trim() || !selectedCustomer || !currentCashier) return;

    const customer = customers.find(c => c.id === selectedCustomer);
    if (!customer) return;

    const allMessages = storage.getMessages();
    const message: Message = {
      id: crypto.randomUUID(),
      fromId: currentCashier.id,
      fromName: currentCashier.name,
      fromRole: 'cashier',
      toId: customer.id,
      toName: customer.name,
      toRole: 'customer',
      text: newMessage,
      createdAt: new Date().toISOString(),
      read: false,
    };

    allMessages.push(message);
    storage.saveMessages(allMessages);
    setNewMessage('');
    loadMessages();
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">Customer Messages</h2>
      
      <Card className="p-4">
        <div className="mb-4">
          <label className="text-sm font-medium mb-2 block">Select Customer</label>
          <Select value={selectedCustomer} onValueChange={setSelectedCustomer}>
            <SelectTrigger>
              <SelectValue placeholder="Choose a customer" />
            </SelectTrigger>
            <SelectContent>
              {customers.map(c => (
                <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {selectedCustomer ? (
          <>
            <div className="h-[400px] overflow-y-auto space-y-3 mb-4 p-4 bg-muted/30 rounded-lg">
              {messages.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full text-muted-foreground">
                  <MessageSquare className="w-12 h-12 mb-2" />
                  <p>No messages yet. Start the conversation!</p>
                </div>
              ) : (
                messages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`flex ${msg.fromRole === 'cashier' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div className={`max-w-[70%] p-3 rounded-lg ${
                      msg.fromRole === 'cashier' 
                        ? 'bg-primary text-primary-foreground' 
                        : 'bg-card border'
                    }`}>
                      <p className="text-sm font-medium mb-1">{msg.fromName}</p>
                      <p>{msg.text}</p>
                      <p className="text-xs opacity-70 mt-1">
                        {formatDistanceToNow(new Date(msg.createdAt), { addSuffix: true })}
                      </p>
                    </div>
                  </div>
                ))
              )}
            </div>
            
            <div className="flex gap-2">
              <Textarea
                placeholder="Type your message..."
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    sendMessage();
                  }
                }}
                rows={2}
              />
              <Button onClick={sendMessage} size="icon" className="h-auto">
                <Send className="w-4 h-4" />
              </Button>
            </div>
          </>
        ) : (
          <div className="text-center py-12 text-muted-foreground">
            Select a customer to view and send messages
          </div>
        )}
      </Card>
    </div>
  );
}
