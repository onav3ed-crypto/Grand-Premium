import { ProductManagement } from '../ProductManagement';

export default function ProductManagementExample() {
  return (
    <div className="p-6">
      <ProductManagement />
    </div>
  );
}
