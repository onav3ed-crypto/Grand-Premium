import { POSCheckout } from '../POSCheckout';

export default function POSCheckoutExample() {
  return (
    <div className="h-screen p-4">
      <POSCheckout />
    </div>
  );
}
