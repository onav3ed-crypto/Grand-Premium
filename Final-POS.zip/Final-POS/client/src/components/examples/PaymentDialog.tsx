import { useState } from 'react';
import { PaymentDialog } from '../PaymentDialog';
import { Button } from '@/components/ui/button';

export default function PaymentDialogExample() {
  const [open, setOpen] = useState(true);

  return (
    <div className="p-6">
      <Button onClick={() => setOpen(true)}>Open Payment Dialog</Button>
      <PaymentDialog
        open={open}
        onOpenChange={setOpen}
        total={156.75}
        customerBalance={45.20}
      />
    </div>
  );
}
