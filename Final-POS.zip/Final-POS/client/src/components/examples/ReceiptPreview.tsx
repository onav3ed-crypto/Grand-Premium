import { useState } from 'react';
import { ReceiptPreview } from '../ReceiptPreview';
import { Button } from '@/components/ui/button';

export default function ReceiptPreviewExample() {
  const [open, setOpen] = useState(true);

  return (
    <div className="p-6">
      <Button onClick={() => setOpen(true)}>Open Receipt Preview</Button>
      <ReceiptPreview open={open} onOpenChange={setOpen} />
    </div>
  );
}
