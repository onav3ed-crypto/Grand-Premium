import { CustomerManagement } from '../CustomerManagement';

export default function CustomerManagementExample() {
  return (
    <div className="p-6">
      <CustomerManagement />
    </div>
  );
}
