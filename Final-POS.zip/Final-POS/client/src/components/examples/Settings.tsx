import { Settings } from '../Settings';

export default function SettingsExample() {
  return (
    <div className="p-6">
      <Settings />
    </div>
  );
}
