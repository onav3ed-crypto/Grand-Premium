import { useState, useEffect } from 'react';
import { storage, Notification } from '@/lib/storage';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Bell, CreditCard, Star, Megaphone, ShoppingBag } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

interface Props {
  customerId: string;
}

export function CustomerNotifications({ customerId }: Props) {
  const [notifications, setNotifications] = useState<Notification[]>([]);

  useEffect(() => {
    loadNotifications();
  }, [customerId]);

  const loadNotifications = () => {
    const notifs = storage.getNotifications(customerId);
    setNotifications(notifs.sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    ));
  };

  const getIcon = (type: Notification['type']) => {
    switch (type) {
      case 'purchase': return ShoppingBag;
      case 'cardActivity': return CreditCard;
      case 'points': return Star;
      case 'announcement': return Megaphone;
      default: return Bell;
    }
  };

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold">Notifications</h2>
      
      {notifications.length === 0 ? (
        <Card className="p-8 text-center text-muted-foreground">
          No notifications yet.
        </Card>
      ) : (
        <div className="space-y-3">
          {notifications.map((notif) => {
            const Icon = getIcon(notif.type);
            return (
              <Card key={notif.id} className={`p-4 ${notif.read ? 'opacity-60' : 'border-primary'}`}>
                <div className="flex items-start gap-3">
                  <div className="p-2 bg-primary/10 rounded-lg">
                    <Icon className="w-5 h-5 text-primary" />
                  </div>
                  <div className="flex-1">
                    <div className="flex justify-between items-start mb-1">
                      <h4 className="font-semibold">{notif.title}</h4>
                      {!notif.read && <Badge variant="default">New</Badge>}
                    </div>
                    <p className="text-sm text-muted-foreground">{notif.message}</p>
                    <p className="text-xs text-muted-foreground mt-2">
                      {formatDistanceToNow(new Date(notif.createdAt), { addSuffix: true })}
                    </p>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
