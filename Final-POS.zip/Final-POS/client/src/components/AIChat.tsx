import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Bot, Send, Trash2, Minimize2, X } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}

export function AIChat() {
  const [messages, setMessages] = useState<Message[]>([{
    id: '1',
    role: 'assistant',
    content: 'Hello! I\'m your offline POS assistant. I can help you with:\n\n• Product pricing strategies\n• Inventory management tips\n• Customer loyalty best practices\n• Tax configuration guidance\n• Sales analytics insights\n\nWhat would you like to know?',
    timestamp: new Date().toISOString(),
  }]);
  const [input, setInput] = useState('');
  const [isCompact, setIsCompact] = useState(false);
  const { toast } = useToast();

  const getOfflineResponse = (query: string): string => {
    const lowerQuery = query.toLowerCase();

    if (lowerQuery.includes('price') || lowerQuery.includes('pricing')) {
      return 'For optimal pricing:\n\n1. Set competitive margins (30-40% for retail)\n2. Use psychological pricing ($9.99 vs $10)\n3. Adjust prices during low-demand periods\n4. Track competitor prices regularly\n5. Offer bundle deals for higher margins\n\nWould you like help setting up price rules?';
    }
    
    if (lowerQuery.includes('stock') || lowerQuery.includes('inventory')) {
      return 'Inventory management tips:\n\n1. Set low-stock alerts at 20% of avg sales\n2. Track fast-moving vs slow-moving items\n3. Implement FIFO (First-In-First-Out)\n4. Schedule regular stock audits\n5. Plan for seasonal variations\n\nNeed help configuring stock alerts?';
    }

    if (lowerQuery.includes('loyalty') || lowerQuery.includes('customer')) {
      return 'Customer loyalty best practices:\n\n1. Reward frequent purchases (5-10% rewards)\n2. Create tiered benefits (Bronze/Silver/Gold)\n3. Send birthday rewards\n4. Offer member-only deals\n5. Track customer lifetime value\n\nWould you like to set up a loyalty program?';
    }

    if (lowerQuery.includes('tax')) {
      return 'Tax configuration guide:\n\n1. Set default tax rate in Settings\n2. Mark tax-exempt categories (groceries, medicine)\n3. Use smart tax detection for automatic classification\n4. Override individual products as needed\n5. Keep tax audit logs for compliance\n\nNeed help with tax rules?';
    }

    if (lowerQuery.includes('sales') || lowerQuery.includes('report')) {
      return 'Sales analytics recommendations:\n\n1. Review daily sales trends\n2. Identify peak hours for staffing\n3. Track profit margins per category\n4. Monitor customer purchase patterns\n5. Export monthly reports for analysis\n\nWant help generating a sales report?';
    }

    return 'I can help you with:\n• Pricing strategies\n• Inventory management\n• Customer loyalty programs\n• Tax configuration\n• Sales analytics\n\nPlease ask a specific question about any of these topics!';
  };

  const handleSend = () => {
    if (!input.trim()) return;

    const userMessage: Message = {
      id: crypto.randomUUID(),
      role: 'user',
      content: input,
      timestamp: new Date().toISOString(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');

    setTimeout(() => {
      const assistantMessage: Message = {
        id: crypto.randomUUID(),
        role: 'assistant',
        content: getOfflineResponse(input),
        timestamp: new Date().toISOString(),
      };
      setMessages(prev => [...prev, assistantMessage]);
    }, 500);
  };

  const clearChat = () => {
    setMessages([{
      id: '1',
      role: 'assistant',
      content: 'Chat cleared. How can I help you?',
      timestamp: new Date().toISOString(),
    }]);
    toast({
      title: 'Chat Cleared',
      description: 'Conversation history has been reset',
    });
  };

  if (isCompact) {
    return (
      <div className="fixed bottom-4 right-4 w-80 bg-card border rounded-lg shadow-lg z-50">
        <div className="flex items-center justify-between p-3 border-b bg-primary text-primary-foreground">
          <div className="flex items-center gap-2">
            <Bot className="w-4 h-4" />
            <span className="font-medium text-sm">AI Assistant</span>
          </div>
          <div className="flex gap-1">
            <Button
              size="icon"
              variant="ghost"
              onClick={() => setIsCompact(false)}
              className="h-6 w-6 text-primary-foreground hover:bg-primary-foreground/20"
            >
              <Minimize2 className="w-3 h-3" />
            </Button>
            <Button
              size="icon"
              variant="ghost"
              onClick={() => setIsCompact(false)}
              className="h-6 w-6 text-primary-foreground hover:bg-primary-foreground/20"
            >
              <X className="w-3 h-3" />
            </Button>
          </div>
        </div>
        <ScrollArea className="h-60 p-3">
          <div className="space-y-3">
            {messages.slice(-3).map((msg) => (
              <div
                key={msg.id}
                className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[90%] rounded-lg p-2 text-sm ${
                    msg.role === 'user'
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-muted'
                  }`}
                >
                  {msg.content}
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
        <div className="p-2 border-t flex gap-2">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Ask a question..."
            className="text-sm"
          />
          <Button size="sm" onClick={handleSend}>
            <Send className="w-3 h-3" />
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <Bot className="w-8 h-8" />
            AI Assistant
          </h1>
          <p className="text-muted-foreground mt-1">
            Offline helper for pricing, inventory, and sales guidance
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setIsCompact(true)}>
            <Minimize2 className="w-4 h-4 mr-2" />
            Minimize
          </Button>
          <Button variant="outline" onClick={clearChat}>
            <Trash2 className="w-4 h-4 mr-2" />
            Clear Chat
          </Button>
        </div>
      </div>

      <Card className="p-4 bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800">
        <div className="flex items-start gap-3">
          <Bot className="w-5 h-5 text-blue-600 mt-0.5" />
          <div className="flex-1">
            <p className="text-sm font-medium text-blue-900 dark:text-blue-100">
              Offline AI Assistant
            </p>
            <p className="text-sm text-blue-700 dark:text-blue-300 mt-1">
              This AI runs completely offline using local heuristics and best practices.
              No API keys or internet connection required!
            </p>
          </div>
          <Badge variant="outline" className="border-blue-400">Local</Badge>
        </div>
      </Card>

      <Card className="p-6">
        <ScrollArea className="h-[500px] pr-4">
          <div className="space-y-4">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[80%] rounded-lg p-4 ${
                    msg.role === 'user'
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-muted'
                  }`}
                >
                  <div className="flex items-start gap-2">
                    {msg.role === 'assistant' && (
                      <Bot className="w-4 h-4 mt-1 flex-shrink-0" />
                    )}
                    <div className="flex-1">
                      <p className="whitespace-pre-wrap">{msg.content}</p>
                      <p className="text-xs opacity-70 mt-2">
                        {new Date(msg.timestamp).toLocaleTimeString()}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>

        <div className="mt-4 flex gap-2">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Ask about pricing, inventory, loyalty, taxes, or sales..."
            className="flex-1"
          />
          <Button onClick={handleSend}>
            <Send className="w-4 h-4 mr-2" />
            Send
          </Button>
        </div>
      </Card>

      <Card className="p-4 bg-muted/50">
        <h3 className="font-medium mb-2">Suggested Questions:</h3>
        <div className="flex flex-wrap gap-2">
          {[
            'How should I price products?',
            'Tips for inventory management?',
            'How to set up loyalty program?',
            'Configure tax rules?',
            'Generate sales reports?',
          ].map((question) => (
            <Button
              key={question}
              variant="outline"
              size="sm"
              onClick={() => setInput(question)}
            >
              {question}
            </Button>
          ))}
        </div>
      </Card>
    </div>
  );
}
