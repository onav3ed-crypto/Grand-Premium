import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { TrendingUp, AlertTriangle, Package, Plus, Calendar } from 'lucide-react';
import { storage } from '@/lib/storage';
import { useToast } from '@/hooks/use-toast';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export function StockManagement() {
  const [products, setProducts] = useState(storage.getProducts());
  const [purchaseOrders, setPurchaseOrders] = useState<any[]>([]);
  const [showPODialog, setShowPODialog] = useState(false);
  const [newPO, setNewPO] = useState({ productId: '', quantity: 0, supplier: '', expectedDate: '' });
  const { toast } = useToast();

  useEffect(() => {
    const loadedPOs = (storage as any).getItem('purchaseOrders', []);
    setPurchaseOrders(loadedPOs);

    checkStockAlerts();
    checkExpiryAlerts();
  }, []);

  const checkStockAlerts = () => {
    const lowStock = products.filter(p => p.stock <= p.lowStockThreshold && !p.archived);
    if (lowStock.length > 0) {
      toast({
        title: 'Low Stock Alert',
        description: `${lowStock.length} product(s) are running low on stock`,
        variant: 'destructive',
      });
    }
  };

  const checkExpiryAlerts = () => {
    const today = new Date();
    const week = new Date(today.getTime() + 7 * 24 * 60 * 60 * 1000);
    
    const expiringSoon = products.filter(p => {
      if (!p.expiryDate) return false;
      const expiry = new Date(p.expiryDate);
      return expiry >= today && expiry <= week;
    });

    if (expiringSoon.length > 0) {
      toast({
        title: 'Expiry Alert',
        description: `${expiringSoon.length} product(s) expiring within 7 days`,
      });
    }
  };

  const createPurchaseOrder = () => {
    if (!newPO.productId || newPO.quantity <= 0) {
      toast({
        title: 'Error',
        description: 'Please fill all required fields',
        variant: 'destructive',
      });
      return;
    }

    const product = products.find(p => p.id === newPO.productId);
    if (!product) return;

    const po = {
      id: crypto.randomUUID(),
      ...newPO,
      productName: product.name,
      status: 'pending',
      createdAt: new Date().toISOString(),
    };

    const updated = [...purchaseOrders, po];
    setPurchaseOrders(updated);
    (storage as any).setItem('purchaseOrders', updated);

    toast({
      title: 'Purchase Order Created',
      description: `PO for ${product.name} created successfully`,
    });

    setShowPODialog(false);
    setNewPO({ productId: '', quantity: 0, supplier: '', expectedDate: '' });
  };

  const receivePurchaseOrder = (poId: string) => {
    const po = purchaseOrders.find(p => p.id === poId);
    if (!po) return;

    const productList = storage.getProducts();
    const updated = productList.map(p =>
      p.id === po.productId ? { ...p, stock: p.stock + po.quantity } : p
    );
    storage.saveProducts(updated);
    setProducts(updated);

    const updatedPOs = purchaseOrders.map(p =>
      p.id === poId ? { ...p, status: 'received', receivedAt: new Date().toISOString() } : p
    );
    setPurchaseOrders(updatedPOs);
    (storage as any).setItem('purchaseOrders', updatedPOs);

    toast({
      title: 'Stock Received',
      description: `${po.quantity} units of ${po.productName} added to stock`,
    });
  };

  const lowStockProducts = products.filter(p => p.stock <= p.lowStockThreshold && !p.archived);
  const expiringProducts = products.filter(p => {
    if (!p.expiryDate) return false;
    const expiry = new Date(p.expiryDate);
    const week = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
    return expiry <= week && expiry >= new Date();
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Stock Management</h1>
          <p className="text-muted-foreground mt-1">Monitor inventory, purchase orders, and expiry tracking</p>
        </div>
        <Button onClick={() => setShowPODialog(true)}>
          <Plus className="w-4 h-4 mr-2" />
          New Purchase Order
        </Button>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <Card className="p-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-red-100 dark:bg-red-900/20 rounded-lg">
              <AlertTriangle className="w-6 h-6 text-red-600" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Low Stock Items</p>
              <p className="text-2xl font-bold">{lowStockProducts.length}</p>
            </div>
          </div>
        </Card>

        <Card className="p-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-yellow-100 dark:bg-yellow-900/20 rounded-lg">
              <Calendar className="w-6 h-6 text-yellow-600" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Expiring Soon</p>
              <p className="text-2xl font-bold">{expiringProducts.length}</p>
            </div>
          </div>
        </Card>

        <Card className="p-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-blue-100 dark:bg-blue-900/20 rounded-lg">
              <Package className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Pending POs</p>
              <p className="text-2xl font-bold">
                {purchaseOrders.filter(po => po.status === 'pending').length}
              </p>
            </div>
          </div>
        </Card>
      </div>

      <Tabs defaultValue="alerts" className="w-full">
        <TabsList>
          <TabsTrigger value="alerts">Stock Alerts</TabsTrigger>
          <TabsTrigger value="expiry">Expiry Tracking</TabsTrigger>
          <TabsTrigger value="orders">Purchase Orders</TabsTrigger>
        </TabsList>

        <TabsContent value="alerts">
          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4">Low Stock Products</h3>
            <ScrollArea className="h-[400px]">
              <div className="space-y-2">
                {lowStockProducts.length === 0 ? (
                  <p className="text-center text-muted-foreground py-8">All products are well stocked!</p>
                ) : (
                  lowStockProducts.map(product => (
                    <div key={product.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <p className="font-medium">{product.name}</p>
                        <p className="text-sm text-muted-foreground">SKU: {product.sku}</p>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="text-right">
                          <p className="text-sm text-muted-foreground">Current Stock</p>
                          <Badge variant="destructive">{product.stock} units</Badge>
                        </div>
                        <div className="text-right">
                          <p className="text-sm text-muted-foreground">Threshold</p>
                          <Badge variant="outline">{product.lowStockThreshold}</Badge>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </ScrollArea>
          </Card>
        </TabsContent>

        <TabsContent value="expiry">
          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4">Products Expiring Soon (Next 7 Days)</h3>
            <ScrollArea className="h-[400px]">
              <div className="space-y-2">
                {expiringProducts.length === 0 ? (
                  <p className="text-center text-muted-foreground py-8">No products expiring soon</p>
                ) : (
                  expiringProducts.map(product => (
                    <div key={product.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <p className="font-medium">{product.name}</p>
                        <p className="text-sm text-muted-foreground">{product.stock} units in stock</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-muted-foreground">Expires</p>
                        <Badge variant="destructive">
                          {new Date(product.expiryDate!).toLocaleDateString()}
                        </Badge>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </ScrollArea>
          </Card>
        </TabsContent>

        <TabsContent value="orders">
          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4">Purchase Orders</h3>
            <ScrollArea className="h-[400px]">
              <div className="space-y-2">
                {purchaseOrders.length === 0 ? (
                  <p className="text-center text-muted-foreground py-8">No purchase orders yet</p>
                ) : (
                  purchaseOrders.map(po => (
                    <div key={po.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex-1">
                        <p className="font-medium">{po.productName}</p>
                        <p className="text-sm text-muted-foreground">
                          {po.quantity} units • Supplier: {po.supplier}
                        </p>
                        {po.expectedDate && (
                          <p className="text-sm text-muted-foreground">
                            Expected: {new Date(po.expectedDate).toLocaleDateString()}
                          </p>
                        )}
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant={po.status === 'pending' ? 'default' : 'secondary'}>
                          {po.status}
                        </Badge>
                        {po.status === 'pending' && (
                          <Button size="sm" onClick={() => receivePurchaseOrder(po.id)}>
                            Receive
                          </Button>
                        )}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </ScrollArea>
          </Card>
        </TabsContent>
      </Tabs>

      <Dialog open={showPODialog} onOpenChange={setShowPODialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create Purchase Order</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Product</Label>
              <select
                className="w-full p-2 border rounded mt-1"
                value={newPO.productId}
                onChange={(e) => setNewPO({ ...newPO, productId: e.target.value })}
              >
                <option value="">Select Product</option>
                {products.filter(p => !p.archived).map(p => (
                  <option key={p.id} value={p.id}>{p.name} (Current: {p.stock})</option>
                ))}
              </select>
            </div>
            <div>
              <Label>Quantity</Label>
              <Input
                type="number"
                value={newPO.quantity}
                onChange={(e) => setNewPO({ ...newPO, quantity: parseInt(e.target.value) })}
                placeholder="100"
                className="mt-1"
              />
            </div>
            <div>
              <Label>Supplier</Label>
              <Input
                value={newPO.supplier}
                onChange={(e) => setNewPO({ ...newPO, supplier: e.target.value })}
                placeholder="Supplier name"
                className="mt-1"
              />
            </div>
            <div>
              <Label>Expected Delivery Date</Label>
              <Input
                type="date"
                value={newPO.expectedDate}
                onChange={(e) => setNewPO({ ...newPO, expectedDate: e.target.value })}
                className="mt-1"
              />
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => setShowPODialog(false)} className="flex-1">
                Cancel
              </Button>
              <Button onClick={createPurchaseOrder} className="flex-1">
                Create PO
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
