import { useState, useEffect } from 'react';
import { storage, Deal, Product } from '@/lib/storage';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Percent } from 'lucide-react';

export function CustomerDeals() {
  const [deals, setDeals] = useState<(Deal & { product?: Product })[]>([]);

  useEffect(() => {
    loadDeals();
  }, []);

  const loadDeals = () => {
    const allDeals = storage.getDeals().filter(d => d.active);
    const products = storage.getProducts();
    
    const dealsWithProducts = allDeals.map(deal => ({
      ...deal,
      product: products.find(p => p.id === deal.productId),
    }));
    
    setDeals(dealsWithProducts);
  };

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold">Special Deals</h2>
      
      {deals.length === 0 ? (
        <Card className="p-8 text-center text-muted-foreground">
          No deals available at the moment. Check back later!
        </Card>
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {deals.map((deal) => {
            if (!deal.product) return null;
            
            const wasPrice = deal.product.price;
            const nowPrice = deal.type === 'percentage' 
              ? wasPrice * (1 - (deal.discountPercent || 0) / 100)
              : wasPrice;
            const savings = wasPrice - nowPrice;
            
            return (
              <Card key={deal.id} className="p-6 hover:shadow-lg transition-shadow">
                <div className="flex justify-between items-start mb-4">
                  <h3 className="font-semibold text-lg">{deal.product.name}</h3>
                  <Badge variant="default">
                    <Percent className="w-3 h-3 mr-1" />
                    {deal.type === 'percentage' ? `${deal.discountPercent}% OFF` : 'Special'}
                  </Badge>
                </div>
                
                {deal.type === 'percentage' && (
                  <div className="space-y-2">
                    <div className="flex justify-between items-baseline">
                      <span className="text-muted-foreground">Was:</span>
                      <span className="line-through text-muted-foreground">${wasPrice.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between items-baseline">
                      <span className="font-medium">Now:</span>
                      <span className="text-2xl font-bold text-primary">${nowPrice.toFixed(2)}</span>
                    </div>
                    <div className="pt-2 border-t">
                      <p className="text-green-600 font-medium">
                        {deal.discountPercent}% Off. Save ${savings.toFixed(2)}!
                      </p>
                    </div>
                  </div>
                )}
                
                {deal.type === 'buyXgetY' && (
                  <div className="bg-primary/10 p-4 rounded-lg">
                    <p className="font-semibold text-center">
                      Buy {deal.buyQuantity}, Get {deal.getQuantity} FREE!
                    </p>
                  </div>
                )}
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
