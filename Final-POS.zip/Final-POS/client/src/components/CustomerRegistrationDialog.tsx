import { useState } from 'react';
import { storage, Customer } from '@/lib/storage';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { useToast } from '@/hooks/use-toast';
import { UserPlus } from 'lucide-react';

export function CustomerRegistrationDialog() {
  const [isOpen, setIsOpen] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [cardPin, setCardPin] = useState('');
  const [cardBalance, setCardBalance] = useState('0');
  const { toast } = useToast();

  const registerCustomer = () => {
    if (!name.trim() || !cardPin || cardPin.length !== 4) {
      toast({
        title: 'Invalid Input',
        description: 'Name and 4-digit PIN are required',
        variant: 'destructive',
      });
      return;
    }

    const existing = storage.getCustomerByPin(cardPin);
    if (existing) {
      toast({
        title: 'PIN Already Used',
        description: 'This PIN is already registered to another customer',
        variant: 'destructive',
      });
      return;
    }

    const customer: Omit<Customer, 'id' | 'createdAt' | 'totalSpent' | 'visits' | 'lastVisit'> = {
      name,
      email: email || undefined,
      phone: phone || undefined,
      balance: 0,
      points: 0,
      tier: 'Bronze',
      tags: [],
      hasCard: true,
      cardPin,
      cardBalance: parseFloat(cardBalance) || 0,
      role: 'customer',
    };

    storage.addCustomer(customer);
    
    toast({
      title: 'Customer Registered',
      description: `${name} can now log in with PIN: ${cardPin}`,
    });

    setIsOpen(false);
    resetForm();
  };

  const resetForm = () => {
    setName('');
    setEmail('');
    setPhone('');
    setCardPin('');
    setCardBalance('0');
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline">
          <UserPlus className="w-4 h-4 mr-2" />
          Register Customer
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Register New Customer</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <div>
            <Label htmlFor="name">Full Name *</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="John Doe"
            />
          </div>

          <div>
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="john@example.com"
            />
          </div>

          <div>
            <Label htmlFor="phone">Phone</Label>
            <Input
              id="phone"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="+1 (555) 000-0000"
            />
          </div>

          <div>
            <Label htmlFor="cardPin">Card PIN (4 digits) *</Label>
            <Input
              id="cardPin"
              type="password"
              maxLength={4}
              value={cardPin}
              onChange={(e) => setCardPin(e.target.value.replace(/\D/g, ''))}
              placeholder="••••"
            />
            <p className="text-xs text-muted-foreground mt-1">
              This PIN will be used for customer login and card payments
            </p>
          </div>

          <div>
            <Label htmlFor="cardBalance">Initial Card Balance</Label>
            <Input
              id="cardBalance"
              type="number"
              step="0.01"
              value={cardBalance}
              onChange={(e) => setCardBalance(e.target.value)}
              placeholder="0.00"
            />
          </div>

          <div className="flex gap-2 pt-4">
            <Button variant="outline" onClick={() => setIsOpen(false)} className="flex-1">
              Cancel
            </Button>
            <Button onClick={registerCustomer} className="flex-1">
              Register Customer
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
