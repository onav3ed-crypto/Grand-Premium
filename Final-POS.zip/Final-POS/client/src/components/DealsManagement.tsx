import { useState, useEffect } from 'react';
import { storage, Deal, Product } from '@/lib/storage';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { useAuth } from './AuthContext';
import { useToast } from '@/hooks/use-toast';
import { Plus, Percent, Gift } from 'lucide-react';

export function DealsManagement() {
  const [deals, setDeals] = useState<Deal[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState('');
  const [dealType, setDealType] = useState<'percentage' | 'buyXgetY'>('percentage');
  const [discountPercent, setDiscountPercent] = useState('10');
  const [buyQuantity, setBuyQuantity] = useState('2');
  const [getQuantity, setGetQuantity] = useState('1');
  const { currentCashier } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    loadDeals();
    loadProducts();
  }, []);

  const loadDeals = () => {
    setDeals(storage.getDeals());
  };

  const loadProducts = () => {
    setProducts(storage.getProducts().filter(p => !p.archived));
  };

  const createDeal = () => {
    if (!selectedProduct || !currentCashier) return;

    const deal: Deal = {
      id: crypto.randomUUID(),
      productId: selectedProduct,
      type: dealType,
      discountPercent: dealType === 'percentage' ? parseInt(discountPercent) : undefined,
      buyQuantity: dealType === 'buyXgetY' ? parseInt(buyQuantity) : undefined,
      getQuantity: dealType === 'buyXgetY' ? parseInt(getQuantity) : undefined,
      active: true,
      createdAt: new Date().toISOString(),
      createdBy: currentCashier.name,
    };

    const allDeals = storage.getDeals();
    allDeals.push(deal);
    storage.saveDeals(allDeals);
    
    toast({ title: 'Deal Created', description: 'Deal has been created successfully' });
    setIsDialogOpen(false);
    loadDeals();
    resetForm();
  };

  const toggleDeal = (dealId: string) => {
    const allDeals = storage.getDeals();
    const deal = allDeals.find(d => d.id === dealId);
    if (deal) {
      deal.active = !deal.active;
      storage.saveDeals(allDeals);
      loadDeals();
      toast({ title: deal.active ? 'Deal Activated' : 'Deal Deactivated' });
    }
  };

  const resetForm = () => {
    setSelectedProduct('');
    setDealType('percentage');
    setDiscountPercent('10');
    setBuyQuantity('2');
    setGetQuantity('1');
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Deals Management</h2>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button><Plus className="w-4 h-4 mr-2" />Create Deal</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create New Deal</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>Product</Label>
                <Select value={selectedProduct} onValueChange={setSelectedProduct}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select product" />
                  </SelectTrigger>
                  <SelectContent>
                    {products.map(p => (
                      <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Deal Type</Label>
                <Select value={dealType} onValueChange={(v) => setDealType(v as 'percentage' | 'buyXgetY')}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="percentage">Percentage Discount</SelectItem>
                    <SelectItem value="buyXgetY">Buy X Get Y Free</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {dealType === 'percentage' && (
                <div>
                  <Label>Discount Percentage</Label>
                  <Input type="number" value={discountPercent} onChange={e => setDiscountPercent(e.target.value)} />
                </div>
              )}

              {dealType === 'buyXgetY' && (
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Buy Quantity</Label>
                    <Input type="number" value={buyQuantity} onChange={e => setBuyQuantity(e.target.value)} />
                  </div>
                  <div>
                    <Label>Get Quantity Free</Label>
                    <Input type="number" value={getQuantity} onChange={e => setGetQuantity(e.target.value)} />
                  </div>
                </div>
              )}

              <Button onClick={createDeal} className="w-full">Create Deal</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {deals.map(deal => {
          const product = products.find(p => p.id === deal.productId);
          if (!product) return null;

          return (
            <Card key={deal.id} className={`p-4 ${!deal.active && 'opacity-50'}`}>
              <div className="flex justify-between items-start mb-2">
                <h3 className="font-semibold">{product.name}</h3>
                <Button variant="outline" size="sm" onClick={() => toggleDeal(deal.id)}>
                  {deal.active ? 'Deactivate' : 'Activate'}
                </Button>
              </div>
              {deal.type === 'percentage' && (
                <p className="text-sm text-muted-foreground flex items-center gap-2">
                  <Percent className="w-4 h-4" />
                  {deal.discountPercent}% Discount
                </p>
              )}
              {deal.type === 'buyXgetY' && (
                <p className="text-sm text-muted-foreground flex items-center gap-2">
                  <Gift className="w-4 h-4" />
                  Buy {deal.buyQuantity} Get {deal.getQuantity} Free
                </p>
              )}
            </Card>
          );
        })}
      </div>
    </div>
  );
}
