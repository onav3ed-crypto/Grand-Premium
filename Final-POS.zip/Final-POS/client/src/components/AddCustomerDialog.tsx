import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { storage, type Customer } from '@/lib/storage';
import { useToast } from '@/hooks/use-toast';

interface AddCustomerDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onAdded: (customer: Customer) => void;
}

export function AddCustomerDialog({ open, onOpenChange, onAdded }: AddCustomerDialogProps) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [hasCard, setHasCard] = useState(false);
  const [cardPin, setCardPin] = useState('');
  const [cardBalance, setCardBalance] = useState('');
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!name.trim()) {
      toast({
        title: 'Name Required',
        description: 'Please enter customer name',
        variant: 'destructive',
      });
      return;
    }

    if (hasCard && (!cardPin || cardPin.length !== 4)) {
      toast({
        title: 'Invalid Card PIN',
        description: 'Card PIN must be 4 digits',
        variant: 'destructive',
      });
      return;
    }

    const customer = storage.addCustomer({
      name: name.trim(),
      email: email.trim() || undefined,
      phone: phone.trim() || undefined,
      balance: 0,
      points: 0,
      tier: 'Bronze',
      tags: [],
      hasCard: hasCard,
      cardPin: hasCard ? cardPin : undefined,
      cardBalance: hasCard ? parseFloat(cardBalance) || 0 : undefined,
    });

    toast({
      title: 'Customer Added',
      description: `${customer.name} has been added successfully`,
    });

    setName('');
    setEmail('');
    setPhone('');
    setHasCard(false);
    setCardPin('');
    setCardBalance('');
    onAdded(customer);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Add New Customer</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="customer-name">Name *</Label>
            <Input
              id="customer-name"
              data-testid="input-customer-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Enter customer name"
              className="mt-1"
            />
          </div>

          <div>
            <Label htmlFor="customer-email">Email</Label>
            <Input
              id="customer-email"
              data-testid="input-customer-email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="customer@example.com"
              className="mt-1"
            />
          </div>

          <div>
            <Label htmlFor="customer-phone">Phone</Label>
            <Input
              id="customer-phone"
              data-testid="input-customer-phone"
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="+1 (555) 123-4567"
              className="mt-1"
            />
          </div>

          <div className="flex items-center space-x-2 pt-2">
            <Checkbox 
              id="has-card" 
              checked={hasCard}
              onCheckedChange={(checked) => setHasCard(checked as boolean)}
            />
            <Label htmlFor="has-card" className="cursor-pointer">
              Card Payment
            </Label>
          </div>

          {hasCard && (
            <>
              <div>
                <Label htmlFor="card-pin">Card PIN (4 digits) *</Label>
                <Input
                  id="card-pin"
                  type="password"
                  maxLength={4}
                  value={cardPin}
                  onChange={(e) => setCardPin(e.target.value.replace(/\D/g, ''))}
                  placeholder="Enter 4-digit PIN"
                  className="mt-1"
                />
              </div>
              <div>
                <Label htmlFor="card-balance">Card Balance *</Label>
                <Input
                  id="card-balance"
                  type="number"
                  step="0.01"
                  value={cardBalance}
                  onChange={(e) => setCardBalance(e.target.value)}
                  placeholder="0.00"
                  className="mt-1"
                />
              </div>
            </>
          )}

          <div className="flex gap-2 pt-4">
            <Button
              type="button"
              variant="outline"
              className="flex-1"
              onClick={() => onOpenChange(false)}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              className="flex-1"
              data-testid="button-save-customer"
            >
              Add Customer
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
