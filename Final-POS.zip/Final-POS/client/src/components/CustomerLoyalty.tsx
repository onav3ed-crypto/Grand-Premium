import { Customer } from '@/lib/storage';
import { Card } from './ui/card';
import { Progress } from './ui/progress';
import { Star, Gift, TrendingUp } from 'lucide-react';

interface Props {
  customer: Customer;
}

export function CustomerLoyalty({ customer }: Props) {
  const tierInfo = {
    Bronze: { min: 0, next: 'Silver', nextAmount: 1000, color: 'text-orange-600' },
    Silver: { min: 1000, next: 'Gold', nextAmount: 5000, color: 'text-gray-400' },
    Gold: { min: 5000, next: 'Platinum', nextAmount: 10000, color: 'text-yellow-500' },
    Platinum: { min: 10000, next: null, nextAmount: 0, color: 'text-purple-600' },
  };

  const currentTier = tierInfo[customer.tier];
  const progress = currentTier.next 
    ? ((customer.totalSpent - currentTier.min) / (currentTier.nextAmount - currentTier.min)) * 100
    : 100;

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">Loyalty Program</h2>
      
      <Card className="p-6">
        <div className="text-center mb-6">
          <div className={`inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-primary/20 to-primary/10 rounded-full mb-4`}>
            <Star className={`w-10 h-10 ${currentTier.color}`} fill="currentColor" />
          </div>
          <h3 className="text-2xl font-bold mb-2">{customer.tier} Member</h3>
          <p className="text-muted-foreground">Total Spent: ${customer.totalSpent.toFixed(2)}</p>
        </div>

        {currentTier.next && (
          <div className="space-y-3">
            <div className="flex justify-between text-sm">
              <span>Progress to {currentTier.next}</span>
              <span className="font-medium">{progress.toFixed(0)}%</span>
            </div>
            <Progress value={progress} className="h-3" />
            <p className="text-sm text-muted-foreground text-center">
              Spend ${(currentTier.nextAmount - customer.totalSpent).toFixed(2)} more to reach {currentTier.next}
            </p>
          </div>
        )}
      </Card>

      <Card className="p-6">
        <h4 className="font-semibold mb-4 flex items-center gap-2">
          <Gift className="w-5 h-5 text-primary" />
          Your Points
        </h4>
        <div className="text-4xl font-bold text-primary mb-2">{customer.points}</div>
        <p className="text-sm text-muted-foreground">Loyalty points earned from purchases</p>
      </Card>

      <Card className="p-6">
        <h4 className="font-semibold mb-4 flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-primary" />
          Your Activity
        </h4>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-sm text-muted-foreground">Total Visits</p>
            <p className="text-2xl font-bold">{customer.visits}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Lifetime Value</p>
            <p className="text-2xl font-bold">${customer.totalSpent.toFixed(2)}</p>
          </div>
        </div>
      </Card>
    </div>
  );
}
