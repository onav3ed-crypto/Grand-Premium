# POS System Design Guidelines

## Design Approach
**System-Based Approach**: Material Design principles adapted for enterprise POS applications, drawing inspiration from Square POS, Toast POS, and Shopify POS for proven usability patterns in retail/hospitality environments.

**Core Principles**:
- Efficiency-first: Every interaction optimized for speed
- Data clarity: Information hierarchy that supports quick decision-making
- Touch-optimized: Large touch targets for tablet/touchscreen use
- Professional credibility: Clean, trustworthy business application aesthetic

---

## Color Palette

**Light Mode**:
- Primary: 220 85% 35% (Deep professional blue)
- Primary Hover: 220 85% 30%
- Background: 0 0% 98%
- Surface: 0 0% 100%
- Border: 220 15% 88%
- Text Primary: 220 20% 15%
- Text Secondary: 220 15% 45%
- Success: 145 65% 42%
- Warning: 38 92% 50%
- Error: 0 72% 51%

**Dark Mode** (for extended use):
- Primary: 220 85% 60%
- Primary Hover: 220 85% 65%
- Background: 220 18% 12%
- Surface: 220 15% 16%
- Border: 220 15% 25%
- Text Primary: 220 15% 95%
- Text Secondary: 220 10% 65%
- Success: 145 60% 48%
- Warning: 38 90% 55%
- Error: 0 70% 58%

**Accent Colors** (use sparingly):
- Info: 200 95% 45%
- Loyalty Gold: 45 95% 55% (for loyalty tier badges only)

---

## Typography

**Font Families**:
- Primary: 'Inter' (Google Fonts) - for UI elements, forms, data
- Monospace: 'Roboto Mono' - for codes, prices, receipts

**Scale**:
- Receipt/Receipt Preview: text-xs (0.75rem)
- Data Tables/Small Labels: text-sm (0.875rem)
- Body/Forms: text-base (1rem)
- Section Headers: text-lg font-semibold (1.125rem)
- Card Titles: text-xl font-semibold (1.25rem)
- Page Titles: text-2xl font-bold (1.5rem)
- Dashboard Headers: text-3xl font-bold (1.875rem)

**Weights**: 
- Regular (400): body text
- Medium (500): emphasis, labels
- Semibold (600): subheadings, buttons
- Bold (700): headings, important metrics

---

## Layout System

**Spacing Primitives**: Use Tailwind units of 2, 4, 6, 8, 12, 16, 20 for consistent rhythm
- Component padding: p-4 to p-6
- Section spacing: mb-6 to mb-8
- Card spacing: p-6
- Form field gaps: gap-4
- Grid gaps: gap-4 to gap-6

**Container Strategy**:
- Main workspace: max-w-[1600px] mx-auto px-4
- Modals/Forms: max-w-2xl for single column, max-w-4xl for two-column
- Receipt preview: max-w-md
- Dashboard cards: grid-cols-1 md:grid-cols-2 lg:grid-cols-4

**Layout Patterns**:
- Primary workspace: 70% transaction area + 30% order summary (split-screen)
- Management screens: Sidebar navigation (240px) + main content area
- Dashboard: 4-column responsive grid for metrics cards
- Modals: Centered overlay with backdrop blur

---

## Component Library

### Core UI Elements
- **Buttons**: 
  - Primary: filled with primary color, h-10 px-6, rounded-lg
  - Secondary: outline border-2, h-10 px-6
  - Icon buttons: h-10 w-10 rounded-lg for actions
  - Touch targets: minimum 44x44px for tablet use

- **Input Fields**:
  - Height: h-12 for easy touch
  - Border: border-2 with focus ring-2 ring-primary/20
  - Rounded: rounded-lg
  - Large text: text-lg for number inputs (codes, quantities)

- **Cards**:
  - Background: bg-surface, border border-border
  - Rounded: rounded-xl
  - Shadow: shadow-sm hover:shadow-md transition
  - Padding: p-6

- **Tables/Lists**:
  - Striped rows: alternate bg-surface/transparent
  - Row height: min-h-14 for touch
  - Sticky headers for long lists
  - Hover state: bg-primary/5

### Navigation
- **Top Bar**: Fixed header h-16, primary brand color, contains logo, cashier info, settings
- **Sidebar** (management): Fixed w-60, collapsible on mobile, icon + label items
- **Tabs**: Underline style with 2px indicator, h-12 touch targets
- **Breadcrumbs**: text-sm with chevron separators

### Forms
- **Multi-step Forms**: Progress indicator at top, 4-step max per page
- **Validation**: Inline error messages in error color, text-sm
- **Field Groups**: Grouped with subtle border, related fields together
- **Search/Filter**: Sticky top bar with autocomplete dropdown

### Data Display
- **Metric Cards**: Large number (text-3xl font-bold), label below, icon top-right
- **Charts**: Simple bar/line charts using Chart.js, primary color scheme
- **Badges**: rounded-full px-3 py-1, colored by status (success/warning/error)
- **Tags**: rounded-md px-2 py-1, muted colors for categories

### Overlays
- **Modals**: backdrop-blur-sm, centered, slide-up animation, max-h-[90vh] overflow-auto
- **Toasts**: Fixed top-right, slide-in-right, auto-dismiss 3s, stacked
- **Confirmation Dialogs**: Compact modal, clear yes/no buttons, danger actions in error color
- **Drawer**: Slide from right for order summary, full-height

---

## Key Screens Layout

### Main POS Screen
- **Left Panel (70%)**: Item lookup search (top), quick-add grid (4 cols), categories filter
- **Right Panel (30%)**: Current order list (scrollable), totals summary, payment buttons
- **Bottom Bar**: Complete Order (primary lg button), Hold Order, Clear Order

### Customer Management
- **Top**: Search bar + Add Customer button
- **Grid**: 3-column customer cards with avatar, name, balance, loyalty tier
- **Side Panel**: Selected customer details, purchase history, edit form

### Inventory Management  
- **Header**: Search, category filter, Add Item button, Bulk Actions dropdown
- **Table View**: Sortable columns (Name, Code, Stock, Price, Actions), pagination
- **Item Card**: Image thumbnail, details, stock badge, quick-edit icon

### Dashboard/Reports
- **Top Row**: 4 metric cards (Daily Sales, Total Orders, Avg Order, Profit)
- **Charts Row**: Sales chart (8 cols) + Top Items list (4 cols)
- **Bottom**: Recent transactions table, exportable

### Receipt Screen
- **Preview**: Paper-style card (white bg, shadow), store header, items table, totals
- **Actions**: Download PDF, Print, Email (simulated), Close buttons
- **Compact layout**: max-w-md, condensed spacing for thermal printer simulation

---

## Animations
**Minimal & Purposeful Only**:
- Button press: scale-95 active state
- Modal enter: slide-up + fade-in (150ms)
- Toast notifications: slide-in-right (200ms)
- Success checkmark: scale pop on order complete
- NO page transitions, NO decorative animations

---

## Interaction Patterns
- **Keyboard Shortcuts**: Enter submits, Tab navigates, Esc closes modals
- **On-screen Numpad**: Floating overlay for tablets, 3x4 grid, large buttons
- **Touch Gestures**: Swipe to delete items, long-press for context menu
- **Auto-focus**: Code input field on page load, next field after submit
- **Loading States**: Spinner overlay on async actions, skeleton loaders for tables
- **Empty States**: Friendly illustration + CTA, not just blank space

---

## Accessibility & Responsive
- **Touch Targets**: 44px minimum, 56px for primary actions
- **Focus Indicators**: 2px ring in primary color, visible in dark mode
- **Color Contrast**: WCAG AA compliant (4.5:1 for text)
- **Responsive Breakpoints**: 
  - Mobile: Single column, stacked layout, bottom nav
  - Tablet (768px+): 2-column, side-by-side
  - Desktop (1024px+): Full multi-column, sidebar visible
- **Dark Mode**: Automatically applied, persisted in localStorage

---

## Data Density Strategy
- **High-density tables**: Compact row height, many columns visible, horizontal scroll on mobile
- **Medium-density cards**: Balanced whitespace, scannable information
- **Low-density forms**: Generous spacing, clear labels, grouped sections
- **Receipts**: Minimal spacing, maximum info in minimal height